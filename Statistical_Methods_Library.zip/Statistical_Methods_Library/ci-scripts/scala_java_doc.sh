#!/usr/bin/env bash
# Build scala documentation
echo 'SCALA DOCUMENTATION'
mvn scala:doc

# Archive the scala documentation
tar -czvf target/ScalaSite.tar.gz target/site/

# Remove the original scala documentation folder
rm -rf target/site

# Build the java documentation
echo 'JAVA DOCUMENTATION'
mvn javadoc:javadoc

# Archive the java documentation
tar -czvf target/JavaSite.tar.gz target/site/


# TODO: Deploy to a web server