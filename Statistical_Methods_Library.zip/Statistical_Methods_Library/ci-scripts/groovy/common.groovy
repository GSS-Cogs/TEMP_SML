#!/usr/bin/env groovy

def branchName()
{
    return sh(returnStdout: true, script: 'git rev-parse --abbrev-ref HEAD').trim()
}

def getLatestGitTag(GITLAB_CREDS_USR, GITLAB_CREDS_PSW) {
    fullStr = sh(returnStdout: true, script: "git ls-remote --tags http://${GITLAB_CREDS_USR}:${GITLAB_CREDS_PSW}@np2rvlapxx507/DAP-S/Statistical_Methods_Library.git")
    fullList = fullStr.split("\n").sort()
    println("Tag fullList: ${fullList}")

    tagList = []
    if (fullStr.length() > 0) {
        fullList = fullStr.split("\n").sort()
        for (tag in fullList) {
            println(tag)
            tagList.add(tag.split("refs/tags")[1])
        }
    } else {
        println "No available tag, using default 0.0.0"
        return "0.0.0"
    }

    // This sorts the tag list so the 0.0.0 is first followed by everything else
    taggListOrd = tagList.sort()

    // This for loop flips the list so the latest on is first
    tagRevOr = []
    for (i = taggListOrd.size() - 1; i > 0; i--){
        println(taggListOrd[i])
        tagRevOr.add(taggListOrd[i])
    }
    println("ordered Tag list : " + tagRevOr)

    for (tag in tagRevOr) {
        def regexResult = "${tag}" == /(\d*)+\.(\d*)+\.(\d*)(-DEV|-SNAPSHOT|-NON-RELEASE)?/
        println "Evaluating most recent tag: ${tag}"
        if (regexResult) {
            println("found a usable tag : ${tag}")
            return tag
        }
    }
    println "No available tag, using default 0.0.0"
    return "0.0.0"
}

def checkMasterTags(currentTag, branchName)
{
    sh("""
    rm -rf ../DAPS-S/Statistical_Methods_Library
    cd .. 
    git clone http://${GITLAB_CREDS_USR}:${GITLAB_CREDS_PSW}@np2rvlapxx507/DAP-S/Statistical_Methods_Library.git
    cd Statistical_Methods_Library
    git checkout origin/master
    """)

    masterTag = sh(returnStdout: true, script: 'cd ../Statistical_Methods_Library && git describe --always').trim()
    sh("rm -rf ../Statistical_Methods_Library")

    regexResult = masterTag.replaceAll(/(\d*)+\.(\d*)+\.(\d*)/, "MasterRelease")

    println "Most recent master tag is: "+masterTag
    println "Most recent tag from "+branchName+" is: "+currentTag
    println "Version number from master tag is: "+masterTag.take(1)
    println "Version number from current tag is: "+currentTag.take(1)

    def fistDigit = masterTag.take(1)
    if (regexResult.startsWith("MasterRelease")) {
        if (massterTag.take(1) > currentTag.take(1)) {
            println "There has been a master deployment, incrementing ${currentTag} to new version: ${firstDigit}.0.0"
            return "${firstDigit}.0.0"

        } else {
            println "There has not been a major release, sticking to current version number: ${currentTag}"
            return currentTag
        }
    } else {
        println "There has never been a major release, sticking to current version number: ${currentTag}"
        return currentTag
    }

}

def getIncrementedTag(currentTag, releaseType)
{
    currentTag = currentTag.replaceAll(/(-DEV|-SNAPSHOT|-NON-RELEASE)/, "")

    def split = currentTag.split('\\.')
    switch (releaseType) {
        case "phase":
            split[2]=Integer.parseInt(split[2]) + 1
            break
        case "non-release":
            split[2]=Integer.parseInt(split[2]) + 1
            break
        case "minor":
            split[1]=Integer.parseInt(split[1]) + 1
            split[2]=0
            break
        case "major":
            split[0]=Integer.parseInt(split[0]) + 1
            split[1]=0
            split[2]=0
            break
    }
    return split.join('.')
}

def updateVersionWithBuildNumber(currentTag,buildNumber)
{
    currentTag = currentTag.replaceAll(/(-SNAPSHOT)/, "")

    def split = currentTag.split('\\.')
    split[2] = buildNumber
    return split.join('.')
}

def releaseTagSuffix(currentTag, gitBranch)
{
    switch (gitBranch){
        case "phase":
            newTag=currentTag+"-DEV"
            break
        case "minor":
            newTag=currentTag+"-SNAPSHOT"
            break
        case "non-release":
            newTag=currentTag+"-NON-RELEASE"
            break
        case "major":
            newTag = currentTag
    }
    return newTag
}

def createSnapshot(newTag, branchName, toBranch, GITLAB_CREDS_USR, GITLAB_CREDS_PSW) {

    sh ("""
        git remote set-url origin http://${GITLAB_CREDS_USR}:${GITLAB_CREDS_PSW}@np2rvlapxx507/DAP-S/Statistical_Methods_Library.git
        """)
    sh  ("""
            git status
            git --version
            git add \\*pom.xml
            git add pom.xml python/MANIFEST.in python/sml/_version.py resources/features/environment.py            
            git commit -m "Changing pom.xml and python versions to most recent version"      
            git status
            git push origin HEAD:refs/heads/${toBranch}
            git tag -a ${newTag} -m 'Jenkins build v${newTag} from ${branchName}'
            git push -f origin refs/tags/${newTag}:refs/tags/${newTag}
			""")

    }


def mvnCommitVersion(newTag) {

        sh ("""
            mvn versions:set -DnewVersion=${newTag} versions:commit -f pom.xml
        """
        )
}

return this



