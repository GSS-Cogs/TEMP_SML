package uk.gov.ons.stepdefs

import uk.gov.ons.methods.TPRCleaning
import cucumber.api.scala.{EN, ScalaDsl}
import org.apache.spark.sql.DataFrame
import cucumber.api.DataTable
import uk.gov.ons.stepdefs.StepsHelper.orderDf
import scala.collection.JavaConversions._


object ContextTPRCleaning {

  var valueCol: String = _
  var markerCol : String = _
  var newCol: String = _
  var resultdf: DataFrame = _
  var expectedData: DataFrame = _
  var inputData: DataFrame = _
  var markerVal: Any = _
  var correctorVal: Int = _
}


class TPRCleaningSteps extends ScalaDsl with EN {
  Given("""the user provides the TPRC function parameters:""") { (x: DataTable) =>
    val inputList = x.asLists(classOf[String])
    ContextCommon.param_list = inputList.get(1).toSeq
    ContextTPRCleaning.inputData = ContextCommon.input_data
    ContextTPRCleaning.valueCol = ContextCommon.param_list(1)
    ContextTPRCleaning.markerCol = ContextCommon.param_list(0)
    ContextTPRCleaning.newCol = ContextCommon.param_list(2)
    ContextTPRCleaning.markerVal = ContextCommon.param_list(3)
    ContextTPRCleaning.correctorVal = ContextCommon.param_list(4).toInt
  }

    When("""^the Scala TPR Cleaning function is applied$"""){ () =>
      ContextCommon.output_data = orderDf(TPRCleaning.cleaning(ContextTPRCleaning.inputData)
        .clean1(ContextTPRCleaning.inputData,ContextTPRCleaning.valueCol, ContextTPRCleaning.markerCol, ContextTPRCleaning.newCol, ContextTPRCleaning.markerVal, ContextTPRCleaning.correctorVal))

    }

      Then("""^the Scala TPR function will Correct records$""") { () =>
        println("Scala TPRC Marked 1 -> outcome:")
        ContextTPRCleaning.inputData.show()
        ContextCommon.expected_data.show()
        ContextCommon.output_data.show()

        assert(ContextCommon.output_data.collect() sameElements ContextCommon.expected_data.collect())

      }

  Then("""^the Scala TPR function will Copy records$""") { () =>
    println("Scala TPRC marked 0 -> outcome:")
    ContextTPRCleaning.inputData.show()
    ContextCommon.expected_data.show()
    ContextCommon.output_data.show()

    assert(ContextCommon.output_data.collect() sameElements ContextCommon.expected_data.collect())

  }
}
