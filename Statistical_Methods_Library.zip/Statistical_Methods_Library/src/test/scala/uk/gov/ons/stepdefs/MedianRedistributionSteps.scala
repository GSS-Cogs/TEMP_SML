package uk.gov.ons.stepdefs

import cucumber.api.scala.{EN, ScalaDsl}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col
import uk.gov.ons.methods.MedianRedistribution


class MedianRedistributionSteps extends ScalaDsl with EN {

  Given("a partition column (.+)$") { (x: String) =>
    ContextMedianRedis.partition_col = x
  }
  Given("a time period column (.+)$") { (x: String) =>
    ContextMedianRedis.time_col = x
  }
  Given("a clean marker column (.+)$") { (x: String) =>
    ContextMedianRedis.marker_col = x
  }
  Given("a record type column (.+)$") { (x: String) =>
    ContextMedianRedis.type_col = x
  }
  Given("a target column (.+)$") { (x: String) =>
    ContextMedianRedis.target_col = x
  }
  Given("unclean values (.+)$") { (x: String) =>
    ContextMedianRedis.unclean_vals = x.split(",").toList
  }
  Given("a output column (.+)$") { (x: String) =>
    ContextMedianRedis.out_col = x
  }
  When("the Scala MedianRedistribution function is applied to the dataset") { () =>
    ContextCommon.output_data = MedianRedistribution
      .medianRedistribution(ContextCommon.input_data)
      .medianRedistributionMethod(
        ContextCommon.input_data,
        ContextMedianRedis.partition_col,
        ContextMedianRedis.time_col,
        ContextMedianRedis.marker_col,
        ContextMedianRedis.type_col,
        ContextMedianRedis.target_col,
        ContextMedianRedis.unclean_vals,
        ContextMedianRedis.out_col)
  }
  Then("the unclean records are altered based on the clean records, the output dataset should " +
    "match the expected dataset") { () =>
    // Order the columns of the output
    ContextCommon.output_data = ContextCommon.orderDf(ContextCommon.output_data)
    // Print the dataframes for clarity
    println("Input Dataframe")
    ContextCommon.input_data.show()
    println("Expected Dataframe")
    ContextCommon.expected_data.show()
    println("Output Dataframe")
    ContextCommon.output_data.show()
    assert(ContextCommon.output_data.collect() sameElements ContextCommon.expected_data.collect())
  }
  Then("the clean records are unaltered") { () =>
    // Step is covered by expected data
  }
  Then("the sum of the target column and output column is the same") { () =>
    // Sum the input target column
    val in_sum: Double = ContextCommon.input_data.select(col(ContextMedianRedis.target_col))
      .rdd.map(_ (0).asInstanceOf[Double]).reduce(_ + _)
    // Sum the output column of the output dataframe
    val out_sum: Double = ContextCommon.output_data.select(col(ContextMedianRedis.target_col))
      .rdd.map(_ (0).asInstanceOf[Double]).reduce(_ + _)

    assert(in_sum == out_sum)
  }
}

object ContextMedianRedis {
  var partition_col: String = _
  var time_col: String = _
  var marker_col: String = _
  var type_col: String = _
  var target_col: String = _
  var unclean_vals: List[String] = _
  var out_col: String = _
}

