package uk.gov.ons.stepdefs

import cucumber.api.DataTable
import cucumber.api.scala.{EN, ScalaDsl}
import org.apache.spark.sql.DataFrame
import uk.gov.ons.methods.Redistribution
import uk.gov.ons.stepdefs.StepsHelper.orderDf

import scala.collection.JavaConversions._

object ContextRedistribution {
  var df: DataFrame = _
  var part_cols: List[String] = _
  var target_col: String = _
  var weights_col: Option[String] = _
  var new_col: String = _
  var outputDF: DataFrame = _
  var expectedDF: DataFrame = _
}

class RedistributionSteps extends ScalaDsl with EN {

  Given("""the user provides the Redistribution function parameters:$""") { (x: DataTable) =>
    val inputList = x.asLists(classOf[String])
    ContextCommon.param_list = inputList.get(1).toSeq
    ContextRedistribution.df = ContextCommon.input_data
    ContextRedistribution.part_cols = ContextCommon.param_list.head.split(",").toList
    ContextRedistribution.target_col = ContextCommon.param_list(1)
    ContextRedistribution.new_col = ContextCommon.param_list(2)
    ContextRedistribution.weights_col = ContextCommon.param_list.lift(3)
    ContextRedistribution.expectedDF = ContextCommon.expected_data
  }

  Given("""the Scala Redistribution function is applied""") { () =>

    if (ContextRedistribution.weights_col.get == "null") {

      ContextRedistribution.outputDF = Redistribution.redistribution(ContextRedistribution.df)
          .redistribute(
            partCols = ContextRedistribution.part_cols,
            targetCol = ContextRedistribution.target_col,
            newCol = ContextRedistribution.new_col
          )
    }
    else {

      ContextRedistribution.outputDF = Redistribution.redistribution(ContextRedistribution.df)
          .redistribute(
            partCols = ContextRedistribution.part_cols,
            targetCol = ContextRedistribution.target_col,
            newCol = ContextRedistribution.new_col,
            weightCol = ContextRedistribution.weights_col)
    }
  }

  Then("""the DataFrame will be redistributed correctly""") { () =>

    println("Scala Output data:")
    ContextRedistribution.outputDF.show()
    println("Scala Expected data:")
    ContextRedistribution.expectedDF.show()

    assert(ContextRedistribution.outputDF.collect() sameElements ContextRedistribution.expectedDF
                                                              .select(ContextRedistribution.outputDF.columns.head,
                                                                ContextRedistribution.outputDF.columns.tail: _*)
                                                                      .collect())
  }
}