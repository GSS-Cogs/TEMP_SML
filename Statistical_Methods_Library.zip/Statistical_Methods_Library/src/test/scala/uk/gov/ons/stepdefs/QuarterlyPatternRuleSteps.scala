package uk.gov.ons.stepdefs


import cucumber.api.scala.{EN, ScalaDsl}
import org.apache.spark.sql.DataFrame
import scala.collection.JavaConversions._
import uk.gov.ons.methods.QuarterlyPatternRule
import cucumber.api.DataTable

object QuarterlyPatternRuleContext {
  var input_data: DataFrame = _
  var partition_cols: Seq[String] = _
  var partition_order_cols: Seq[String] = _
  var partition_list: List[String] = _
  var partition_order_list: List[String] = _
  var comparisonValueColumn: String = _
  var identifierColumn: String = _
  var identifierValue: Seq[Any] = _
}

class QuarterlyPatternRuleSteps extends ScalaDsl with EN {

    And ("""the paramters are provided$""") { (x: DataTable) =>
      val inputList = x.asLists(classOf[String])
      ContextCommon.param_list = inputList.get(1).toSeq
      QuarterlyPatternRuleContext.input_data = ContextCommon.input_data
      QuarterlyPatternRuleContext.partition_cols = ContextCommon.param_list.head.split(",")
      QuarterlyPatternRuleContext.partition_list = QuarterlyPatternRuleContext.partition_cols.toList //ContextCommon.param_list.head.split(",")
      QuarterlyPatternRuleContext.partition_order_cols = ContextCommon.param_list(1).split(",")
      QuarterlyPatternRuleContext.partition_order_list = QuarterlyPatternRuleContext.partition_order_cols.toList //ContextCommon.param_list(1).split(",")
      QuarterlyPatternRuleContext.comparisonValueColumn = ContextCommon.param_list(2) //ContextCommon.param_list(2)
      QuarterlyPatternRuleContext.identifierColumn = ContextCommon.param_list(3) //ContextCommon.param_list(3)
      QuarterlyPatternRuleContext.identifierValue = ContextCommon.param_list(4).split(",")

      println("Params for Scenario:")
      println(QuarterlyPatternRuleContext.partition_list(0))
      println(QuarterlyPatternRuleContext.partition_order_list(0))
      println(QuarterlyPatternRuleContext.comparisonValueColumn)
      println(QuarterlyPatternRuleContext.identifierColumn)
      println(QuarterlyPatternRuleContext.identifierValue(0))
    }

  When ("""we apply the Scala QPR function to the input dataset Scenario A$""") { () =>
    println("When we apply the Scala QPR function to the input dataset Scenario A:")
    println("All four turnovers in the financial year are equal pattern:")
    ContextCommon.output_data = QuarterlyPatternRule.quarterlyPatternRule(QuarterlyPatternRuleContext.input_data).quarterlyPatternRuleMethod(
      ContextCommon.input_data, QuarterlyPatternRuleContext.partition_list,
      QuarterlyPatternRuleContext.partition_order_list, QuarterlyPatternRuleContext.comparisonValueColumn,
      QuarterlyPatternRuleContext.identifierColumn, QuarterlyPatternRuleContext.identifierValue.toList)
    println("Output Data:")
    ContextCommon.output_data.select(
      "test_financial_year", "test_period", "test_stagger",
      "test_turnover", "test_vat_returns_vatref9",
      "lagged_1", "lagged_2", "lagged_3",
      "qpr_pattern"
    ).orderBy("test_vat_returns_vatref9", "test_financial_year", "test_period").show(50)
    println (ContextCommon.output_data.printSchema())
  }

  When ("""we apply the Scala QPR function to the input dataset Scenario B$""") { () =>
    println("When we apply the Scala QPR function to the input dataset Scenario B:")
    println("First three turnover returns in the financial year are equal except final return pattern:")
    ContextCommon.output_data = QuarterlyPatternRule.quarterlyPatternRule(QuarterlyPatternRuleContext.input_data).quarterlyPatternRuleMethod(
      ContextCommon.input_data,
      QuarterlyPatternRuleContext.partition_list,
      QuarterlyPatternRuleContext.partition_order_list,
      QuarterlyPatternRuleContext.comparisonValueColumn,
      QuarterlyPatternRuleContext.identifierColumn,
      QuarterlyPatternRuleContext.identifierValue.toList
    )
    println("Output Data:")
    ContextCommon.output_data.select(
      "test_financial_year", "test_period", "test_stagger",
      "test_turnover", "test_vat_returns_vatref9",
      "lagged_1", "lagged_2", "lagged_3",
      "qpr_pattern"
    ).orderBy("test_vat_returns_vatref9", "test_financial_year", "test_period").show(50)
    println (ContextCommon.output_data.printSchema())
  }

  When ("""we apply the Scala QPR function to the input dataset Scenario C$""") { () =>
    println("When we apply the Scala QPR function to the input dataset Scenario C:")
    println("First three turnover returns in the financial year are zero except final return pattern")
    ContextCommon.output_data = QuarterlyPatternRule.quarterlyPatternRule(QuarterlyPatternRuleContext.input_data).quarterlyPatternRuleMethod(
      ContextCommon.input_data,
      QuarterlyPatternRuleContext.partition_list,
      QuarterlyPatternRuleContext.partition_order_list,
      QuarterlyPatternRuleContext.comparisonValueColumn,
      QuarterlyPatternRuleContext.identifierColumn,
      QuarterlyPatternRuleContext.identifierValue.toList
    )
    println("Output Data:")
    ContextCommon.output_data.select(
      "test_financial_year", "test_period", "test_stagger",
      "test_turnover", "test_vat_returns_vatref9",
      "lagged_1", "lagged_2", "lagged_3",
      "qpr_pattern"
    ).orderBy("test_vat_returns_vatref9", "test_financial_year", "test_period").show(50)
    println (ContextCommon.output_data.printSchema())
  }

  Then ("""the Scala QPR function correctly flags the record where the scenario pattern is identified$""") { () =>
    println("Expected Data:")
    ContextCommon.expected_data.select(
      "test_financial_year", "test_period", "test_stagger",
      "test_turnover", "test_vat_returns_vatref9",
      "lagged_1", "lagged_2", "lagged_3",
      "qpr_pattern"
    ).orderBy("test_vat_returns_vatref9", "test_financial_year", "test_period").show(50)
    println (ContextCommon.expected_data.printSchema())

    assert(ContextCommon.expected_data.select(
      "test_financial_year", "test_period", "test_stagger",
      "test_turnover", "test_vat_returns_vatref9",
      "lagged_1", "lagged_2", "lagged_3",
      "qpr_pattern"
    ).orderBy("test_vat_returns_vatref9", "test_period").collect()
      sameElements
      ContextCommon.output_data.select(
        "test_financial_year", "test_period", "test_stagger",
        "test_turnover", "test_vat_returns_vatref9",
        "lagged_1", "lagged_2", "lagged_3",
        "qpr_pattern"
      ).orderBy("test_vat_returns_vatref9", "test_period").collect()
    )
  }
}