package uk.gov.ons.stepdefs

import cucumber.api.DataTable
import cucumber.api.scala.{EN, ScalaDsl}
import org.apache.spark.sql.DataFrame
import uk.gov.ons.methods.Imputation
import uk.gov.ons.stepdefs.StepsHelper.orderDf

import scala.collection.JavaConversions._


object ContextImputation {
  var input_data: DataFrame = _
  var part_cols: List[String] = _
  var unit_col: String = _
  var time_col: String = _
  var target_col: String = _
  var aux_col: String = _
  var output_col: String = _
  var marker_col: String = _
  var lang: String = _
}

class ImputationSteps extends ScalaDsl with EN {
  Given("""the user provides the Imputation function parameters:$""") { (x: DataTable) =>
    val inputList = x.asLists(classOf[String])
    ContextCommon.param_list = inputList.get(1).toSeq
    ContextImputation.input_data = ContextCommon.input_data
    ContextImputation.part_cols = ContextCommon.param_list.head.split(",").toList
    ContextImputation.unit_col = ContextCommon.param_list(1)
    ContextImputation.time_col = ContextCommon.param_list(2)
    ContextImputation.target_col = ContextCommon.param_list(3)
    ContextImputation.aux_col = ContextCommon.param_list(4)
    ContextImputation.output_col = ContextCommon.param_list(5)
    ContextImputation.marker_col = ContextCommon.param_list(6)
  }

  Given("""the Scala Imputation function is applied""") { () =>
    ContextImputation.lang = "Scala"
    ContextCommon.output_data = orderDf(
      Imputation.imputation(ContextImputation.input_data)
        .impute(ContextImputation.input_data,
          ContextImputation.part_cols,
          ContextImputation.unit_col,
          ContextImputation.time_col,
          ContextImputation.target_col,
          ContextImputation.output_col,
          ContextImputation.marker_col,
          ContextImputation.aux_col)
    ).orderBy("time", "id")
  }

  Then("""the DataFrame will be imputed correctly""") { () =>

    println("Input Data")
    ContextImputation.input_data.show()
    println("Expected Output")
    ContextCommon.expected_data.show()
    println(ContextImputation.lang + " Imputation output")
    ContextCommon.output_data.show()

    assert(ContextCommon.output_data.collect() sameElements ContextCommon.expected_data.collect())
  }

}
