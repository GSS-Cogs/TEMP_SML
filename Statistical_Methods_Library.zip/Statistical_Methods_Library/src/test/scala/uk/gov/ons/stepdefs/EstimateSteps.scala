package uk.gov.ons.stepdefs

import cucumber.api.DataTable
import cucumber.api.scala.{EN, ScalaDsl}
import org.apache.spark.sql.DataFrame
import uk.gov.ons.methods.Estimation

import scala.collection.JavaConversions._

object ContextEstimation {

  var df: DataFrame = _
  var targetColumn: String = _
  var auxiliaryColumn: String = _
  var strataColumn: Option[String] = _
  var isTrimmed: Boolean = _
  var outDF: DataFrame = _
  var expectedDF: DataFrame = _
}

class EstimationSteps extends ScalaDsl with EN {

  Given("""^the user provides the estimateWeightByExpansion function parameters:$""") { (x: DataTable) =>

    val inputList = x.asLists(classOf[String])

    ContextCommon.param_list = inputList.get(1).toSeq

    ContextEstimation.targetColumn = ContextCommon.param_list.head
    ContextEstimation.strataColumn = ContextCommon.param_list.lift(1)
    ContextEstimation.isTrimmed = ContextCommon.param_list(2).contains("true")
    ContextEstimation.df = ContextCommon.input_data
    ContextEstimation.expectedDF = ContextCommon.expected_data

    println("Given the user provides the estimateWeightByExpansion function parameters: " + inputList)
  }

  Given("""^the user provides the estimateWeightByRatio function parameters:$""") { (x: DataTable) =>

    val inputList = x.asLists(classOf[String])

    ContextCommon.param_list = inputList.get(1).toSeq

    ContextEstimation.targetColumn = ContextCommon.param_list.head
    ContextEstimation.auxiliaryColumn = ContextCommon.param_list(1)
    ContextEstimation.strataColumn = ContextCommon.param_list.lift(2)
    ContextEstimation.isTrimmed = ContextCommon.param_list(3).contains("true")
    ContextEstimation.df = ContextCommon.input_data
    ContextEstimation.expectedDF = ContextCommon.expected_data

    println("Given the user provides the estimateByRatio function parameters: " + inputList)
  }

  When("""^the Scala estimateWeightByExpansion function is applied.$""") { () =>

    if (ContextEstimation.strataColumn.get == "null") {
      ContextEstimation.outDF = Estimation.estimation(ContextEstimation.df)
                                          .estimateWeightByExpansion(targetColumn = ContextEstimation.targetColumn,
                                                                     isTrimmed = ContextEstimation.isTrimmed)
    }
    else {
      ContextEstimation.outDF = Estimation.estimation(ContextEstimation.df)
                                          .estimateWeightByExpansion(targetColumn = ContextEstimation.targetColumn,
                                                                     strataColumn = ContextEstimation.strataColumn,
                                                                     isTrimmed = ContextEstimation.isTrimmed)
    }

    println("When the Scala estimateWeightByExpansion function is applied.")
  }

  When("""^the Scala estimateWeightByRatio function is applied.$""") { () =>

    if (ContextEstimation.strataColumn.get == "null") {
      ContextEstimation.outDF = Estimation.estimation(ContextEstimation.df)
                                          .estimateWeightByRatio(auxiliaryColumn = ContextEstimation.auxiliaryColumn,
                                                                 targetColumn = ContextEstimation.targetColumn,
                                                                 isTrimmed = ContextEstimation.isTrimmed)
    }
    else {
      ContextEstimation.outDF = Estimation.estimation(ContextEstimation.df)
                                          .estimateWeightByRatio(targetColumn = ContextEstimation.targetColumn,
                                                                 auxiliaryColumn = ContextEstimation.auxiliaryColumn,
                                                                 strataColumn = ContextEstimation.strataColumn,
                                                                 isTrimmed = ContextEstimation.isTrimmed)
    }

    println("When the Scala estimateWeightByRatio function is applied.")
  }

  Then("""^the target column will be extrapolated to estimate a total.$""") { () =>

    println("Output data:")
    ContextEstimation.outDF.show(30)

    println("Expected data:")
    ContextEstimation.expectedDF.select(ContextEstimation.outDF.columns.head,
                                        ContextEstimation.outDF.columns.tail: _*).show(30)

    assert(ContextEstimation.outDF.collect() sameElements  ContextEstimation.expectedDF
                                                                            .select(ContextEstimation.outDF.columns.head,
                                                                                    ContextEstimation.outDF.columns.tail: _*)
                                                                            .collect())

    println("Then the target column will be extrapolated to estimate a total.")
  }
}
