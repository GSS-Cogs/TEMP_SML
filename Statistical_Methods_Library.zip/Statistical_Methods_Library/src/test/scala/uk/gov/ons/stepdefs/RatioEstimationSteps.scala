package uk.gov.ons.stepdefs

import cucumber.api.DataTable
import cucumber.api.scala.{EN, ScalaDsl}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql
import org.apache.spark.sql.catalyst.optimizer.EliminateSerialization
import org.apache.spark.sql.functions.round
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, functions => F}
import org.apache.spark.sql.functions.round

import scala.collection.JavaConversions._
import uk.gov.ons.methods.RatioEstimation

object Estimation_by_RatioContext {
  var input_data_sample: DataFrame = _
  var input_data_population: DataFrame = _
  var grouping_classification: String = _
  var reporting_period: String = _
  var auxiliary_variable: String = _
  var focus: String = _
  var target: String = _
  var population_grouping_classification: String = _
  var population_reporting_period: String = _
  var population_auxiliary_variable: String = _
  var population_focus: String = _
  var flagging_exclude: String = _
  var expected_data_focus: DataFrame = _
  var expected_data_grouping_classification: DataFrame = _
}


class Estimation_by_RatioSteps extends ScalaDsl with EN {

  val input_data_schema_sample = new StructType()
    .add("grouping_classification", StringType, nullable = false)
    .add("reporting_period", StringType, nullable = false)
    .add("auxiliary_variable", StringType, nullable = false)
    .add("focus", StringType, nullable = false)
    .add("turnover", LongType, nullable = true)
    .add("complexity", StringType, nullable = true)

  val input_data_schema_population = new StructType()
    .add("population_grouping_classification", StringType, nullable = false)
    .add("population_reporting_period", StringType, nullable = false)
    .add("population_auxiliary_variable", StringType, nullable = false)
    .add("population_focus", StringType, nullable = false)
    .add("population_complexity", StringType, nullable = true)

  val expected_data_schema_focus = new StructType()
    .add("grouping_classification", StringType, nullable = true)
    .add("reporting_period", StringType, nullable = true)
    .add("auxiliary_variable", StringType, nullable = true)
    .add("focus", StringType, nullable = true)
    .add("turnover", LongType, nullable = true)
    .add("complexity", StringType, nullable = true)
    .add("population_grouping_classification", StringType, nullable = true)
    .add("population_reporting_period", StringType, nullable = true)
    .add("count_of_focus_sample", LongType, nullable = true)
    .add("sum_of_auxiliary_variable_sample", DoubleType, nullable = true)
    .add("sum_of_auxiliary_variable_population", DoubleType, nullable = true)
    .add("sum_of_target_sample", LongType, nullable = true)
    .add("count_of_focus_population", LongType, nullable = false)
    .add("grouping_classification_beta", StringType, nullable = true)
    .add("reporting_period_beta", StringType, nullable = true)
    .add("ratio_estimation_flag", IntegerType, nullable = true)
    .add("beta_grouping_classification", DoubleType, nullable = true)
    .add("estimated_target_by_grouping_classification", DoubleType, nullable = true)
    .add("residual_target_by_grouping_classification", DoubleType, nullable = true)

  val expected_data_schema_grouping_classification = new StructType()
    .add("grouping_classification", StringType, nullable = true)
    .add("reporting_period", StringType, nullable = true)
    .add("sum_of_auxiliary_variable_sample", DoubleType, nullable = true)
    .add("sum_of_auxiliary_variable_population", DoubleType, nullable = true)
    .add("sum_of_target_sample", LongType, nullable = true)
    .add("count_of_focus_sample", LongType, nullable = true)
    .add("count_of_focus_population", LongType, nullable = false)
    .add("ratio_estimation_flag", IntegerType, nullable = false)
    .add("beta_grouping_classification", DoubleType, nullable = true)
    .add("estimated_turnover_by_grouping_population", DoubleType, nullable = true)
    .add("sum_of_Sqr_DeltaRft", DoubleType, nullable = true)
    .add("root_sum_sqr", DoubleType, nullable = true)
    .add("standard_error", DoubleType, nullable = true)
    .add("final_target", DoubleType, nullable = true)

  //JSON file only in this common execution:
  Given("""there is an input dataset LOAD$""") { (x: DataTable) =>
    val pathList = x.asLists(classOf[String])
    val inputPathSample: String = pathList.get(1).get(0)
    val inputPathPopulation: String = pathList.get(1).get(1)
    val expectedPathFocus: String = pathList.get(1).get(2)
    val expectedPathGroupingClassification: String = pathList.get(1).get(3)
    println("   Input Path identified in Scala Common Steps: " + inputPathSample)
    println("   Input Path identified in Scala Common Steps: " + inputPathPopulation)
    println("Expected Path identified in Scala Common Steps: " + expectedPathFocus)
    println("Expected Path identified in Scala Common Steps: " + expectedPathGroupingClassification)
    Estimation_by_RatioContext.input_data_sample = Helpers.sparkSession.read.schema(input_data_schema_sample).json(inputPathSample)
    Estimation_by_RatioContext.input_data_population = Helpers.sparkSession.read.schema(input_data_schema_population).json(inputPathPopulation)
    Estimation_by_RatioContext.expected_data_focus = Helpers.sparkSession.read.schema(expected_data_schema_focus).json(expectedPathFocus)
    Estimation_by_RatioContext.expected_data_grouping_classification = Helpers.sparkSession.read.schema(expected_data_schema_grouping_classification).json(expectedPathGroupingClassification)
    println("Input Data:")
    println(Estimation_by_RatioContext.input_data_sample.printSchema())
    Estimation_by_RatioContext.input_data_sample.select(
      "focus", "reporting_period",
      "auxiliary_variable", "grouping_classification",
      "turnover", "complexity"
    ).orderBy("focus", "reporting_period").show(50)
    Estimation_by_RatioContext.input_data_population.select(
      "population_focus", "population_reporting_period",
      "population_auxiliary_variable", "population_grouping_classification",
      "population_complexity"
    ).orderBy("population_focus", "population_reporting_period").show(50)
  }

  Given("""there is an input dataset$""") { (x: DataTable) =>
    println("Data already loaded for inputs via GIVEN with LOAD")
  }
  And("""an auxiliary variable is provided$""") { (x: DataTable) =>

    val inputList = x.asLists(classOf[String])
    ContextCommon.param_list = inputList.get(1).toSeq
    //Set Params:
    Estimation_by_RatioContext.input_data_sample = Estimation_by_RatioContext.input_data_sample
    Estimation_by_RatioContext.input_data_population = Estimation_by_RatioContext.input_data_population
    Estimation_by_RatioContext.grouping_classification = ContextCommon.param_list.head
    Estimation_by_RatioContext.reporting_period = ContextCommon.param_list(1)
    Estimation_by_RatioContext.auxiliary_variable = ContextCommon.param_list(2)
    Estimation_by_RatioContext.focus = ContextCommon.param_list(3)
    Estimation_by_RatioContext.target = ContextCommon.param_list(4)
    Estimation_by_RatioContext.population_grouping_classification = ContextCommon.param_list(5)
    Estimation_by_RatioContext.population_reporting_period = ContextCommon.param_list(6)
    Estimation_by_RatioContext.population_auxiliary_variable = ContextCommon.param_list(7)
    Estimation_by_RatioContext.population_focus = ContextCommon.param_list(8)
    Estimation_by_RatioContext.flagging_exclude = ContextCommon.param_list(9)

    //Confirm Params:
    println("Params for Scenario:")
    println(Estimation_by_RatioContext.grouping_classification + " - grouping_classification")
    println(Estimation_by_RatioContext.reporting_period + " - reporting_period")
    println(Estimation_by_RatioContext.auxiliary_variable + " - auxiliary_variable")
    println(Estimation_by_RatioContext.focus + " - focus")
    println(Estimation_by_RatioContext.target + " - target")
    println(Estimation_by_RatioContext.population_grouping_classification + " - population_grouping_classification")
    println(Estimation_by_RatioContext.population_reporting_period + " - population_reporting_period")
    println(Estimation_by_RatioContext.population_auxiliary_variable + " - population_auxiliary_variable")
    println(Estimation_by_RatioContext.population_focus + " - population_focus")
    println(Estimation_by_RatioContext.flagging_exclude + " - flagging_exclude")

  }


  And("""a ratio has been calculated$""") { (x: DataTable) =>
    println("Checking a ratio has been calculated:")
  }


  And("""estimated turnover for RU and cell have both been calculated$""") { (x: DataTable) =>
    println("Checking estimated turnover has been calculated:")
  }


  When("""we apply the Scala function to the dataset$""") { () =>

    println("When we apply the Scala function to the dataset:")
    ContextCommon.output_data = RatioEstimation.ratioEstimation(Estimation_by_RatioContext.input_data_sample)
      .ratioEstimationMethod(
        Estimation_by_RatioContext.input_data_sample, Estimation_by_RatioContext.input_data_population,
        Estimation_by_RatioContext.grouping_classification, Estimation_by_RatioContext.reporting_period,
        Estimation_by_RatioContext.auxiliary_variable, Estimation_by_RatioContext.focus,
        Estimation_by_RatioContext.target,
        Estimation_by_RatioContext.population_grouping_classification, Estimation_by_RatioContext.population_reporting_period,
        Estimation_by_RatioContext.population_auxiliary_variable, Estimation_by_RatioContext.population_focus,
        true, Estimation_by_RatioContext.flagging_exclude
      )

    ContextCommon.output_data.select(
      "grouping_classification", "reporting_period", "auxiliary_variable", "focus", "turnover", "complexity",
      "population_grouping_classification", "population_reporting_period",
      "count_of_focus_sample", "sum_of_auxiliary_variable_sample", "sum_of_auxiliary_variable_population",
      "sum_of_target_sample", "count_of_focus_population",
      "grouping_classification_beta", "reporting_period_beta",
      "ratio_estimation_flag", "beta_grouping_classification",
      "estimated_target_by_grouping_classification", "residual_target_by_grouping_classification"
    ).orderBy("grouping_classification", "reporting_period").show(50)
    println("Schema - Estimation by Focus (Reporting Unit):")
    println(ContextCommon.output_data.printSchema())


  }


  When("""the ratio is multiplied by the Scala auxiliary variable$""") { () =>
    println("When the ratio is multiplied by the Scala auxiliary variable:")
    println("(Achieved via primary scenario...)")
  }


  When("""the ratio is multiplied by the Scala sum of the auxiliary variable for population$""") { () =>
    println("When the ratio is multiplied by the Scala sum of the auxiliary variable for population:")
    ContextCommon.output_data = RatioEstimation.ratioEstimation(Estimation_by_RatioContext.input_data_sample)
      .ratioEstimationMethod(
        Estimation_by_RatioContext.input_data_sample, Estimation_by_RatioContext.input_data_population,
        Estimation_by_RatioContext.grouping_classification, Estimation_by_RatioContext.reporting_period,
        Estimation_by_RatioContext.auxiliary_variable, Estimation_by_RatioContext.focus,
        Estimation_by_RatioContext.target,
        Estimation_by_RatioContext.population_grouping_classification, Estimation_by_RatioContext.population_reporting_period,
        Estimation_by_RatioContext.population_auxiliary_variable, Estimation_by_RatioContext.population_focus,
        false, Estimation_by_RatioContext.flagging_exclude
      )
  }


  When("""the sum of squares of difference Scala calculation is applied$""") { () =>
    println("When the sum of squares of difference Scala calculation is applied:")
    println("(Achieved via primary scenario...)")
  }


  Then("""the sum of the turnover sample is divided by the auxiliary sample and a ratio is produced by the Scala process$""") { () =>

    println("Showing output data first, then expected data and associated schemas:")
    ContextCommon.output_data.select(
      "focus", "reporting_period", "grouping_classification", "auxiliary_variable", "turnover",
      "sum_of_auxiliary_variable_sample", "sum_of_auxiliary_variable_population",
      "sum_of_target_sample", "count_of_focus_population"
    ).orderBy("focus", "reporting_period", "grouping_classification").show(50)

    Estimation_by_RatioContext.expected_data_focus.select(
      "focus", "reporting_period", "grouping_classification", "auxiliary_variable", "turnover",
      "sum_of_auxiliary_variable_sample", "sum_of_auxiliary_variable_population",
      "sum_of_target_sample", "count_of_focus_population"
    ).orderBy("focus", "reporting_period", "grouping_classification").show(50)

    ContextCommon.output_data.printSchema()
    Estimation_by_RatioContext.expected_data_focus.printSchema()

    assert(Estimation_by_RatioContext.expected_data_focus.select(
      "focus", "reporting_period", "grouping_classification", "auxiliary_variable", "turnover",
      "sum_of_auxiliary_variable_sample", "sum_of_auxiliary_variable_population",
      "sum_of_target_sample", "count_of_focus_population"
    ).orderBy("focus", "reporting_period", "grouping_classification").collect()

      sameElements

      ContextCommon.output_data.select(
        "focus", "reporting_period", "grouping_classification", "auxiliary_variable", "turnover",
        "sum_of_auxiliary_variable_sample", "sum_of_auxiliary_variable_population",
        "sum_of_target_sample", "count_of_focus_population"
      ).orderBy("focus", "reporting_period", "grouping_classification").collect()
    )


  }


  Then("""the Scala estimated turnover for reporting unit is produced$""") { () =>
    println("Then the Scala estimated turnover for reporting unit is produced:")

    val focus_expected_part1: DataFrame = Estimation_by_RatioContext.expected_data_focus.select("focus", "reporting_period",
      "grouping_classification", "beta_grouping_classification", "estimated_target_by_grouping_classification")
    val focus_output_part1: DataFrame = ContextCommon.output_data.select("focus", "reporting_period", "grouping_classification",
      "beta_grouping_classification", "estimated_target_by_grouping_classification")
    val focus_expected_part2: DataFrame = focus_expected_part1.withColumn("beta_grouping_classification_new",
      F.col("beta_grouping_classification").cast(DecimalType(25, 3))).withColumn("estimated_target_by_grouping_classification_new",
      F.col("estimated_target_by_grouping_classification").cast(DecimalType(25, 3))).drop("beta_grouping_classification", "estimated_target_by_grouping_classification")
    val focus_output_part2: DataFrame = focus_output_part1.withColumn("beta_grouping_classification_new",
      F.col("beta_grouping_classification").cast(DecimalType(25, 3))).withColumn("estimated_target_by_grouping_classification_new",
      F.col("estimated_target_by_grouping_classification").cast(DecimalType(25, 3))).drop("beta_grouping_classification", "estimated_target_by_grouping_classification")

    println("Data for Focus (including Double data types that have been cast to Decimal(25,3)):")
    println("Showing output data first, then expected data and associated schemas:")
    focus_expected_part2.select("focus", "reporting_period", "grouping_classification", "beta_grouping_classification_new", "estimated_target_by_grouping_classification_new")
      .orderBy("focus", "reporting_period", "grouping_classification").show(50)
    focus_output_part2.select("focus", "reporting_period", "grouping_classification", "beta_grouping_classification_new", "estimated_target_by_grouping_classification_new")
      .orderBy("focus", "reporting_period", "grouping_classification").show(50)
    focus_expected_part2.printSchema()
    focus_output_part2.printSchema()

    assert(focus_expected_part2.select("focus", "reporting_period", "grouping_classification", "beta_grouping_classification_new", "estimated_target_by_grouping_classification_new")
      .orderBy("focus", "reporting_period", "grouping_classification").collect()
      sameElements
      focus_output_part2.select("focus", "reporting_period", "grouping_classification", "beta_grouping_classification_new", "estimated_target_by_grouping_classification_new")
        .orderBy("focus", "reporting_period", "grouping_classification").collect())


  }


  Then("""the Scala estimated turnover cell is produced$""") { () =>
    println("Then the Scala estimated turnover cell is produced:")

    //Cast for Double Data Precision - Assert may fail otherwise...
    val grouping_classification_expected_part1: DataFrame = Estimation_by_RatioContext.expected_data_grouping_classification.select(
      "reporting_period", "grouping_classification", "beta_grouping_classification", "final_target")
    val grouping_classification_output_part1: DataFrame = ContextCommon.output_data.select(
      "reporting_period", "grouping_classification", "beta_grouping_classification", "final_target")
    val grouping_classification_expected_part2: DataFrame = grouping_classification_expected_part1.withColumn(
      "beta_grouping_classification_new", F.col("beta_grouping_classification").cast(DecimalType(25, 3)))
      .withColumn("final_target_new", F.col("final_target").cast(DecimalType(25, 3))).drop("beta_grouping_classification", "final_target")
    val grouping_classification_output_part2: DataFrame = grouping_classification_output_part1
      .withColumn("beta_grouping_classification_new", F.col("beta_grouping_classification").cast(DecimalType(25, 3)))
      .withColumn("final_target_new", F.col("final_target").cast(DecimalType(25, 3))).drop("beta_grouping_classification", "final_target")

    println("Data for Grouping Classification (including Double data types that have been cast to Decimal(25,3)):")
    println("Showing output data first, then expected data and associated schemas:")
    grouping_classification_expected_part2.select("reporting_period", "grouping_classification", "beta_grouping_classification_new", "final_target_new")
      .orderBy("reporting_period", "grouping_classification").show(50)
    grouping_classification_output_part2.select("reporting_period", "grouping_classification", "beta_grouping_classification_new", "final_target_new")
      .orderBy("reporting_period", "grouping_classification").show(50)
    grouping_classification_expected_part2.printSchema()
    grouping_classification_output_part2.printSchema()

    assert(grouping_classification_expected_part2.select("reporting_period", "grouping_classification", "beta_grouping_classification_new", "final_target_new")
      .orderBy("reporting_period", "grouping_classification").collect()
      sameElements
      grouping_classification_output_part2.select("reporting_period", "grouping_classification", "beta_grouping_classification_new", "final_target_new")
        .orderBy("reporting_period", "grouping_classification").collect())


  }


  Then("""the Scala uncertainty of the estimation is produced$""") { () =>
    println("Then the Scala uncertainty of the estimation is produced:")

    //Cast for Double Data Precision - Assert may fail otherwise...
    val uncertainty_expected_part1: DataFrame = Estimation_by_RatioContext.expected_data_grouping_classification.select("reporting_period", "grouping_classification", "standard_error")
    val uncertainty_output_part1: DataFrame = ContextCommon.output_data.select("reporting_period", "grouping_classification", "standard_error")
    val uncertainty_expected_part2: DataFrame = uncertainty_expected_part1.withColumn("standard_error_new", F.col("standard_error").cast(DecimalType(25, 3))).drop("standard_error")
    val uncertainty_output_part2: DataFrame = uncertainty_output_part1.withColumn("standard_error_new", F.col("standard_error").cast(DecimalType(25, 3))).drop("standard_error")

    println("Data for Grouping Classification (including Double data types that have been cast to Decimal(25,3)):")
    println("Showing output data first, then expected data and associated schemas:")
    uncertainty_expected_part2.select("reporting_period", "grouping_classification", "standard_error_new").orderBy("reporting_period", "grouping_classification").show(50)
    uncertainty_output_part2.select("reporting_period", "grouping_classification", "standard_error_new").orderBy("reporting_period", "grouping_classification").show(50)
    uncertainty_expected_part2.printSchema()
    uncertainty_output_part2.printSchema()

    assert(uncertainty_expected_part2.select("reporting_period", "grouping_classification", "standard_error_new")
      .orderBy("reporting_period", "grouping_classification").collect()
      sameElements
      uncertainty_output_part2.select("reporting_period", "grouping_classification", "standard_error_new")
        .orderBy("reporting_period", "grouping_classification").collect())

  }
}
