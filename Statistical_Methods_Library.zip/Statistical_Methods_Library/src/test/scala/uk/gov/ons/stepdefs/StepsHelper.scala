package uk.gov.ons.stepdefs

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.{StructField, StructType}
import org.apache.spark.sql.{DataFrame, SQLContext}
import org.apache.spark.{SparkConf, SparkContext}

object StepsHelper {

  def orderDf(df: DataFrame): DataFrame = {
    val cols: Seq[String] =  df.columns.sorted
    df.select(cols.head, cols.tail: _*)
  }

  /**
    * Set nullable property of column.
    * @param df source DataFrame
    * @param colName is the column name to change
    * @param nullable is the flag to set the nullability
    */
  def setNullableStateOfColumn(df: DataFrame, colName: String, nullable: Boolean): DataFrame = {

    // Modify [[StructField] with name 'colName'
    val schema = df.schema
    val newSchema = StructType(schema.map {
      case StructField( c, t, _, m) if c.equals(colName) => StructField( c, t, nullable = nullable, m)
      case y: StructField => y
    })

    // Apply new schema
    df.sqlContext.createDataFrame( df.rdd, newSchema )
  }
}
