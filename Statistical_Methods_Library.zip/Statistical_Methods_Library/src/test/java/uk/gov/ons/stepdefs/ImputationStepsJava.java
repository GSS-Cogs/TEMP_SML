package uk.gov.ons.stepdefs;

import cucumber.api.java.en.When;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import scala.collection.convert.WrapAsJava$;
import uk.gov.ons.api.java.methods.ImputationFactory;

import java.util.ArrayList;

public class ImputationStepsJava {
    private Dataset<Row> inputDS = ContextImputation.input_data();

    @When("the Java Imputation function is applied")
    public void java_imputation_called() throws Exception {
        ContextImputation.lang_$eq("Java");
        Dataset<Row> outDS = Helpers.orderDf(ImputationFactory
                .imputation(inputDS)
                .impute(inputDS,
                        new ArrayList<>(WrapAsJava$.MODULE$.seqAsJavaList(ContextImputation.part_cols())),
                        ContextImputation.unit_col(),
                        ContextImputation.time_col(),
                        ContextImputation.target_col(),
                        ContextImputation.output_col(),
                        ContextImputation.marker_col(),
                        ContextImputation.aux_col()
                ).orderBy("time", "id")
        );
        ContextCommon.output_data_$eq(outDS);
    }
}
