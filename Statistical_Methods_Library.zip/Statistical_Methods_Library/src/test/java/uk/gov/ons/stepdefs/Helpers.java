package uk.gov.ons.stepdefs;

import org.apache.spark.sql.Column;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.SparkSession;

import java.util.Arrays;
import java.util.Comparator;

public class Helpers {
    public static SparkSession sparkSession = null;

    public static Dataset orderDf(Dataset df){
        Column[] cols = Arrays
                .stream(df.columns())
                .sorted(Comparator.naturalOrder())
                .map(df::col)
                .toArray(Column[]::new);
        return df.select(cols);
    }
}
