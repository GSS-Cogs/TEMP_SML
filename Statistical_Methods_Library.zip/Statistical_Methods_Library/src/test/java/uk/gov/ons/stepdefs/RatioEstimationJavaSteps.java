package uk.gov.ons.stepdefs;

import cucumber.api.java.en.When;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.Row$;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Decimal;
import org.apache.spark.sql.types.DecimalType;
import org.apache.spark.sql.types.DecimalType$;
import scala.Tuple2;
import uk.gov.ons.api.java.methods.RatioEstimationFactory;
import cucumber.api.java.en.Then;

import java.math.BigDecimal;
import java.math.RoundingMode;

import static org.junit.Assert.assertEquals;

public class RatioEstimationJavaSteps {

    //Tuple2<Dataset<Row>, Dataset<Row>> output_data_1;
    Dataset<Row> output_data_1;

    Dataset<Row> in_df = Estimation_by_RatioContext.input_data_sample();

    public void ebr_call(Dataset<Row> inputDf, Boolean flag) throws Exception {
        output_data_1 = RatioEstimationFactory.ratioEstimation(inputDf).Ratio_Estimation_Method(
                //ContextCommon.output_data_$eq() = RatioEstimationFactory.ratioEstimation(inputDf).Ratio_Estimation_Method(
                inputDf,
                Estimation_by_RatioContext.input_data_population(),
                Estimation_by_RatioContext.grouping_classification(),
                Estimation_by_RatioContext.reporting_period(),
                Estimation_by_RatioContext.auxiliary_variable(),
                Estimation_by_RatioContext.focus(),
                Estimation_by_RatioContext.target(),
                Estimation_by_RatioContext.population_grouping_classification(),
                Estimation_by_RatioContext.population_reporting_period(),
                Estimation_by_RatioContext.population_auxiliary_variable(),
                Estimation_by_RatioContext.population_focus(),
                flag,
                Estimation_by_RatioContext.flagging_exclude()
        );

        System.out.println("Java Steps Output Data and Schema:");

        System.out.println(output_data_1);
        ContextCommon.output_data_$eq(output_data_1);

    }


    @When("we apply the Java function to the dataset$")
    public void we_apply_the_Java_EbR_function_to_the_dataset() throws Exception {
        ebr_call(in_df, true);
    }


    @When("the ratio is multiplied by the Java auxiliary variable$")
    public void the_ratio_is_multiplied_by_the_Java_auxiliary_variable() throws Exception {
        System.out.println("When the ratio is multiplied by the Java auxiliary variable");
        System.out.println("(Achieved via primary scenario...)");
    }


    @When("the ratio is multiplied by the Java sum of the auxiliary variable for population$")
    public void the_ratio_is_multiplied_by_the_Java_sum_of_the_auxiliary_variable_for_population() throws Exception {
        System.out.println("When the ratio is multiplied by the Java auxiliary variable:");
        ebr_call(in_df, false);
    }


    @When("the sum of squares of difference Java calculation is applied$")
    public void the_sum_of_squares_of_difference_Java_calculation_is_applied() throws Exception {
        System.out.println("When the sum of squares of difference Java calculation is applied:");
        System.out.println("(Achieved via third When scenario...)");
    }


    @Then("the sum of the turnover sample is divided by the auxiliary sample and a ratio is produced by the Java process$")
    public void the_sum_of_the_turnover_sample_is_divided_by_the_auxiliary_sample_and_a_ratio_is_produced_by_the_Java_process() throws Exception {
        Dataset<Row> expected_ratioprod_df = Estimation_by_RatioContext.expected_data_focus();
        Dataset<Row> output_ratioprod_df = ContextCommon.output_data();

        System.out.println("Showing output data first, then expected data and associated schemas:");

        output_ratioprod_df.select(
                "focus", "reporting_period", "grouping_classification", "auxiliary_variable", "turnover",
                "sum_of_auxiliary_variable_sample", "sum_of_auxiliary_variable_population",
                "sum_of_target_sample", "count_of_focus_population"
        ).orderBy("focus", "reporting_period", "grouping_classification").show(50);
        output_ratioprod_df.printSchema();
        expected_ratioprod_df.select(
                "focus", "reporting_period", "grouping_classification", "auxiliary_variable", "turnover",
                "sum_of_auxiliary_variable_sample", "sum_of_auxiliary_variable_population",
                "sum_of_target_sample", "count_of_focus_population"
        ).orderBy("focus", "reporting_period", "grouping_classification").show(50);
        expected_ratioprod_df.printSchema();

        assertEquals(
                output_ratioprod_df.select(
                        "focus", "reporting_period", "grouping_classification", "auxiliary_variable", "turnover",
                        "sum_of_auxiliary_variable_sample", "sum_of_auxiliary_variable_population",
                        "sum_of_target_sample", "count_of_focus_population"
                ).orderBy("focus", "reporting_period", "grouping_classification").collectAsList()
                ,
                expected_ratioprod_df.select(
                        "focus", "reporting_period", "grouping_classification", "auxiliary_variable", "turnover",
                        "sum_of_auxiliary_variable_sample", "sum_of_auxiliary_variable_population",
                        "sum_of_target_sample", "count_of_focus_population"
                ).orderBy("focus", "reporting_period", "grouping_classification").collectAsList()
        );

    }


    @Then("the Java estimated turnover for reporting unit is produced$")
    public void the_Java_estimated_turnover_for_reporting_unit_is_produced() throws Exception {
        Dataset<Row> expected_estturnru_df = Estimation_by_RatioContext.expected_data_focus();
        //Dataset<Row> output__estturnru_df = ContextCommon.output_data()._1;
        Dataset<Row> output__estturnru_df = ContextCommon.output_data();

        System.out.println("Showing output data first, then expected data and associated schemas:");

        expected_estturnru_df = expected_estturnru_df.withColumn(
                "beta_grouping_classification", expected_estturnru_df.col("beta_grouping_classification")
                        .cast(new DecimalType(25,3)));
        expected_estturnru_df = expected_estturnru_df.withColumn(
                "estimated_target_by_grouping_classification", expected_estturnru_df.col("estimated_target_by_grouping_classification")
                        .cast(new DecimalType(25,3)));

        output__estturnru_df = output__estturnru_df.withColumn(
                "beta_grouping_classification", output__estturnru_df.col("beta_grouping_classification")
                        .cast(new DecimalType(25,3)));
        output__estturnru_df = output__estturnru_df.withColumn(
                "estimated_target_by_grouping_classification", output__estturnru_df.col("estimated_target_by_grouping_classification")
                        .cast(new DecimalType(25,3)));

        expected_estturnru_df.select(
                "focus", "reporting_period", "grouping_classification", "beta_grouping_classification",
                "estimated_target_by_grouping_classification").orderBy("focus", "reporting_period", "grouping_classification")
                .show(50);
        expected_estturnru_df.printSchema();
        output__estturnru_df.select("focus", "reporting_period", "grouping_classification", "beta_grouping_classification", "estimated_target_by_grouping_classification")
                .orderBy("focus", "reporting_period", "grouping_classification").show(50);
        output__estturnru_df.printSchema();

        assertEquals(
                expected_estturnru_df.select("focus", "reporting_period", "grouping_classification", "beta_grouping_classification",
                        "estimated_target_by_grouping_classification").orderBy("focus", "reporting_period", "grouping_classification")
                        .collectAsList()
                ,
        output__estturnru_df.select("focus", "reporting_period", "grouping_classification", "beta_grouping_classification",
                "estimated_target_by_grouping_classification").orderBy("focus", "reporting_period", "grouping_classification")
                .collectAsList()
        );

    }


    @Then("the Java estimated turnover cell is produced$")
    public void the_Java_estimated_turnover_cell_is_produced() throws Exception {
        Dataset<Row> expected_estturncell_df = Estimation_by_RatioContext.expected_data_grouping_classification();
        //Dataset<Row> output_estturncell_df = ContextCommon.output_data()._2;
        Dataset<Row> output_estturncell_df = ContextCommon.output_data();

        System.out.println("Showing output data first, then expected data and associated schemas:");

        expected_estturncell_df = expected_estturncell_df.withColumn(
                "beta_grouping_classification", expected_estturncell_df.col("beta_grouping_classification")
                        .cast(new DecimalType(25,3)));
        expected_estturncell_df = expected_estturncell_df.withColumn(
                "final_target", expected_estturncell_df.col("final_target")
                        .cast(new DecimalType(25,3)));

        output_estturncell_df = output_estturncell_df.withColumn(
                "beta_grouping_classification", output_estturncell_df.col("beta_grouping_classification")
                        .cast(new DecimalType(25,3)));
        output_estturncell_df = output_estturncell_df.withColumn(
                "final_target", output_estturncell_df.col("final_target")
                        .cast(new DecimalType(25,3)));

        expected_estturncell_df.select(
                "reporting_period", "grouping_classification",
                "beta_grouping_classification", "final_target")
                .orderBy("reporting_period", "grouping_classification")
                .show(50);
        expected_estturncell_df.printSchema();
        output_estturncell_df.select(
                "reporting_period", "grouping_classification",
                "beta_grouping_classification", "final_target")
                .orderBy("reporting_period", "grouping_classification")
                .show(50);
        output_estturncell_df.printSchema();

        assertEquals(
                expected_estturncell_df.select("reporting_period", "grouping_classification",
                        "beta_grouping_classification", "final_target")
                        .orderBy("reporting_period", "grouping_classification")
                        .collectAsList()
                ,
                output_estturncell_df.select("reporting_period", "grouping_classification",
                        "beta_grouping_classification", "final_target")
                        .orderBy("reporting_period", "grouping_classification")
                        .collectAsList()
        );

    }


    @Then("the Java uncertainty of the estimation is produced$")
    public void the_Java_uncertainty_of_the_estimation_is_produced() throws Exception {
        Dataset<Row> expected_uncertainty_df = Estimation_by_RatioContext.expected_data_grouping_classification();
        Dataset<Row> output_uncertainty_df = ContextCommon.output_data();

        System.out.println("Showing output data first, then expected data and associated schemas:");

        expected_uncertainty_df = expected_uncertainty_df.withColumn(
                "standard_error", expected_uncertainty_df.col("standard_error")
                        .cast(new DecimalType(25,3)));

        output_uncertainty_df = output_uncertainty_df.withColumn(
                "standard_error", output_uncertainty_df.col("standard_error")
                        .cast(new DecimalType(25,3)));

        expected_uncertainty_df.select(
                "reporting_period", "grouping_classification",
                "standard_error")
                .orderBy("reporting_period", "grouping_classification")
                .show(50);
        expected_uncertainty_df.printSchema();
        output_uncertainty_df.select(
                "reporting_period", "grouping_classification",
                "standard_error")
                .orderBy("reporting_period", "grouping_classification")
                .show(50);
        output_uncertainty_df.printSchema();

        assertEquals(
                expected_uncertainty_df.select("reporting_period", "grouping_classification",
                        "standard_error")
                        .orderBy("reporting_period", "grouping_classification")
                        .collectAsList()
                ,
                output_uncertainty_df.select("reporting_period", "grouping_classification",
                        "standard_error")
                        .orderBy("reporting_period", "grouping_classification")
                        .collectAsList()
        );

    }


}