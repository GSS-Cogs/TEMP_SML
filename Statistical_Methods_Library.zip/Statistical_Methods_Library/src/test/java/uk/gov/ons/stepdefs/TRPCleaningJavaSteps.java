package uk.gov.ons.stepdefs;

import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import scala.collection.convert.WrapAsJava$;
import uk.gov.ons.api.java.methods.TPRCleaningFactory;
import static org.junit.Assert.assertEquals;
import java.util.ArrayList;

public class TRPCleaningJavaSteps {

    Dataset<Row> TPRCDs = null;


    @When("^the Java TPR Cleaning function is applied$")
    public void apply_java_TPRC() throws Exception {
        ArrayList<String> paramList = new ArrayList<>(WrapAsJava$.MODULE$.seqAsJavaList(ContextCommon.param_list()));

        TPRCDs = TPRCleaningFactory.cleaning(ContextCommon.input_data())
                .clean1(ContextCommon.input_data(),paramList.get(1)
                        ,paramList.get(0), paramList.get(2), paramList.get(3), Integer.parseInt(paramList.get(4)));
        System.out.println("Java TPRC -> outcome: ");
        TPRCDs.select("Marker", "turnover", "tpr_turnover").show();
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
    }
    @Then("^the Java TPR function will Correct records$")
    public void check_java_TPRC_M1() throws Exception {
        ContextCommon.expected_data_$eq(TPRCDs);
    }

    @Then("^the Java TPR function will Copy records$")
    public void check_java_TPRC_M0() throws Exception {
        ContextCommon.expected_data_$eq(TPRCDs);
    }
}


