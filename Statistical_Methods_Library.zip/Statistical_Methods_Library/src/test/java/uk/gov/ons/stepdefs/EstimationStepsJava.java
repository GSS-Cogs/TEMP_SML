package uk.gov.ons.stepdefs;

import cucumber.api.java.en.When;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import uk.gov.ons.api.java.methods.EstimationFactory;

public class EstimationStepsJava {

    @When("the Java estimateWeightByExpansion function is applied.")
    public void estimateByExpansionCalled() throws Exception {

        if (ContextEstimation.strataColumn().get().equals("null")) {

            Dataset<Row> outDF = EstimationFactory.estimation(ContextEstimation.df())
                                                  .estimateWeightByExpansion(ContextEstimation.targetColumn(),
                                                                             null,
                                                                             false);
            ContextEstimation.outDF_$eq(outDF);
        }
        else {

            Dataset<Row> outDF = EstimationFactory.estimation(ContextEstimation.df())
                                                  .estimateWeightByExpansion(ContextEstimation.targetColumn(),
                                                                             ContextEstimation.strataColumn().get(),
                                                                             ContextEstimation.isTrimmed());
            ContextEstimation.outDF_$eq(outDF);
        }

        System.out.println("When the Java estimateWeightByExpansion function is applied.");
    }

    @When("the Java estimateWeightByRatio function is applied.")
    public void estimateByRatioCalled() throws Exception {

        if (ContextEstimation.strataColumn().get().equals("null")) {

            Dataset<Row> outDF = EstimationFactory.estimation(ContextEstimation.df())
                                                  .estimateWeightByRatio(ContextEstimation.targetColumn(),
                                                                         ContextEstimation.auxiliaryColumn(),
                                                                        null,
                                                                        false);
            ContextEstimation.outDF_$eq(outDF);
        }
        else {

            Dataset<Row> outDF = EstimationFactory.estimation(ContextEstimation.df())
                                                  .estimateWeightByRatio(ContextEstimation.targetColumn(),
                                                                         ContextEstimation.auxiliaryColumn(),
                                                                         ContextEstimation.strataColumn().get(),
                                                                         ContextEstimation.isTrimmed());
            ContextEstimation.outDF_$eq(outDF);
        }

        System.out.println("When the Java estimateWeightByRatio function is applied.");
    }
}
