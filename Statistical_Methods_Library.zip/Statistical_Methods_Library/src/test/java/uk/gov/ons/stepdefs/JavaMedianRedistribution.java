package uk.gov.ons.stepdefs;

import cucumber.api.java.en.When;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import scala.collection.convert.WrapAsJava$;
import uk.gov.ons.api.java.methods.MedianRedistributionFactory;

import java.util.ArrayList;


public class JavaMedianRedistribution {

    @When("the Java MedianRedistribution function is applied to the dataset")
    public void when_stepimpl() throws Exception {

        Dataset<Row> in_df = ContextCommon.input_data();

        Dataset<Row> out_df = MedianRedistributionFactory
                .medianRedistribution(in_df)
                .medianRedistributionMethod(
                        in_df,
                        ContextMedianRedis.partition_col(),
                        ContextMedianRedis.time_col(),
                        ContextMedianRedis.marker_col(),
                        ContextMedianRedis.type_col(),
                        ContextMedianRedis.target_col(),
                        new ArrayList<>(WrapAsJava$.MODULE$.seqAsJavaList(ContextMedianRedis.unclean_vals())),
                        ContextMedianRedis.out_col()
                );
        ContextCommon.output_data_$eq(out_df);
    }
}
