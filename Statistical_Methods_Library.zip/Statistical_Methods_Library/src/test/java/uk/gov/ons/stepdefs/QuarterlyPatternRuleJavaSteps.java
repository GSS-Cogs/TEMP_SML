package uk.gov.ons.stepdefs;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import scala.collection.convert.WrapAsJava$;
import uk.gov.ons.api.java.methods.QuarterlyPatternRuleFactory;
import java.util.ArrayList;
import static org.junit.Assert.assertEquals;

public class QuarterlyPatternRuleJavaSteps {

    Dataset<Row> output_data;

    //Setup for Java Steps (params):
    public void qpr_call(Dataset<Row> inputDf) throws Exception {

        ArrayList<String> partCol = new ArrayList<>(WrapAsJava$.MODULE$.seqAsJavaList(QuarterlyPatternRuleContext.partition_list()));
        ArrayList<String> ordCol = new ArrayList<>(WrapAsJava$.MODULE$.seqAsJavaList(QuarterlyPatternRuleContext.partition_order_list()));
        ArrayList<Object> idenVal = new ArrayList<>(WrapAsJava$.MODULE$.seqAsJavaList(QuarterlyPatternRuleContext.identifierValue()));

        output_data = QuarterlyPatternRuleFactory.quarterlyPatternRule(inputDf).quarterlyPatternRuleMethod(
                inputDf,
                partCol,
                ordCol,
                QuarterlyPatternRuleContext.comparisonValueColumn(),
                QuarterlyPatternRuleContext.identifierColumn(),
                idenVal
        );
        System.out.println("Java Steps Params:");
        System.out.println("Java Steps Output Data and Schema:");
        output_data.show();
        output_data.schema();
        ContextCommon.output_data_$eq(output_data);
    }

    @When("^we apply the Java QPR function to the input dataset Scenario A$")
    public void we_apply_the_Java_QPR_function_to_the_input_dataset_Scenario_A() throws Exception {
        Dataset<Row> in_df = ContextCommon.input_data();
        qpr_call(in_df);
    }

    @When("^we apply the Java QPR function to the input dataset Scenario B$")
    public void we_apply_the_Java_QPR_function_to_the_input_dataset_Scenario_B() throws Exception {
        Dataset<Row> in_df = ContextCommon.input_data();
        qpr_call(in_df);
    }

    @When("^we apply the Java QPR function to the input dataset Scenario C$")
    public void we_apply_the_Java_QPR_function_to_the_input_dataset_Scenario_C() throws Exception {
        Dataset<Row> in_df = ContextCommon.input_data();
        qpr_call(in_df);
    }

    @Then("^the Java QPR function correctly flags the record where the scenario pattern is identified$")
    public void the_Java_QPR_function_correctly_flags_the_record_where_the_scenario_pattern_is_identified() throws Exception {
        //Scenarios A through C use this code section:
        Dataset<Row> expected_df = ContextCommon.expected_data();
        assertEquals(expected_df.select("test_financial_year", "test_period", "test_stagger", "test_turnover", "test_vat_returns_vatref9",
                "lagged_1", "lagged_2", "lagged_3",
                //"qpr_000y", "qpr_xxxy", "qpr_xxxx", "qpr_null")
                "qpr_pattern").orderBy("test_vat_returns_vatref9", "test_period").collectAsList(),
                output_data.select("test_financial_year", "test_period", "test_stagger", "test_turnover", "test_vat_returns_vatref9",
                        "lagged_1", "lagged_2", "lagged_3",
                        //"qpr_000y", "qpr_xxxy", "qpr_xxxx", "qpr_null"
                        "qpr_pattern"
                ).orderBy("test_vat_returns_vatref9", "test_period").collectAsList());
    }
}




