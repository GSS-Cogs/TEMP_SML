package uk.gov.ons.stepdefs;

import cucumber.api.java.en.When;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import scala.collection.convert.WrapAsJava$;
import uk.gov.ons.api.java.methods.RedistributionFactory;

import java.util.ArrayList;

public class RedistributionStepsJava {
    private Dataset<Row> inputDS = ContextRedistribution.df();

    @When("the Java Redistribution function is applied")
    public void java_redistribution_called() throws Exception {

        if (ContextRedistribution.weights_col().get().equals("null")) {
            Dataset<Row> output_data = RedistributionFactory.redistribution(ContextRedistribution.df()).redistribute(
                    new ArrayList<>(WrapAsJava$.MODULE$.seqAsJavaList(ContextRedistribution.part_cols())),
                    ContextRedistribution.target_col(),
                    ContextRedistribution.new_col(),
                    null);
            ContextRedistribution.outputDF_$eq(output_data);
        }
        else {
            Dataset<Row> output_data = RedistributionFactory.redistribution(ContextRedistribution.df()).redistribute(
                    new ArrayList<>(WrapAsJava$.MODULE$.seqAsJavaList(ContextRedistribution.part_cols())),
                    ContextRedistribution.target_col(),
                    ContextRedistribution.new_col(),
                    ContextRedistribution.weights_col().get());
            ContextRedistribution.outputDF_$eq(output_data);
        }


        System.out.println("The Java Redistribution output\n");
        ContextRedistribution.outputDF().show();
    }
}
