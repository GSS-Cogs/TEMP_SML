package uk.gov.ons.api.java.methods;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;

public class RedistributionFactory {
    private static final RedistributionAPI$ Redistribution_API = RedistributionAPI$.MODULE$;

    private RedistributionFactory() {
    }

    /**
     * This Factory initilises a RedistributionAPI object
     *
     * @param df Dataset[Row]
     * @return Dataset[Row]
     */
    public static RedistributionAPI redistribution(Dataset<Row> df) {
        return Redistribution_API.redistribution(df);
    }
}
