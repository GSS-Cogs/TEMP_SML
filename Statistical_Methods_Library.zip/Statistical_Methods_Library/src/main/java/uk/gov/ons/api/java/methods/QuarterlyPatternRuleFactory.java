package uk.gov.ons.api.java.methods;


import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;

public class QuarterlyPatternRuleFactory {

    private static final QuarterlyPatternRuleAPI$ QUARTERLY_PATTERN_RULE_API = QuarterlyPatternRuleAPI$.MODULE$;

    private QuarterlyPatternRuleFactory() {
    }
    /**
     * This method will mark records that fail return in a quarterly stagger but actually are annual returns.  It does
     * this by checking for the following patterns in the quarterly returns split over a financial year then marks them
     * depending on the pattern they fail
     * Pattern 2 : X,X,X,X Marked with : 2
     * Pattern 3 : X,X,X,Y Marked with : 3
     * Pattern 4 : 0,0,0,Y Marked with : 4
     *
     * These marked records can then be cleaned using some form of calendarisation function like the
     * MedianRedistribution function in the SML
     *
     * This Factory class witch initialises an QuarterlyPatternRuleAPI object for use.
     *
     * @param df a input dataframe
     * @return df
     */

            public static QuarterlyPatternRuleAPI quarterlyPatternRule(Dataset<Row> df) {
                return QUARTERLY_PATTERN_RULE_API.quarterlyPatternRule(df);
            }

}
