package uk.gov.ons.api.java.methods;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;

public class MedianRedistributionFactory {
    private static final MedianRedistributionAPI$ MEDIAN_REDISTRIBUTION_API = MedianRedistributionAPI$.MODULE$;

    private MedianRedistributionFactory() {
    }

    /**
     * This Factory class witch initialises an MedianRedistributionAPI object for use.
     *
     * @param df a input dataframe
     * @return df
     */
    public static MedianRedistributionAPI medianRedistribution(Dataset<Row> df) {
        return MEDIAN_REDISTRIBUTION_API.medianRedistribution(df);
    }
}
