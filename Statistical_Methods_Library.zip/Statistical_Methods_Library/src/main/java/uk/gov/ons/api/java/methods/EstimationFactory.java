package uk.gov.ons.api.java.methods;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;

public class EstimationFactory {
    private static final EstimationAPI$ Estimation_API = EstimationAPI$.MODULE$;

    private EstimationFactory() {
    }

    /**
     * This Factory initialises an EstimationAPI object
     *
     * @param df Dataset[Row] - Dataset transported to Scala layer.
     * @return Dataset[Row]
     */
    public static EstimationAPI estimation(Dataset<Row> df) { return Estimation_API.estimation(df); }
}
