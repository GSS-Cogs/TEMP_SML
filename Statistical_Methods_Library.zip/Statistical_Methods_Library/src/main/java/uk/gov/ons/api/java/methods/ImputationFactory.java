package uk.gov.ons.api.java.methods;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;

public class ImputationFactory {
    private static final ImputationAPI$ Imputation_API = ImputationAPI$.MODULE$;

    public ImputationFactory() {
    }

    /**
     * This Factory class will initialise an ImputationAPI object for use.
     *
     * @param df DataFrame
     * @return Imputation
     */
    public static ImputationAPI imputation(Dataset<Row> df) {
        return ImputationAPI.imputation(df);
    }
}
