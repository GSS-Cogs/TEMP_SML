package uk.gov.ons.api.java.methods;


import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;


public class RatioEstimationFactory {


    private static final RatioEstimationAPI$ RATIO_ESTIMATION_API = RatioEstimationAPI$.MODULE$;


    private RatioEstimationFactory() {
    }

    /**
     * This Factory class witch initialises an RatioEstimationAPI object for use.
     */

    public static RatioEstimationAPI ratioEstimation(Dataset<Row> df) {
        return RATIO_ESTIMATION_API.ratioEstimation(df);
    }

}