package uk.gov.ons.api.java.methods;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import uk.gov.ons.methods.TPRCleaning;
import uk.gov.ons.methods.TPRCleaning$;

public class TPRCleaningFactory {

    private static final TPRCleaning$ TPR_CLEANING_API = TPRCleaning$.MODULE$;

    private TPRCleaningFactory(){}

    /**
     * Java Wrapper for the TPR Cleaning function.
     *
     * @param df    Dataset[Row] - dataset to transform.
     * @return      Dataset[Row]
     */

    public static TPRCleaning cleaning(Dataset<Row> df) {
        return TPR_CLEANING_API.cleaning(df);
    }
}