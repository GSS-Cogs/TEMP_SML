package uk.gov.ons.api.java.methods

import java.util

import org.apache.spark.sql.DataFrame
import uk.gov.ons.methods.Imputation

import scala.collection.JavaConversions._

class ImputationAPI[K](impute: Imputation) {
  /** Marks, constructs and imputes missing values
    *
    * @param df         DataFrame - The input DataFrame for the function to be applied to
    * @param partCols   List[String] - Columns that will be used to partition the data
    * @param unitCol    String - Name of column containing identifier for each unit
    * @param timeCol    String - Name of column contain time period for data
    * @param targetCol  String - Name of column that will be imputed
    * @param outputCol  String - Name of output column for imputed/constructed/real values
    * @param markerCol  String - Name of marker column indicating if a row is imputed/constructed/real
    * @param auxCol     String - Name of column containing auxiliary variable
    * @return
    */
  def impute(df: DataFrame, partCols: util.ArrayList[String], unitCol: String, timeCol: String, targetCol: String,
             outputCol: String, markerCol: String, auxCol: String): DataFrame = {
    impute.impute(df, partCols.toList, unitCol, timeCol, targetCol, outputCol, markerCol, auxCol)
  }
}

object ImputationAPI {
  def imputation(df: DataFrame): ImputationAPI[Imputation] = {
    new ImputationAPI[Imputation](Imputation.imputation(df))
  }
}
