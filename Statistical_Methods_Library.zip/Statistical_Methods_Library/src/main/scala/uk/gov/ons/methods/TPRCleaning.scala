package uk.gov.ons.methods

import uk.gov.ons.methods.impl.CleaningTPRImpl
import org.apache.spark.sql.DataFrame

class TPRCleaning  (val dfIn: DataFrame) {

  if (dfIn == null) throw new Exception("This DataFrame cannot be null")

  import CleaningTPRImpl._

  val defaultCol = "tpr_turnover"

  private def mandatoryArgCheck(arg1 : String, arg2 : String) : Unit = {

    if ((arg1 == null) || (arg2 == null)) throw new
        Exception("Missing the mandatory argument")
  }

  /**
    * Scala Method which call the TPR Cleaning method.
    *
    * @author saul.pountney@ons.gov.uk
    * @version 1.0
    *
    *
    * @param df           Dataframe.
    * @param Value_col    String -  column which is used as the initial value.
    * @param Marker_col   String -  column which is the marked value which shows irregular values.
    * @param New_col      String -  column which shows the altered values.
    * @param markerVal    String -  the value that indicates a column should be cleaned
    * @param correctorVal String -  the multiplier used to correct a marked value
    * @return             Dataset[Row].
    */

  def clean1(df: DataFrame, Value_col: String, Marker_col:String,
             New_col: String = defaultCol, markerVal: Any, correctorVal: Int) : DataFrame = {

    mandatoryArgCheck(Value_col, Marker_col)

    val dF = if (df == null) dfIn else df

    dF.tprCleaning(Value_col, Marker_col, New_col, markerVal, correctorVal)
  }
}

object TPRCleaning {

  def cleaning(df: DataFrame) : TPRCleaning = new TPRCleaning(df)
}