package uk.gov.ons.api.java.methods

//Imports for Java API Layer:
import java.util
import org.apache.spark.sql.{DataFrame, Dataset, Row}
import uk.gov.ons.methods.QuarterlyPatternRule
import scala.collection.JavaConversions._


class QuarterlyPatternRuleAPI[K](qpr: QuarterlyPatternRule) {

  /** This method will mark records that fail return in a quarterly stagger but actually are annual returns.  It does
    * this by checking for the following patterns in the quarterly returns split over a financial year then marks them
    * depending on the pattern they fail
    * Pattern 2 : X,X,X,X Marked with : 2
    * Pattern 3 : X,X,X,Y Marked with : 3
    * Pattern 4 : 0,0,0,Y Marked with : 4
    *
    * These marked records can then be cleaned using some form of calendarisation function like the
    * MedianRedistribution function in the SML
    *
    * This function will call the function defined in methods.QuarterlyPatternRule. It acts as a gateway between the
    * Java and scala Project Layers.
    * Any translations from Java Types to Scala types are performed in this .scala file.
    *
    * @author martyn.spooner@ons.gov.uk
    * @version 1.0
    * @since 1.0
    * @param partitionColumns       List[String] - The dataframe columns that will be used to partition the input dataframe.
    * @param orderColumns           List[String] - The dataframe columns that will be used to order the partition.
    * @param comparisonValueColumn  String       - The dataframe column that will specify the turnover identifier.
    * @param identifierColumn       String       - The dataframe column that will specify the whether a row will be part of the comparison.
    * @param identifierValue        List[Object] - The value(s) to look for in the identifierColumn to indicate it is a quarterly value
    * @return
    */

  def quarterlyPatternRuleMethod(df: DataFrame,
                                 partitionColumns: util.ArrayList[String], orderColumns: util.ArrayList[String],
                                 comparisonValueColumn: String, identifierColumn: String,
                                 identifierValue: util.ArrayList[Object]): DataFrame = {
                                                qpr.quarterlyPatternRuleMethod(df, partitionColumns.toList,
                                                  orderColumns.toList, comparisonValueColumn, identifierColumn,
                                                  identifierValue.toList)
                                               }
}

object QuarterlyPatternRuleAPI {
  def quarterlyPatternRule(df: Dataset[Row]): QuarterlyPatternRuleAPI[QuarterlyPatternRule] = {
    new QuarterlyPatternRuleAPI(QuarterlyPatternRule.quarterlyPatternRule(df))
  }
}