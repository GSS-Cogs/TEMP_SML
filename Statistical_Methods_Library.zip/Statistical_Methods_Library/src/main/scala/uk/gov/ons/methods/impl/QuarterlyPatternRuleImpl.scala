package uk.gov.ons.methods.impl

//Imports for Method and Base to Extend with QPR:
import uk.gov.ons.methods.impl.BaseImpl.BaseMethodsImpl
import org.apache.spark.sql.{functions => F, Column, DataFrame, Dataset, Row}
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.expressions.Window

object QuarterlyPatternRuleImpl {


  implicit class QuarterlyPatternRuleMethodsImpl(df: DataFrame) extends BaseMethodsImpl(df: DataFrame) {

    /** This function will check the names of columns in the DataFrame against a list of inputs
      *
      * This method will mark records that fail return in a quarterly stagger but actually are annual returns.  It does
      * this by checking for the following patterns in the quarterly returns split over a financial year then marks them
      * depending on the pattern they fail
      * Pattern 2 : X,X,X,X Marked with : 2
      * Pattern 3 : X,X,X,Y Marked with : 3
      * Pattern 4 : 0,0,0,Y Marked with : 4
      *
      * These marked records can then be cleaned using some form of calendarisation function like the
      * MedianRedistribution function in the SML
      *
      * @author martyn.spooner@ons.gov.uk
      * @version 1.0
      * @since 1.0
      * @param partitionColumns       List[String] - The dataframe columns that will be used to partition the input dataframe.
      * @param orderColumns           List[String] - The dataframe columns that will be used to order the partition.
      * @param comparisonValueColumn  String       - The dataframe column that will specify the value that will be compared.
      * @param identifierColumn       String       - The dataframe column that will specify the whether a row will be part of the comparison.
      * @param identifierValue        List[Any]    - The value(s) to look for in the identifierColumn to indicate it is a quarterly value
      * @return
      */

    def quarterlyPatternRuleMethod(
                                    partitionColumns: List[String], orderColumns: List[String],
                                    comparisonValueColumn: String, identifierColumn: String, identifierValue: List[Any]
                                  ): DataFrame = {

      // New column names
      val lagged_1: String = "lagged_1"
      val lagged_2: String = "lagged_2"
      val lagged_3: String = "lagged_3"
      val qpr_col_pattern: String = "qpr_pattern"

      // Create windowing partitions and perform pattern identification routines:
      val pColumns: List[Column] = partitionColumns.map(s => col(s))
      val oColumns: List[Column] = orderColumns.map(s => col(s))
      val w = Window.partitionBy(pColumns:_*).orderBy(oColumns:_*)
      val df_q: DataFrame = df.where(F.col(identifierColumn).isin(identifierValue:_*))

      // Lag by the turnover identifier:
      val df_lagged: DataFrame = df_q.withColumn(lagged_1, F.lag(comparisonValueColumn, 1, null).over(w))
        .withColumn(lagged_2, F.lag(comparisonValueColumn, 2, null).over(w))
        .withColumn(lagged_3, F.lag(comparisonValueColumn, 3, null).over(w))

            df_lagged// If (0,0,0,y) mark with 4
              .withColumn(qpr_col_pattern, F.when(F.col(lagged_1).equalTo(0.0) &&
              F.col(lagged_2).equalTo(0.0) &&
              F.col(lagged_3).equalTo(0.0) &&
              F.col(comparisonValueColumn).notEqual(0.0), 4).otherwise(
              F.when(F.col(comparisonValueColumn).equalTo(F.col(lagged_1)) &&
                        F.col(comparisonValueColumn).equalTo(F.col(lagged_2)) &&
                        F.col(comparisonValueColumn).notEqual(F.col(lagged_3)),3).otherwise(
                F.when(F.col(comparisonValueColumn).equalTo(F.col(lagged_1)) &&
                          F.col(comparisonValueColumn).equalTo(F.col(lagged_2)) &&
                          F.col(comparisonValueColumn).equalTo(F.col(lagged_3)), 2).otherwise(
                  F.when(F.col(comparisonValueColumn).isNull ||
                            F.col(lagged_1).isNull ||
                            F.col(lagged_2).isNull ||
                            F.col(lagged_3).isNull, 1)
                )
              )
            )
            ).na.fill(0, Seq(qpr_col_pattern))
    }
  }
}

