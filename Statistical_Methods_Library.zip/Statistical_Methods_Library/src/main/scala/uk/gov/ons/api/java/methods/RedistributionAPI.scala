package uk.gov.ons.api.java.methods

import java.util

import org.apache.spark.sql.DataFrame
import uk.gov.ons.methods.Redistribution

import scala.collection.JavaConversions._

class RedistributionAPI[K](redist: Redistribution) {

  /** This function redistributes the target column based on weights
    * If no weights are provided the target will be redistributed evenly within the partitions
    *
    * @author tom.reilly@ext.ons.gov.uk
    * @version 1.0
    * @since 1.0
    * @param partCols  ArrayList[String] - Name of the column(s) to partition on
    * @param targetCol String - Name of the column that is to be redistributed
    * @param newCol    String - Name of the column to contain the output
    * @param weightCol Option[String] - Name of the column containing the weights
    * @return
    */
  def redistribute(partCols: util.ArrayList[String], targetCol: String,
                   newCol: String, weightCol: String = null): DataFrame = {

    redist.redistribute(partCols.toList, targetCol, newCol, Option(weightCol))
  }

}

object RedistributionAPI {
  def redistribution(df: DataFrame): RedistributionAPI[Redistribution] = {
    new RedistributionAPI[Redistribution](Redistribution.redistribution(df))
  }
}
