package uk.gov.ons.methods

import org.apache.spark.sql.DataFrame

class MedianRedistribution(val dfIn: DataFrame) extends BaseMethod {
  if (dfIn == null) throw new Exception("DataFrame can not be null")

  import uk.gov.ons.methods.impl.MedianRedistributionImpl._

  /** This function will call the implicit function defined in impl.MedianRedistributionMethodsImpl
    *
    * @author tom.reilly@ext.ons.gov.uk
    * @version 1.0
    * @since 1.0
    * @param partitionCol String - Name of the column to partition on
    * @param timeCol      String - Name of the column containg the timeperiod data
    * @param markerCol    String - Name of the column that contains the markers
    * @param typeCol      String - Name of the column that contains the record type
    * @param targetCol    String - Name of the column that is to be redistributed
    * @param uncleanVals  List[String] - Markers that denote unclean records
    * @param outCol       String - Name of the column to contain the output
    * @return
    */
  def medianRedistributionMethod(df: DataFrame, partitionCol: String, timeCol: String,
                                 markerCol: String, typeCol: String, targetCol: String,
                                 uncleanVals: List[String], outCol: String): DataFrame = {

    mandatoryArgCheck(partitionCol, timeCol, markerCol, typeCol,
      targetCol, outCol, uncleanVals.flatten)

    val dF: DataFrame = if (df == null) dfIn else df

    dF.medianRedistribution(partitionCol, timeCol, markerCol, typeCol,
      targetCol, uncleanVals, outCol)
  }

}

object MedianRedistribution {
  def medianRedistribution(df: DataFrame): MedianRedistribution = new MedianRedistribution(df)
}