package uk.gov.ons.api.java.methods


import org.apache.spark.sql.DataFrame
import uk.gov.ons.methods.Estimation

class EstimationAPI[K](est: Estimation) {

  /**
    * Public method that estimates a weighting of a target column based on the simple relationship of sample
    * values to unknown population values, optionally allows for strata to be honoured. This is also referred to as
    * Horvits-Thompson estimation.
    *
    * @author danny.fiske@ons.gov.uk, stuart.russell@ons.gov.uk
    * @version 1.0
    * @since 1.0
    * @param targetColumn String          - Column name that to be estimated from.
    * @param strataColumn Option[String]  - Column name to be partitioned on.
    * @param isTrimmed Boolean            - Flag to disregard marked records in estimation.
    * @return DataFrame
    */
  def estimateWeightByExpansion(targetColumn: String, strataColumn: String = null,
                                isTrimmed: Boolean = false): DataFrame = {

    est.estimateWeightByExpansion(targetColumn, Option(strataColumn), isTrimmed)
  }

  /**
    * Public method that estimates estimates a weighting of a target column based on an auxiliary variable,
    * optionally allows for strata to be honoured.
    *
    * @author danny.fiske@ons.gov.uk, stuart.russell@ons.gov.uk
    * @version 1.0
    * @since 1.0
    * @param targetColumn String          - Column name that to be estimated from.
    * @param auxiliaryColumn String       - Column name of auxiliary values to produce a weight.
    * @param strataColumn Option[String]  - Column name to be partitioned on.
    * @param isTrimmed Boolean            - Flag to disregard marked records in estimation.
    * @return DataFrame
    */
  def estimateWeightByRatio(targetColumn: String, auxiliaryColumn: String = null,
                            strataColumn: String, isTrimmed: Boolean = false): DataFrame = {

    est.estimateWeightByRatio(targetColumn, auxiliaryColumn, Option(strataColumn), isTrimmed)
  }
}

object EstimationAPI {
  def estimation(df: DataFrame): EstimationAPI[Estimation] = new EstimationAPI[Estimation](Estimation.estimation(df))
}
