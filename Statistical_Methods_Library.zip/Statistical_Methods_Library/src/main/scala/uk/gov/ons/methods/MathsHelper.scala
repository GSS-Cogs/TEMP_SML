package uk.gov.ons.methods

object MathsHelper {
  /** This function finds the median value of a sequence of doubles
    *
    * @author tom.reilly@ext.ons.gov.uk
    * @version 1.0
    * @since 1.0
    * @param seq Seq[Double] - The sequence of values
    * @return
    */
  def median(seq: Seq[Double]): Double = {
    val size: Int = seq.size
    val sorted: Seq[Double] = seq.sortWith(_ < _)

    if (seq.size % 2 == 1) {
      sorted(size / 2)
    }
    else {
      val (up, down) = sorted.splitAt(size / 2)
      (up.last + down.head) / 2
    }
  }
}
