package uk.gov.ons.methods

import org.apache.spark.sql.DataFrame

class Estimation(val df: DataFrame) extends BaseMethod {

  if (df == null) throw new Exception("DataFrame cannot be null")

  import uk.gov.ons.methods.impl.EstimationImpl._

  /**
    * Public method that estimates a weighting of a target column based on the simple relationship of sample
    * values to unknown population values, optionally allows for strata to be honoured. This is also referred to as
    * Horvits-Thompson estimation.
    *
    * @author danny.fiske@ons.gov.uk, stuart.russell@ons.gov.uk
    * @version 1.0
    * @since 1.0
    * @param targetColumn String          - Column name that to be estimated from.
    * @param strataColumn Option[String]  - Column name to be partitioned on.
    * @param isTrimmed Boolean            - Flag to disregard marked records in estimation.
    * @return DataFrame
    */
  def estimateWeightByExpansion(targetColumn: String, strataColumn: Option[String] = None,
                                isTrimmed: Boolean = false): DataFrame = {

    mandatoryArgCheck(targetColumn)
    df.estimateWeightByExpansion(targetColumn, strataColumn, isTrimmed)
  }

  /**
    * Public method that estimates estimates a weighting of a target column based on an auxiliary variable,
    * optionally allows for strata to be honoured.
    *
    * @author danny.fiske@ons.gov.uk, stuart.russell@ons.gov.uk
    * @version 1.0
    * @since 1.0
    * @param targetColumn String          - Column name that to be estimated from.
    * @param auxiliaryColumn String       - Column name of auxiliary values to produce a weight.
    * @param strataColumn Option[String]  - Column name to be partitioned on.
    * @param isTrimmed Boolean            - Flag to disregard marked records in estimation.
    * @return DataFrame
    */
  def estimateWeightByRatio(targetColumn: String, auxiliaryColumn: String,
                            strataColumn: Option[String] = None, isTrimmed: Boolean = false): DataFrame = {

    mandatoryArgCheck(targetColumn, auxiliaryColumn)
    df.estimateWeightByRatio(targetColumn, auxiliaryColumn, strataColumn, isTrimmed)
  }
}

object Estimation {
  def estimation(df: DataFrame): Estimation = new Estimation(df)
}
