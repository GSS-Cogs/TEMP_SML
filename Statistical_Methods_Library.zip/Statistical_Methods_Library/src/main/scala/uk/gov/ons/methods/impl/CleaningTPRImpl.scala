
package uk.gov.ons.methods.impl

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.when

object CleaningTPRImpl {

  implicit class CleanTPRMethodsImpl(df: DataFrame) {

    /**
      * The Cleaning TPR checks for relevant Marker and applies a function to the correct marker.
      *
      * If the Marker is different from the designated value then it is expected that the ratio calculation was
      * correct and the value column is kept the same, the new results are then then stored in a new column.
      *
      * If the Marker is the designated value then it has failed the the ratio calculation and the value
      * column is multiplied by 1000, the new results are then stored in a new column.
      *
      * @param Value_col    String -  column which is used as the initial value.
      * @param Marker_col   String -  column which is the marked value which shows irregular values.
      * @param New_col      String -  column which shows the altered values.
      * @param markerVal    String -  the value that indicates a column should be cleaned
      * @param correctorVal String -  the multiplier used to correct a marked value
      * @return             Dataset[Row].
      */

    def tprCleaning(Value_col: String, Marker_col: String,
               New_col: String, markerVal: Any, correctorVal: Int): DataFrame = {
      df.withColumn(New_col, when(df(Marker_col) === markerVal, df(Value_col) * correctorVal)
        .otherwise(df(Value_col)))
    }
  }
}