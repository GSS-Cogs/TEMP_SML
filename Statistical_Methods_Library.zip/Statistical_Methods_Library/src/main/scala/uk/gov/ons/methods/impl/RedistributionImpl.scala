package uk.gov.ons.methods.impl

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{col, lit}
import uk.gov.ons.methods.impl.CommonImpl._


object RedistributionImpl {

  implicit class RedistributionMethodsImpl(df: DataFrame) {

    protected val defaultWeightsCol: String = "defWeights"
    protected val sumOfWeightsCol: String = "sumWeights"
    protected val proportionalWeightsCol: String = "propWeights"
    protected val sumOfTargetCol: String = "sumTarget"

    /** This function checks if there is a weight column and provides a default if not
      *
      * @author tom.reilly@ext.ons.gov.uk
      * @version 1.0
      * @since 1.0
      * @param weightCol Option[String] - Name of the column containing the weights
      * @return DataFrame
      */
    protected def checkWeightsColumn(weightCol: Option[String]): DataFrame = {
      if (weightCol.isEmpty) df.withColumn(this.defaultWeightsCol, lit(1)) else df
    }

    /** This function generates proportional weights within partitions
      *
      * @author tom.reilly@ext.ons.gov.uk
      * @version 1.0
      * @since 1.0
      * @param partCols  List[String] - Name of the column(s) to partition on
      * @param weightCol String - Name of the column containing the weights
      * @return DataFrame
      */
    protected def createProportionalWeights(partCols: List[String], weightCol: String): DataFrame = {
      df.sumAndJoin(partCols, weightCol, this.sumOfWeightsCol)
        .withColumn(this.proportionalWeightsCol, col(weightCol) / col(this.sumOfWeightsCol))
        .drop(this.sumOfWeightsCol)
    }

    /** This function redistributes the turnover for each partition based on proportional weights
      *
      * @author tom.reilly@ext.ons.gov.uk
      * @version 1.0
      * @since 1.0
      * @param targetCol String - Name of the column that is to be redistributed
      * @param weightCol String - Name of the column containing the weights
      * @param newCol    String - Name of the column to contain the output
      * @return DataFrame
      */
    protected def targetRedistribution(partCols: List[String], targetCol: String,
                                       weightCol: String, newCol: String): DataFrame = {
      df.sumAndJoin(partCols, targetCol, this.sumOfTargetCol)
        .withColumn(newCol, col(this.sumOfTargetCol) * col(this.proportionalWeightsCol))
        .drop(this.sumOfTargetCol)
    }

    /** This function redistributes the target column based on weights
      * If no weights are provided the target will be redistributed evenly within the partitions
      *
      * @author tom.reilly@ext.ons.gov.uk
      * @version 1.0
      * @since 1.0
      * @param partCols  List[String] - Name of the column(s) to partition on
      * @param targetCol String - Name of the column that is to be redistributed
      * @param newCol    String - Name of the column to contain the output
      * @param weightCol Option[String] - Name of the column containing the weights
      * @return
      */
    def redistribute(partCols: List[String], targetCol: String,
                     newCol: String, weightCol: Option[String] = None): DataFrame = {

      df.checkWeightsColumn(weightCol)
        .createProportionalWeights(partCols, weightCol.getOrElse(this.defaultWeightsCol))
        .targetRedistribution(partCols, targetCol, weightCol.getOrElse(this.defaultWeightsCol), newCol)
        .drop(this.defaultWeightsCol)
        .drop(this.proportionalWeightsCol)
    }
  }

}
