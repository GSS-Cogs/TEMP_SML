package uk.gov.ons.methods

import org.apache.spark.sql.{DataFrame, Dataset, Row}

class QuarterlyPatternRule (val df_input: DataFrame) extends BaseMethod {
  if (df_input == null) throw new Exception("DataFrame can not be null")

  import uk.gov.ons.methods.impl.QuarterlyPatternRuleImpl._

  /** This method will mark records that fail return in a quarterly stagger but actually are annual returns.  It does
    * this by checking for the following patterns in the quarterly returns split over a financial year then marks them
    * depending on the pattern they fail
    * Pattern 2 : X,X,X,X Marked with : 2
    * Pattern 3 : X,X,X,Y Marked with : 3
    * Pattern 4 : 0,0,0,Y Marked with : 4
    *
    * These marked records can then be cleaned using some form of calendarisation function like the
    * MedianRedistribution function in the SML
    *
    * @author martyn.spooner@ons.gov.uk
    * @version 1.0
    * @since 1.0
    *
    * @param df                     DataFrame    - The input DataFrame
    * @param partitionColumns       List[String] - Column(s) used to partition the input dataframe.
    * @param orderColumns           List[String] - Columns(s) used to order the partition.
    * @param comparisonValueColumn  String       - Column that will specify the turnover identifier.
    * @param identifierColumn       String       - The Column that will specify the whether a row will be part of the comparison.
    * @param identifierValue        List[Any]    - The value(s) to look for in the identifierColumn to indicate it is a quarterly value
    * @return DataFrame
    */
  def quarterlyPatternRuleMethod(df: DataFrame, partitionColumns: List[String],
                                 orderColumns: List[String], comparisonValueColumn: String,
                                 identifierColumn: String, identifierValue: List[Any]): DataFrame = {
    mandatoryArgCheck(partitionColumns, orderColumns, comparisonValueColumn, identifierColumn,
                      identifierValue)
    val dF = if (df == null) df_input else df
    dF.quarterlyPatternRuleMethod(partitionColumns, orderColumns, comparisonValueColumn, identifierColumn,
                                          identifierValue )
  }

}


object QuarterlyPatternRule {
      def quarterlyPatternRule(df: DataFrame): QuarterlyPatternRule = new QuarterlyPatternRule(df)
    }
