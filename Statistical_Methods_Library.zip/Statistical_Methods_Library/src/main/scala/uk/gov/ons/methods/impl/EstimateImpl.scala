package uk.gov.ons.methods.impl

import org.apache.spark.sql.DataFrame
import uk.gov.ons.methods.Estimate
import uk.gov.ons.methods.impl.BaseImpl.BaseMethodsImpl

object EstimateImpl {

  implicit class EstimateImplMethods(df: DataFrame) extends BaseMethodImpl(df: DataFrame) {


    def estimateWeightByExpansion(targetColumn: String, strataColumn: Option[String] = None, flagExclude: Option[String] = None,
                                  isTrimmed: Boolean = false): DataFrame = {
    Estimate.estimateWeightByExpansion(df, targetColumn, strataColumn, flagExclude, isTrimmed)
    }


    def estimateWeightByRatio(targetColumn: String, auxiliaryColumn: String, strataColumn: Option[String] = None,
                              isTrimmed: Boolean = false): DataFrame = {
    Estimate.estimateWeightByRatio(df, auxiliaryColumn, targetColumn, strataColumn, isTrimmed)
    }



    def applyEstimateWeights(df: DataFrame, weightCol: String, auxCol: String, targetCol: String,
                             strataCol: Option[String] = None): DataFrame = {
    Estimate.applyEstimateWeights(df, weightCol, auxCol, targetCol, strataCol)
    }


  }

}