package uk.gov.ons.methods.impl

import org.apache.spark.sql.expressions.{Window, WindowSpec}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame}

object OutlieringImpl {

  implicit class OutlieringMethodsImpl(df: DataFrame) {

    /**
      * Public method that ranks data by targetColumn and removes a percentage of records based on user input,
      * can optionally honour stratification.
      *
      * @author danny.fiske@ons.gov.uk, stuart.russell@ons.gov.uk
      * @version 1.0
      * @since 1.0
      * @param targetColumn String          - Column name that to be estimated from.
      * @param strataColumn Option[String]  - Column name to be partitioned on.
      * @param trimTop      Double          - Percentage of records to be trimmed from top of targetColumn-ordered data.
      * @param trimBottom   Double          - Percentage of records to be trimmed from bottom of targetColumn-ordered data.
      * @return DataFrame
      */
    def trimOutliers(targetColumn: String, strataColumn: Option[String] = None,
                     trimTop: Double = 0.0, trimBottom: Double = 0.0): DataFrame = {

      // TODO: Needs testing.

      var dfTrimmed: DataFrame = df
      var trimTopCount: Column = null
      var trimBottomCount: Column = null
      var window: WindowSpec = null

      if (strataColumn.isDefined) {

        dfTrimmed = dfTrimmed.join(df.where(col(targetColumn).isNotNull).groupBy(strataColumn.get).count(), strataColumn.get)
        window = Window.partitionBy(strataColumn.get).orderBy(desc(targetColumn))
      }
      else {

        dfTrimmed = dfTrimmed.withColumn("count", lit(df.where(col(targetColumn).isNotNull).count()))
        window = Window.orderBy(desc(targetColumn))
      }

      if (trimTop == 0.0) trimTopCount = lit(0) else trimTopCount = expr("floor((" + trimTop + "/ 100) * count)")
      if (trimBottom == 0.0) trimBottomCount = lit(dfTrimmed.count()) else trimBottomCount = expr("floor(count - (" + trimBottom + "/ 100) * count)")

      dfTrimmed = dfTrimmed.withColumn("trim_top", trimTopCount)
                           .withColumn("trim_bottom", trimBottomCount)

      val dfTrimmedNull = dfTrimmed.orderBy(desc(targetColumn))
                                   .where(col(targetColumn).isNull)
                                   .withColumn("rank", lit(null))

      val dfTrimmedRanked = dfTrimmed.orderBy(desc(targetColumn))
                                     .where(col(targetColumn).isNotNull)
                                     .withColumn("rank", row_number.over(window))

      dfTrimmedRanked.union(dfTrimmedNull)
                     .withColumn("is_trimmed", when((col("rank") <= col("trim_top") || col("rank") > col("trim_bottom")
                       || col("count") == lit(1)) && col("rank").isNotNull, "1").otherwise(null))
                     .drop(Seq("rank", "trim_top", "trim_bottom", "count"): _*)
    }
  }
}
