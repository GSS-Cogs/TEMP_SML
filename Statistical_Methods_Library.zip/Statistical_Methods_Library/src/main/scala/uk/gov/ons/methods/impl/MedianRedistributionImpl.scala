package uk.gov.ons.methods.impl

import org.apache.spark.sql.expressions.{Window, WindowSpec}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame}
import uk.gov.ons.methods.MathsHelper.median
import uk.gov.ons.methods.impl.BaseImpl.BaseMethodsImpl

object MedianRedistributionImpl {

  implicit class MedianRedistributionMethodsImpl(df: DataFrame)
    extends BaseMethodsImpl(df: DataFrame) {

    /**
      * @author tom.reilly@ext.ons.gov.uk
      * @version 1.0
      * @since 1.0
      * @param partitionCol String - Name of the column to partition on
      * @param timeCol      String - Name of the column containg the timeperiod data
      * @param markerCol    String - Name of the column that contains the markers
      * @param typeCol      String - Name of the column that contains the record type
      * @param targetCol    String - Name of the column that is to be redistributed
      * @param uncleanVals  List[String] - Markers that denote unclean records
      * @param outCol       String - Name of the column to contain the output
      * @return DataFrame
      */
    def medianRedistribution(partitionCol: String, timeCol: String, markerCol: String,
                             typeCol: String, targetCol: String, uncleanVals: List[String],
                             outCol: String): DataFrame = {
      // Temp column names
      val rowNum: String = "rowNum"
      val totalTarget: String = "totalTarget"
      val totMed: String = "totalMed"

      // Add row numbers to the groups
      val w: WindowSpec = Window.partitionBy(partitionCol, typeCol).orderBy(timeCol)
      // TODO Make row number names better e.g. "row_1" not "1"
      // TODO make multiple partition columns
      val dfRowNum: DataFrame = df.withColumn(rowNum, row_number().over(w))
      val maxRow: Int = dfRowNum.agg(max(rowNum)).as("Int").head().get(0).asInstanceOf[Int]

      // Identify clean and unclean records
      val cleanDf: DataFrame = dfRowNum.where(!col(markerCol).isin(uncleanVals: _*))
      val uncleanDf: DataFrame = dfRowNum.where(col(markerCol).isin(uncleanVals: _*))

      // Group by partition, and type columns and find the target for each time
      val cleanPivot: DataFrame = cleanDf.groupBy(partitionCol, typeCol)
        .pivot(rowNum)
        .sum(targetCol)

      // Create total target
      val cleanNewCols = for (num <- 1 to maxRow) yield col(num.toString)
      var cleanProp: DataFrame = cleanPivot.withColumn(totalTarget, cleanNewCols.reduce(_ + _))

      // Create proportional target
      val propCols = for (c <- cleanNewCols) yield "prop_" + c.toString()
      for ((c, p) <- cleanNewCols zip propCols) {
        cleanProp = cleanProp.withColumn(p, c / col(totalTarget))
      }

      // Collect list of the proportional targets in each type
      val collectSetCols = for (c <- propCols) yield collect_set(c)
      val cleanGroupedProp = cleanProp.groupBy(typeCol)
        .agg(collectSetCols.head, collectSetCols.tail: _*)

      // Find median of the proportional targets for each row in a type
      val medUdf = udf[Double, Seq[Double]](median)
      val medCols: Seq[Column] = for (c <- cleanNewCols) yield col("med_" + c.toString())
      var cleanMed: DataFrame = cleanGroupedProp

      for ((m, c) <- medCols zip collectSetCols) {
        cleanMed = cleanMed.withColumn(m.toString(), medUdf(col(c.toString)))
      }

      // Normalise the medians
      var cleanNorm: DataFrame = cleanMed.withColumn(totMed, medCols.reduce(_ + _))
      val normMedCols: Seq[String] = for (c <- medCols) yield "norm_" + c.toString()

      for ((m, n) <- medCols zip normMedCols) {
        cleanNorm = cleanNorm.withColumn(n, m / col(totMed))
      }

      // Prepare Data for join
      val cleanFinal: DataFrame = cleanNorm.select(typeCol, normMedCols: _*)

      // Join the values
      val joinedDf: DataFrame = uncleanDf.join(cleanFinal, Seq(typeCol), "left")

      // Correct the values
      val groupedDf: DataFrame = joinedDf.groupBy(partitionCol)
        .agg(sum(targetCol).alias(totalTarget))
      val totDf: DataFrame = joinedDf.join(groupedDf, Seq(partitionCol), "left")

      // TODO make this dynamic
      val cleanedDf: DataFrame = totDf.withColumn(outCol,
        when(col(rowNum) === 1, col(normMedCols(0)) * col(totalTarget))
          .otherwise(when(col(rowNum) === 2, col(normMedCols(1)) * col(totalTarget))
            .otherwise(when(col(rowNum) === 3, col(normMedCols(2)) * col(totalTarget))
              .otherwise(when(col(rowNum) === 4, col(normMedCols(3)) * col(totalTarget))))))

      // Union clean and unclean
      val cleanNewColDf: DataFrame = cleanDf.drop(rowNum).withColumn(outCol, col(targetCol))
      cleanNewColDf.union(
        cleanedDf.select(cleanNewColDf.columns.head, cleanNewColDf.columns.tail: _*))
    }
  }

}
