package uk.gov.ons.api.java.methods
import org.apache.spark.sql.{DataFrame, Dataset, Row}
import uk.gov.ons.methods.TPRCleaning


/**
  * This is a Java Wrapper which is used to access the TPR Cleaning Scala function.
  */

class JavaTRPCleaning[K](cl: TPRCleaning) {

  /**
    * Java wrapper used to access the TPR Cleaning function.
    *
    * @author saul.pountney@ons.gov.uk
    * @version 1.0
    *
    * @param df           Dataframe.
    * @param Value_col    String -  column which is used as the initial value.
    * @param Marker_col   String -  column which is the marked value which shows irregular values.
    * @param New_col      String -  column which shows the altered values.
    * @param markerVal    String -  the value that indicates a column should be cleaned
    * @param correctorVal String -  the multiplier used to correct a marked value
    * @return
    */

  def clean1(df: Dataset[Row], Value_col:String, Marker_col: String, New_col:String, markerVal: Object, correctorVal: Int):
    DataFrame = {cl.clean1(df, Value_col, Marker_col,New_col, markerVal, correctorVal)

  }
}
object JavaTPRCleaning {
  def cleaning(df: Dataset[Row]): JavaTRPCleaning[TPRCleaning] = {
    new JavaTRPCleaning(TPRCleaning.cleaning(df))
  }
}