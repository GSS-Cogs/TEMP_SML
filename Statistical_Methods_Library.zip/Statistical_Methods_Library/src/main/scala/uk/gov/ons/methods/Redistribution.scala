package uk.gov.ons.methods

import org.apache.spark.sql.DataFrame

class Redistribution(val df: DataFrame) extends BaseMethod {
  if (df == null) throw new Exception("DataFrame cannot be null")

  import uk.gov.ons.methods.impl.RedistributionImpl._

  def redistribute(partCols: List[String], targetCol: String,
                   newCol: String, weightCol: Option[String] = None): DataFrame = {

    mandatoryArgCheck(partCols.flatten, targetCol, newCol)
    df.redistribute(partCols, targetCol, newCol, weightCol)
  }
}

object Redistribution {
  def redistribution(df: DataFrame): Redistribution = new Redistribution(df)
}
