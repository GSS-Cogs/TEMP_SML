package uk.gov.ons.methods.impl

import org.apache.spark.sql.functions.{col, _}
import org.apache.spark.sql.DataFrame

object EstimationImpl {

  implicit class EstimationMethodsImpl(df: DataFrame) {

    /**
      * Public method that estimates a weighting of a target column based on the simple relationship of sample
      * values to unknown population values, optionally allows for strata to be honoured. This is also referred to as
      * Horvits-Thompson estimation.
      *
      * @author danny.fiske@ons.gov.uk, stuart.russell@ons.gov.uk
      * @version 1.0
      * @since 1.0
      * @param targetColumn String          - Column name that to be estimated from.
      * @param strataColumn Option[String]  - Column name to be partitioned on.
      * @param isTrimmed Boolean            - Flag to disregard marked records in estimation.
      * @return DataFrame
      */
    def estimateWeightByExpansion(targetColumn: String, strataColumn: Option[String] = None,
                                  isTrimmed: Boolean = false): DataFrame = {

      var dfEstimated: DataFrame = df
      var sampleCount: DataFrame = null
      var populationCount: DataFrame = null

      if (strataColumn.isDefined) {

        if (isTrimmed) {

          sampleCount = dfEstimated.where(col(targetColumn).isNotNull && col("is_trimmed").isNull).groupBy(strataColumn.get).count()
          populationCount = dfEstimated.where(col("is_trimmed").isNull).groupBy(strataColumn.get).count()
        }
        else {

          sampleCount = dfEstimated.where(col(targetColumn).isNotNull).groupBy(strataColumn.get).count()
          populationCount = dfEstimated.groupBy(strataColumn.get).count()
        }

        sampleCount = sampleCount.withColumnRenamed(strataColumn.get, strataColumn.get + "2")
                                 .withColumnRenamed("count", "count_sample")

        populationCount = populationCount.withColumnRenamed(strataColumn.get, strataColumn.get + "3")
                                         .withColumnRenamed("count", "count_population")

        dfEstimated.join(sampleCount, dfEstimated(strataColumn.get) === sampleCount(strataColumn.get + "2"), "right")
                   .join(populationCount, dfEstimated(strataColumn.get) === populationCount(strataColumn.get + "3"), "right")
                   .withColumn("design_weight", expr("count_population / count_sample"))
                   .drop(strataColumn.get + "2", strataColumn.get + "3", "count_population", "count_sample")
      }
      else {

        if (isTrimmed) {

          dfEstimated = dfEstimated.withColumn("count_sample", lit(dfEstimated.where(col(targetColumn).isNotNull && col("is_trimmed").isNull).count()))
                                   .withColumn("count_population", lit(dfEstimated.where(col("is_trimmed").isNull).count()))
        }
        else {

          dfEstimated = dfEstimated.withColumn("count_sample", lit(dfEstimated.where(col(targetColumn).isNotNull).count()))
                                   .withColumn("count_population", lit(dfEstimated.count()))
        }

        dfEstimated.withColumn("design_weight", expr("count_population / count_sample"))
                   .drop("count_sample", "count_population")
      }
    }

    /**
      * Public method that estimates estimates a weighting of a target column based on an auxiliary variable,
      * optionally allows for strata to be honoured.
      *
      * @author danny.fiske@ons.gov.uk, stuart.russell@ons.gov.uk
      * @version 1.0
      * @since 1.0
      * @param targetColumn String          - Column name that to be estimated from.
      * @param auxiliaryColumn String       - Column name of auxiliary values to produce a weight.
      * @param strataColumn Option[String]  - Column name to be partitioned on.
      * @param isTrimmed Boolean            - Flag to disregard marked records in estimation.
      * @return DataFrame
      */
    def estimateWeightByRatio(targetColumn: String, auxiliaryColumn: String, strataColumn: Option[String] = None,
                              isTrimmed: Boolean = false): DataFrame = {

      var dfEstimated: DataFrame = df.estimateWeightByExpansion(targetColumn, strataColumn, isTrimmed)
      var sampleSum: DataFrame = null
      var populationSum: DataFrame = null

      if (strataColumn.isDefined) {

        if (isTrimmed) {

          sampleSum = dfEstimated.where(col(targetColumn).isNotNull && col("is_trimmed").isNull).groupBy(strataColumn.get).sum(auxiliaryColumn)
          populationSum = dfEstimated.where(col("is_trimmed").isNull).groupBy(strataColumn.get).sum(auxiliaryColumn)
        }
        else {

          sampleSum = dfEstimated.where(col(targetColumn).isNotNull).groupBy(strataColumn.get).sum(auxiliaryColumn)
          populationSum = dfEstimated.groupBy(strataColumn.get).sum(auxiliaryColumn)
        }

        sampleSum = sampleSum.withColumnRenamed(strataColumn.get, strataColumn.get + "2")
                             .withColumnRenamed("sum(" + auxiliaryColumn + ")", "strata_sum_sample_" + auxiliaryColumn)

        populationSum = populationSum.withColumnRenamed(strataColumn.get, strataColumn.get + "3")
                                     .withColumnRenamed("sum(" + auxiliaryColumn + ")", "strata_sum_population_" + auxiliaryColumn)

        dfEstimated.join(sampleSum, dfEstimated(strataColumn.get) === sampleSum(strataColumn.get + "2"), "right")
                   .join(populationSum, dfEstimated(strataColumn.get) === populationSum(strataColumn.get + "3"), "right")
                   .withColumn("calibration_weight", expr("strata_sum_population_" + auxiliaryColumn + " / (strata_sum_sample_" + auxiliaryColumn + " * design_weight)"))
                   .drop(strataColumn.get + "2", strataColumn.get + "3", "strata_sum_sample_" + auxiliaryColumn, "strata_sum_population_" + auxiliaryColumn)
      }
      else {

        if (isTrimmed) {

          dfEstimated = dfEstimated.withColumn("sum_sample_" + auxiliaryColumn,
                                               lit(dfEstimated.where(col(targetColumn).isNotNull && col("is_trimmed").isNull)
                                                              .agg(sum(auxiliaryColumn))
                                                              .first()
                                                              .get(0)))
                                   .withColumn("sum_population_" + auxiliaryColumn,
                                               lit(dfEstimated.where(col("is_trimmed").isNull)
                                                              .agg(sum(auxiliaryColumn))
                                                              .first()
                                                              .get(0)))
        }
        else {

          dfEstimated = dfEstimated.withColumn("sum_sample_" + auxiliaryColumn,
                                               lit(dfEstimated.where(col(targetColumn).isNotNull)
                                                              .agg(sum(auxiliaryColumn))
                                                              .first()
                                                              .get(0)))
                                   .withColumn("sum_population_" + auxiliaryColumn,
                                               lit(dfEstimated.agg(sum(auxiliaryColumn))
                                                              .first()
                                                              .get(0)))
        }

        dfEstimated.withColumn("calibration_weight", expr("sum_population_" + auxiliaryColumn + " / (sum_sample_" + auxiliaryColumn + " * design_weight)"))
                   .drop("sum_population_" + auxiliaryColumn, "sum_sample_" + auxiliaryColumn)
      }
    }
  }
}