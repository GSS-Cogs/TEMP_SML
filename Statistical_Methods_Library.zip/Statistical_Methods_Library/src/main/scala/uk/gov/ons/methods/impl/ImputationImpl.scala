package uk.gov.ons.methods.impl

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{sum, _}
import uk.gov.ons.methods.impl.CommonImpl._

object ImputationImpl {

  implicit class ImputationMethodsImpl(df: DataFrame) {
    protected val sumTarget: String = "SumTarget"
    protected val sumAux: String = "SumAux"
    protected val laggedSumTarget: String = "LaggedSumTarget"
    protected val laggedColumn: String = "lagged1"
    protected val firstInSeries: String = "FirstTurnoverInSeries"
    protected val constructedVal: String = "ConstructedValue"
    protected val imputeVal: String = "ImputedValue"
    protected val impLink: String = "ImputationLink"
    protected val conLink: String = "Construction Link"
    protected val leadColumn: String = "Lead"
    protected val leadSumTarget: String = "LeadSumTarget"
    protected val backImpLink: String = "BackwardImputationLink"
    protected val firstReturnPeriod: String = "FirstReturnedPeriod"

    /** Marks, constructs and imputes missing values
      *
      * @param partCols  List[String] - Columns that will be used to partition the data
      * @param unitCol   String - Name of column containing identifier for each unit
      * @param timeCol   String - Name of column contain time period for data
      * @param targetCol String - Name of column that will be imputed
      * @param outputCol String - Name of output column for imputed/constructed/real values
      * @param markCol   String - Name of marker column indicating if a row is imputed/constructed/real
      * @param auxCol    String - Name of column containing auxiliary variable
      * @return
      */
    def impute(partCols: List[String], unitCol: String, timeCol: String, targetCol: String,
               outputCol: String, markCol: String, auxCol: String): DataFrame = {
      df.lagFunc(List(unitCol), List(timeCol), targetCol, 1)
        .withColumn(this.leadColumn, lead(targetCol, 1).over(Window.partitionBy(unitCol).orderBy(timeCol)))
        .mark(markCol, targetCol, auxCol, timeCol, partCols, unitCol)
        .addLinkCols(partCols, timeCol, targetCol, auxCol, markCol)
        .doConstruction(partCols, timeCol, targetCol, auxCol, markCol)
        .doImputation(markCol)
        //        .doAverageWeightedImputation(partCols, timeCol, targetCol, auxCol, markCol, unitCol, 1, 0.5)
        .finaliseOutput(markCol, outputCol, targetCol, auxCol)
    }

    /** Add columns for construction link, forward imputation link and backward imputation link
      *
      * @param partCols  List[String] - Columns that will be used to partition the data
      * @param timeCol   String - Name of column contain time period for data
      * @param targetCol String - Name of column that will be imputed
      * @param auxCol    String - Name of column containing auxiliary variable
      * @param markCol   String - Name of marker column indicating if a row is imputed/constructed/real
      * @return
      */
    protected def addLinkCols(partCols: List[String], timeCol: String,
                              targetCol: String, auxCol: String, markCol: String): DataFrame = {
      val partitionAndTime: List[String] = partCols :+ timeCol
      val realVals: DataFrame = df.filter(col(markCol) === "r")
      val conLinks = realVals
        .filter(col(auxCol).isNotNull)
        .groupBy(partitionAndTime map col: _*)
        .agg(
          sum(targetCol).alias(this.sumTarget),
          sum(auxCol).alias(this.sumAux))
        .withColumn(this.conLink,
          col(this.sumTarget) / col(this.sumAux))
        .drop(this.sumTarget) // calculate construction link
      val forLinks = realVals
        .filter(col(this.laggedColumn).isNotNull)
        .groupBy(partitionAndTime map col: _*)
        .agg(
          sum(targetCol).alias(this.sumTarget),
          sum(this.laggedColumn).alias(this.laggedSumTarget))
        .withColumn(this.impLink,
          col(this.sumTarget) / col(this.laggedSumTarget))
        .drop(this.sumTarget) // calculate imputation link
      val backLinks = realVals
        .filter(col(this.leadColumn).isNotNull)
        .groupBy(partitionAndTime map col: _*)
        .agg(
          sum(targetCol).alias(this.sumTarget),
          sum(this.leadColumn).alias(this.leadSumTarget))
        .withColumn(this.backImpLink,
          col(this.sumTarget) / col(this.leadSumTarget))
        .drop(this.sumTarget)
      df.join(forLinks, partitionAndTime, "left")
        .join(backLinks, partitionAndTime, "left")
        .join(conLinks, partitionAndTime, "left") // left join of original DataFrame with DataFrame of imputation links
    }

    /** Constructs value for first return in group without real value
      *
      * @param partCols  List[String] - Columns that will be used to partition the data
      * @param timeCol   String - Name of column contain time period for data
      * @param targetCol String - Name of column that will be imputed
      * @param auxCol    String - Name of column containing auxiliary variable
      * @param markCol   String - Name of marker column indicating if a row is imputed/constructed/real
      * @return
      */
    protected def doConstruction(partCols: List[String], timeCol: String, targetCol: String, auxCol: String,
                                 markCol: String): DataFrame = {
      // add construction for turnover
      df.withColumn(constructedVal, when(col(markCol) === "c",
        round(col(this.conLink) * col(auxCol), 2)).otherwise(null))
    }

    /** Imputes values for rows with null values
      *
      * @param markCol String - Name of marker column indicating if a row is imputed/constructed/real
      * @return
      */
    protected def doImputation(markCol: String): DataFrame = {
      df.withColumn(imputeVal, when(col(markCol) === "fi",
        round(col(this.impLink) * col(this.laggedColumn), 2))
        .otherwise(when(col(markCol) === "bi", round(col(this.backImpLink) * col(this.leadColumn), 2))
          .otherwise(null))) // calculate imputation
    }

    /*
      Imputes values for rows with null values using an imputation link based on an average of imputation links for
      more than one period
      lag - int indicating how far back the imputation link is to be fetched
      weight - double between 0-1 e.g. 0.5 (fifty percent weighting between the links)
     */
    protected def doAverageWeightedImputation(partCols: List[String], timeCol: String, targetCol: String, auxCol: String,
                                              markCol: String, unitCol: String, lagVal: Int, weight: Double): DataFrame = {
      val window = Window.partitionBy(unitCol).orderBy(timeCol)
      df.withColumn("laggedImpLink", lag(this.impLink, lagVal).over(window)) // column for the lagged imputation link
        .withColumn("avgImp", (col(this.impLink) * weight) + col("laggedImpLink") * (1 - weight)) // calculate the average weighted imputation link
        .withColumn("AverageImputation", when(col(markCol) === "fi", round(col("avgImp") * col(this.laggedColumn), 2))) // calculate imputed value using
      // average imputation link
    }

    /** Mark the rows indicating that they have been constructed, imputed or are real.
        e: error
        r: real value
        c: constructed value
        fi: forward imputed value
        bi: backward imputed value
      *
      * @param markCol   String - Name of marker column indicating if a row is imputed/constructed/real
      * @param targetCol String - Name of column that will be imputed
      * @param auxCol    String - Name of column containing auxiliary variable
      * @param timeCol   String - Name of column contain time period for data
      * @param partCols  List[String] - Columns that will be used to partition the data
      * @param unitCol   String - Name of column containing identifier for each unit
      * @return
      */
    protected def mark(markCol: String, targetCol: String, auxCol: String, timeCol: String,
                       partCols: List[String], unitCol: String): DataFrame = {
      // TODO: construction value with small group
      val partAndUnit: List[String] = partCols :+ unitCol // List of partition columns and unit column to be grouped
      // Filter for real values, grouping with partAndUnit List, finding the minimum time return for each group
      val minTime = df.filter(col(targetCol).isNotNull)
        .groupBy(partAndUnit map col: _*)
        .agg(min(timeCol).alias(this.firstReturnPeriod))
      val dfWithMinTime = df.join(minTime, partAndUnit, "left")
      dfWithMinTime.withColumn(markCol, when(col(targetCol).isNull && col(auxCol).isNull, "e")
        .otherwise(when(col(targetCol).isNotNull, "r")
          .otherwise(when(col(timeCol) < col(this.firstReturnPeriod) && col(targetCol).isNull, "bi") // if timeCol is less than the
            // minimum first real return for the group and the target column is null then the unit will need to be backwards imputed
            .otherwise(when(col(timeCol) > col(this.firstReturnPeriod) && col(targetCol).isNull, "fi") // if timeCol is greater
            // than the minimum first real return for the group and the target column is null then the unit will need to be forward imputed
            .otherwise(when(col(this.firstReturnPeriod).isNull, "c") // if the unit has no returns the value must be
            // constructed
          )
          )
          )
        )
      )
    }

    /*
      Merge columns into one output column
     */
    protected def finaliseOutput(markCol: String, outputCol: String, targetCol: String, auxCol: String): DataFrame = {
      df.withColumn(outputCol, when(col(markCol) === "c", col(constructedVal))
        .otherwise(when(col(markCol) === "fi" || col(markCol) === "bi", col(imputeVal))
          .otherwise(when(col(markCol) === "r", col(targetCol))
            .otherwise(null)
          )
        )
      ).drop(constructedVal)
        .drop(imputeVal)
        .drop(laggedSumTarget)
        .drop(laggedColumn)
        .drop(sumAux)
        .drop(impLink)
        .drop(conLink)
        .drop(backImpLink)
        .drop(leadColumn)
        .drop(leadSumTarget)
        .drop(firstReturnPeriod)
    }
  }

}
