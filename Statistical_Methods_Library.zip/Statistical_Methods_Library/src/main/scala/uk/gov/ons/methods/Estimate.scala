package uk.gov.ons.methods

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{col, lit, _}
import org.apache.spark.sql.{DataFrame, functions => F}
import scala.collection.mutable.ListBuffer
import org.apache.spark.sql.types._



object Estimate extends BaseMethod {

    /**
      * Public method that estimates a weighting of a target column based on the simple relationship of sample
      * values to unknown population values, optionally allows for strata to be honoured. This is also referred to as
      * Horvits-Thompson estimation.
      *
      * @author martyn.spooner@ons.gov.uk, danny.fiske@ons.gov.uk, stuart.russell@ons.gov.uk
      * @version 1.0
      * @since 1.0
      * @param targetColumn String          - Column name that to be estimated from.
      * @param strataColumn Option[String]  - Column name to be partitioned on.
      * @param flagExclude Option[String]   - Identifies a single strata to exclude from flagging.
      * @param isTrimmed Boolean            - Flag to disregard marked records in estimation.
      * @return DataFrame
      */
    def estimateWeightByExpansion(df: DataFrame, targetColumn: String, strataColumn: Option[String] = None, flagExclude: Option[String] = None,
                                  isTrimmed: Boolean = false): DataFrame = {

      var dfEstimated: DataFrame = df
      var sampleCount: DataFrame = null
      var populationCount: DataFrame = null
      var estimatedWeights: DataFrame = null
      var estimatedFlagged: DataFrame = null

      if (strataColumn.isDefined) {

        if (isTrimmed) {

          sampleCount = dfEstimated.where(col(targetColumn).isNotNull && col("is_trimmed").isNull).groupBy(strataColumn.get).count()
          populationCount = dfEstimated.where(col("is_trimmed").isNull).groupBy(strataColumn.get).count()
        }
        else {

          sampleCount = dfEstimated.where(col(targetColumn).isNotNull).groupBy(strataColumn.get).count()
          populationCount = dfEstimated.groupBy(strataColumn.get).count()
        }

        sampleCount = sampleCount.withColumnRenamed(strataColumn.get, strataColumn.get + "2")
                                 .withColumnRenamed("count", "count_sample")

        populationCount = populationCount.withColumnRenamed(strataColumn.get, strataColumn.get + "3")
                                         .withColumnRenamed("count", "count_population")

        estimatedWeights = dfEstimated.join(sampleCount, dfEstimated(strataColumn.get) === sampleCount(strataColumn.get + "2"), "right")
                                      .join(populationCount, dfEstimated(strataColumn.get) === populationCount(strataColumn.get + "3"), "right")
                                      .withColumn("design_weight", expr("count_population / count_sample"))
                                      .drop(strataColumn.get + "2", strataColumn.get + "3")

        val estimatedFlagged = getFlags((estimatedWeights), ("Flag"), (strataColumn.get), ("count_sample"), ("count_population"), Option(flagExclude.getOrElse(null)))
        return estimatedFlagged

      }
      else {

        if (isTrimmed) {

          dfEstimated = dfEstimated.withColumn("count_sample", lit(dfEstimated.where(col(targetColumn).isNotNull && col("is_trimmed").isNull).count()))
                                   .withColumn("count_population", lit(dfEstimated.where(col("is_trimmed").isNull).count()))
        }
        else {

          dfEstimated = dfEstimated.withColumn("count_sample", lit(dfEstimated.where(col(targetColumn).isNotNull).count()))
                                   .withColumn("count_population", lit(dfEstimated.count()))
        }

        dfEstimated.withColumn("design_weight", expr("count_population / count_sample"))

      }
    }


    /**
      * Public method that estimates estimates a weighting of a target column based on an auxiliary variable,
      * optionally allows for strata to be honoured.
      *
      * @author martyn.spooner@ons.gov.uk, danny.fiske@ons.gov.uk, stuart.russell@ons.gov.uk
      * @version 1.0
      * @since 1.0
      * @param targetColumn String          - Column name that to be estimated from.
      * @param auxiliaryColumn String       - Column name of auxiliary values to produce a weight.
      * @param strataColumn Option[String]  - Column name to be partitioned on.
      * @param isTrimmed Boolean            - Flag to disregard marked records in estimation.
      * @return DataFrame
      */
    def estimateWeightByRatio(df: DataFrame, targetColumn: String, auxiliaryColumn: String, strataColumn: Option[String] = None,
                              isTrimmed: Boolean = false): DataFrame = {

      var dfEstimated: DataFrame = df.estimateWeightByExpansion(targetColumn, strataColumn, isTrimmed)
      var sampleSum: DataFrame = null
      var populationSum: DataFrame = null

      if (strataColumn.isDefined) {

        if (isTrimmed) {

          sampleSum = dfEstimated.where(col(targetColumn).isNotNull && col("is_trimmed").isNull).groupBy(strataColumn.get).sum(auxiliaryColumn)
          populationSum = dfEstimated.where(col("is_trimmed").isNull).groupBy(strataColumn.get).sum(auxiliaryColumn)
        }
        else {

          sampleSum = dfEstimated.where(col(targetColumn).isNotNull).groupBy(strataColumn.get).sum(auxiliaryColumn)
          populationSum = dfEstimated.groupBy(strataColumn.get).sum(auxiliaryColumn)
        }

        sampleSum = sampleSum.withColumnRenamed(strataColumn.get, strataColumn.get + "2")
                             .withColumnRenamed("sum(" + auxiliaryColumn + ")", "strata_sum_sample_" + auxiliaryColumn)

        populationSum = populationSum.withColumnRenamed(strataColumn.get, strataColumn.get + "3")
                                     .withColumnRenamed("sum(" + auxiliaryColumn + ")", "strata_sum_population_" + auxiliaryColumn)

        dfEstimated.join(sampleSum, dfEstimated(strataColumn.get) === sampleSum(strataColumn.get + "2"), "right")
                   .join(populationSum, dfEstimated(strataColumn.get) === populationSum(strataColumn.get + "3"), "right")
                   .withColumn("calibration_weight", expr("strata_sum_population_" + auxiliaryColumn + " / (strata_sum_sample_" + auxiliaryColumn + " * design_weight)"))
                   .drop(strataColumn.get + "2", strataColumn.get + "3")
      }
      else {

        if (isTrimmed) {

          dfEstimated = dfEstimated.withColumn("sum_sample_" + auxiliaryColumn,
                                               lit(dfEstimated.where(col(targetColumn).isNotNull && col("is_trimmed").isNull)
                                                              .agg(sum(auxiliaryColumn))
                                                              .first()
                                                              .get(0)))
                                   .withColumn("sum_population_" + auxiliaryColumn,
                                               lit(dfEstimated.where(col("is_trimmed").isNull)
                                                              .agg(sum(auxiliaryColumn))
                                                              .first()
                                                              .get(0)))
        }
        else {

          dfEstimated = dfEstimated.withColumn("sum_sample_" + auxiliaryColumn,
                                               lit(dfEstimated.where(col(targetColumn).isNotNull)
                                                              .agg(sum(auxiliaryColumn))
                                                              .first()
                                                              .get(0)))
                                   .withColumn("sum_population_" + auxiliaryColumn,
                                               lit(dfEstimated.agg(sum(auxiliaryColumn))
                                                              .first()
                                                              .get(0)))
        }

        dfEstimated.withColumn("calibration_weight", expr("sum_population_" + auxiliaryColumn + " / (sum_sample_" + auxiliaryColumn + " * design_weight)"))

      }
    }


    private def getFlags(input: DataFrame, flagCol: String, grpclassCol: String, cntFocusSamp: String, cntFocusPop: String,
                           flagging_exc: Option[String] = None): DataFrame = {
      // apply a flag to the DataFrame based on the grouping classification
      if (flagging_exc.isDefined){
      input.withColumn(flagCol, F.when(F.col(grpclassCol) === flagging_exc.get, 1)
                                 .when((F.col(cntFocusSamp) < 2) && (F.col(cntFocusSamp) !== F.col(cntFocusPop)), 2)
                                 .when((F.col(cntFocusSamp) < 2) && (F.col(cntFocusSamp) === F.col(cntFocusPop)), 3)
                                 .when((F.col(cntFocusSamp) > 1) && (F.col(cntFocusSamp) === F.col(cntFocusPop)), 4)
                                 .otherwise(0))}
      else {
      input.withColumn(flagCol, F.when((F.col(cntFocusSamp) < 2) && (F.col(cntFocusSamp) !== F.col(cntFocusPop)), 2)
                                 .when((F.col(cntFocusSamp) < 2) && (F.col(cntFocusSamp) === F.col(cntFocusPop)), 3)
                                 .when((F.col(cntFocusSamp) > 1) && (F.col(cntFocusSamp) === F.col(cntFocusPop)), 4)
                                 .otherwise(0))}
    }


    def applyEstimateWeights(df: DataFrame, weightCol: String, auxCol: String, targetCol: String, strataCol: Option[String] = None ): DataFrame = {

    val weightApplied: DataFrame = df.withColumn("Estimated_Calc", F.col(weightCol) * F.col(auxCol))
    val estimated:     DataFrame = weightApplied.withColumn("Estimated_Output", F.when(F.col(targetCol).isNotNull, F.col(targetCol))
                                              .otherwise(F.col("Estimated_Calc")))
    val residual:      DataFrame = estimated.withColumn("Residual", F.col("Estimated_Output") - F.col("Estimated_Calc"))
                                            .withColumn("Residual_Perc", F.col("Residual") / F.col("Estimated_Output"))
                                            .withColumn("Residual_Perc", F.col("Residual_Perc").cast(DecimalType(32,5)))
      if (strataCol.isDefined){
        val stddevout:     DataFrame = residual.groupBy(strataCol.get).agg(stddev("Estimated_Calc"))
        val stddevcombi:   DataFrame = residual.join(stddevout, (weightApplied(strataCol.get) === stddevout(strataCol.get)), "left")
        return stddevcombi
      } else {
        return residual
      }

    }


}


