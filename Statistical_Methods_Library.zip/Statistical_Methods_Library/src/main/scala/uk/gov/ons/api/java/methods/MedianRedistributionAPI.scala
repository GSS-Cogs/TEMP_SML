package uk.gov.ons.api.java.methods

import java.util

import org.apache.spark.sql.{DataFrame, Dataset, Row}
import uk.gov.ons.methods.MedianRedistribution

import scala.collection.JavaConversions._

class MedianRedistributionAPI[K](mr: MedianRedistribution) {

  /** This function will call the function defined in methods.MedianRedistribution. It acts as a gateway between the Java and the scala.
    * Any translations from Java Types to Scala types is done here.
    *
    * @author tom.reilly@ext.ons.gov.uk
    * @version 1.0
    * @since 1.0
    * @param partitionCol String - Name of the column to partition on
    * @param timeCol      String - Name of the column containg the timeperiod data
    * @param markerCol    String - Name of the column that contains the markers
    * @param typeCol      String - Name of the column that contains the record type
    * @param targetCol    String - Name of the column that is to be redistributed
    * @param uncleanVals  ArrayList[String] - Markers that denote unclean records
    * @param outCol       String - Name of the column to contain the output
    * @return DataFrame
    */
  def medianRedistributionMethod(df: DataFrame, partitionCol: String, timeCol: String,
                                 markerCol: String, typeCol: String, targetCol: String,
                                 uncleanVals: util.ArrayList[String], outCol: String): DataFrame = {
    mr.medianRedistributionMethod(df, partitionCol, timeCol, markerCol,
      typeCol, targetCol, uncleanVals.toList, outCol)
  }
}

object MedianRedistributionAPI {
  def medianRedistribution(df: Dataset[Row]): MedianRedistributionAPI[MedianRedistribution] = {
    new MedianRedistributionAPI(MedianRedistribution.medianRedistribution(df))
  }
}