package uk.gov.ons.methods.impl

import org.apache.spark.sql.{DataFrame, functions => F}

object RatioEstimationImpl {

  implicit class RatioEstimationMethodsImpl(df: DataFrame) {

    /** This method estimates values where non-response is present in a dataset using a ratio methodology.
      * Using an auxiliary variable to compute a ratio for a target data column (target_estimation_col) estimation can be achieved.
      * Typically the target_estimation_col will be a monetry or growth item.
      * To form the ratio, a sampled dataset containing both the response and non-response is required in addition to a
      * population dataset where the auxiliary variable can be sourced and referenced.
      * The sample and population datasets are typically to be of the same grouping classification.
      * A focus is required to identify each record / data row.
      * As noted, this estimation method is based on a grouping classification, i.e. this could be for example a
      * reporting unit's SIC cell or a sampled age range etc.
      * A singular grouping classification can be excluded using flagging_exclude (String).
      * The method produces uncertanty metrics to evaluate the quality / accuracy of the estimate.
      *
      * @author martyn.spooner@ons.gov.uk
      * @version 1.0
      *
      * @param df_population                          Dataset     - Population dataset required for the ratio calculation.
      * @param grouping_classification_col            String      - Used to identify the grouping classification.
      * @param reporting_period_col                   String      - Used to identify the reporting period.
      * @param auxiliary_variable_col                 String      - Used to identify the auxiliary variable.
      * @param focus_col                              String      - Used to identify the focus (the primary key).
      * @param target_estimation_col                  String      - Used to identify the estimation target.
      * @param population_grouping_classification_col String      - Used to identify the population grouping classification.
      * @param population_reporting_period_col        String      - Used to identify the population reporting period.
      * @param population_auxiliary_variable_col      String      - Used to identify the population auxiliary variable.
      * @param population_focus_col                   String      - Used to identify the population focus (the primary key).
      * @param bln_flag_focus_or_grpclass             Boolean     - Used to identify the output from the method (True = focus / False = grouping classification).
      * @param flagging_exclude                       String      - Used to identify during the flagging process a singular grouping classification to exclude.
      * @return Dataframe                             Dataset     - Returned dataset based on flag, either at focus or grouping classification aggregation.
      */

    def ratioEstimationMethodMain(
                                    df_population: DataFrame,
                                    grouping_classification_col: String,
                                    reporting_period_col: String,
                                    auxiliary_variable_col: String,
                                    focus_col: String,
                                    target_estimation_col: String,
                                    population_grouping_classification_col: String,
                                    population_reporting_period_col: String,
                                    population_auxiliary_variable_col: String,
                                    population_focus_col: String,
                                    bln_flag_focus_or_grpclass: Boolean,
                                    flagging_exclude: String
                                  ): (DataFrame) = {

        //Population counts and grouping classification grouping totals - sthis sums the actual auxilary data, for example this could be frozen turnover or past period data etc:
        val populationCount: DataFrame = df_population.groupBy(population_grouping_classification_col, population_reporting_period_col)
          .agg(F.sum(population_auxiliary_variable_col).alias("sum_of_auxiliary_variable_population"),
          F.count(population_focus_col).alias("count_of_focus_population"))

        //Same counts and group by sums for the input data frame (sample) non-inclusive of null returns - this sums the acutal sample returns:
        val sampleCount = df.where(F.col(target_estimation_col).isNotNull).groupBy(grouping_classification_col, reporting_period_col)
          .agg(F.sum(auxiliary_variable_col).alias("sum_of_auxiliary_variable_sample"),
          F.sum(target_estimation_col).alias("sum_of_target_sample"),
          F.count(focus_col).alias("count_of_focus_sample"))

        //Join sample and population data frames:
        val joinCounts: DataFrame = populationCount.join(sampleCount,
          (populationCount(population_grouping_classification_col) === sampleCount(grouping_classification_col)) &&
                 (populationCount(population_reporting_period_col) === sampleCount(reporting_period_col)), "left_outer")

        //Replace nulls where sample counts are non-existant with a zero for future estimation routines:
        val fillNulls: DataFrame = joinCounts.na.fill(0.0, Seq("count_of_focus_sample"))

        //Add flags to the grouping classification level DataFrame:
        val flagged: DataFrame = getFlags(fillNulls, "ratio_estimation_flag", grouping_classification_col, "count_of_focus_sample", "count_of_focus_population", flagging_exclude)
          .withColumnRenamed(grouping_classification_col, "grouping_classification_beta")
          .withColumnRenamed(reporting_period_col, "reporting_period_beta")

        //Add grouping classification column:
        val betaCol: DataFrame = flagged.withColumn("beta_grouping_classification", F.when(F.col("ratio_estimation_flag") === 0,
          F.col("sum_of_target_sample") / F.col("sum_of_auxiliary_variable_sample")).otherwise(null))

        //Join calculations back onto original (sampled) DF input:
        val betaColJoined: DataFrame = df.join(betaCol, df(reporting_period_col) === betaCol("reporting_period_beta") &&
                                                 df(grouping_classification_col) === betaCol("grouping_classification_beta"), "inner")

        //Estimated target calculation:
        val estimatedTarget: DataFrame = betaColJoined.withColumn("estimated_target_by_grouping_classification",
          F.when(F.col("beta_grouping_classification").isNotNull,
          F.col("beta_grouping_classification") * F.col(auxiliary_variable_col)).otherwise(null))

        //Residual target calculation:
        val residualTarget = estimatedTarget.withColumn("residual_target_by_grouping_classification",
          F.when(F.col("estimated_target_by_grouping_classification").isNotNull,
          F.col(target_estimation_col) - F.col("estimated_target_by_grouping_classification")).otherwise(null))
          val estimated_focus: DataFrame = residualTarget

        //SQR (square root) delta calculation:
        val sqrDelta: DataFrame = residualTarget.withColumn("sum_of_Sqr_DeltaRft",
          F.when(F.col("residual_target_by_grouping_classification").isNotNull,
          F.col("residual_target_by_grouping_classification") * F.col("residual_target_by_grouping_classification")).otherwise(null))

        //Cleam SQR DF and fill null values:
        val fillNulls2: DataFrame = sqrDelta.na.fill(0.0, Seq("sum_of_Sqr_DeltaRft"))

        //Calculate the sum of sqr delta rft:
        val sumSqrDeltaRft: DataFrame = fillNulls2.groupBy(grouping_classification_col, reporting_period_col,
          "ratio_estimation_flag", "beta_grouping_classification", "count_of_focus_sample", "count_of_focus_population",
          "sum_of_target_sample", "sum_of_auxiliary_variable_sample", "sum_of_auxiliary_variable_population")
          .agg(F.sum("sum_of_Sqr_DeltaRft").alias("sum_of_Sqr_DeltaRft"))

        //Estimated target for grouping classification:
        val estGrpClassTarget: DataFrame = sumSqrDeltaRft.withColumn("estimated_target_by_grouping_population",
          F.when(F.col("ratio_estimation_flag") === 0,
          F.col("beta_grouping_classification") * F.col("sum_of_auxiliary_variable_population"))
          .otherwise(null))

        //Add SQR:
        val sqrRootDeltaRft: DataFrame = estGrpClassTarget.withColumn("root_sum_sqr", F.sqrt("sum_of_Sqr_DeltaRft"))

        // Find standard error and set to null where flag is not 0
        val standardError: DataFrame = findStandardError(sqrRootDeltaRft, "standard_error", "ratio_estimation_flag",
                                                         "root_sum_sqr", "count_of_focus_population", "count_of_focus_sample")
        val stderrNull: DataFrame = standardError.withColumn("standard_error",
          F.when(F.col("ratio_estimation_flag") === 0, F.col("ratio_estimation_flag")).otherwise(null))

        // Add cord target
        val estimatedGrpClass: DataFrame = stderrNull.withColumn("final_target",
          F.when(F.col("estimated_target_by_grouping_population").isNotNull,
          F.col("estimated_target_by_grouping_population"))
            .otherwise(F.when(F.col("sum_of_target_sample").isNotNull,
            F.col("sum_of_target_sample")).otherwise(0)))


        if (bln_flag_focus_or_grpclass == true) {
          estimated_focus};
        else {
          estimatedGrpClass
        };


    }

  }


  //Flaging is semi-bespoke to VAT methods. Values such as 0000 are explicitly referenced and used!
  def getFlags(input: DataFrame, flagCol: String, grpclassCol: String, cntFocusSamp: String, cntFocusPop: String, flagging_exc: String): DataFrame = {
    // apply a flag to the DataFrame based on the grouping classification
    input.withColumn(flagCol, F.when(F.col(grpclassCol) === flagging_exc, 1).when((F.col(cntFocusSamp) < 2) &&
      (F.col(cntFocusSamp) !== F.col(cntFocusPop)), 2).when((F.col(cntFocusSamp) < 2) &&
      (F.col(cntFocusSamp) === F.col(cntFocusPop)), 3).when((F.col(cntFocusSamp) > 1) &&
      (F.col(cntFocusSamp) === F.col(cntFocusPop)), 4).otherwise(0))
  }

  //Standard Error sub-component:
  def findStandardError(dataframe: DataFrame, std_err_col: String, flag_col: String, root_sum_sqr_col: String,
                        count_focus_population: String, count_focus_sample: String): DataFrame = {
    val standard_df = dataframe.withColumn(std_err_col, F.when(
                                                               F.col(flag_col) === 0,
                                                               F.sqrt((F.col(count_focus_population)/F.col(count_focus_sample))
                                                                 *((F.col(count_focus_population)-F.col(count_focus_sample))
                                                                 /(F.col(count_focus_sample)-1)))*F.col(root_sum_sqr_col))
                                                               .otherwise(null))

    standard_df

  }

}
