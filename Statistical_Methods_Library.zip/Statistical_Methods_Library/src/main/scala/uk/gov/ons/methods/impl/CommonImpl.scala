package uk.gov.ons.methods.impl

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, lag, sum, round}
import org.apache.spark.sql.{Column, DataFrame}

object CommonImpl {

  implicit class CommonMethodsImpl(df: DataFrame) {
    /** This function sums a column within a partition and rejoins it to the original dataset
      *
      * @author tom.reilly@ext.ons.gov.uk
      * @version 1.0
      * @since 1.0
      * @param partCols List[String] - Name of the column(s) to partition on
      * @param sumCol   String - Name of the column to be summed
      * @param newCol   String - Name of the column to contain the output
      * @return
      */
    def sumAndJoin(partCols: List[String], sumCol: String, newCol: String): DataFrame = {
      val summedDf: DataFrame = df.groupBy(partCols.head, partCols.tail: _*)
        .agg(round(sum(sumCol), 2).alias(newCol))
      // Join the summed weights
      df.join(summedDf, partCols, "left")
    }

    /**
      * @param partitionCols List[String]                 - List of column(s) to partition on
      * @param orderCols     List[String]                     - List of column(s) to order on
      * @param targetCol     String                           - Column name to create a window over
      * @param lagNum        Integer                             - The number of rows back from the current row from which to obtain a value
      * @return sql.DataFrame                             - The DataFrame returned
      */
    def lagFunc(partitionCols: List[String],
                orderCols: List[String], targetCol: String, lagNum: Int): DataFrame = {

      val pCols: List[Column] = partitionCols.map(s => col(s))
      val oCols: List[Column] = orderCols.map(s => col(s))
      // Create window
      val w = Window.partitionBy(pCols: _*).orderBy(oCols: _*)
      // Lag target
      var df2: DataFrame = df
      for (i <- 1 to lagNum) {
        df2 = df2.withColumn(s"lagged$i", lag(targetCol, i, null).over(w))
      }
      df2
    }
  }

}
