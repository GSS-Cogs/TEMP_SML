package uk.gov.ons.methods

import org.apache.spark.sql.DataFrame

class Outliering(val df: DataFrame) extends BaseMethod {

  if (df == null) throw new Exception("DataFrame cannot be null")

  import uk.gov.ons.methods.impl.OutlieringImpl._

  /**
    * Public method that ranks data by targetColumn and removes a percentage of records based on user input,
    * can optionally honour stratification.
    *
    * @author danny.fiske@ons.gov.uk, stuart.russell@ons.gov.uk
    * @version 1.0
    * @since 1.0
    * @param targetColumn String          - Column name that to be estimated from.
    * @param strataColumn Option[String]  - Column name to be partitioned on.
    * @param trimTop      Double          - Percentage of records to be removed from top of targetColumn-ordered data.
    * @param trimBottom   Double          - Percentage of records to be removed from bottom of targetColumn-ordered data.
    * @return DataFrame
    */
  def trimOutliers(targetColumn: String, strataColumn: Option[String] = None,
                   trimTop: Double = 0.0, trimBottom: Double = 0.0): DataFrame = {

    mandatoryArgCheck(targetColumn, trimTop, trimBottom)
    df.trimOutliers(targetColumn, strataColumn, trimTop, trimBottom)
  }
}
