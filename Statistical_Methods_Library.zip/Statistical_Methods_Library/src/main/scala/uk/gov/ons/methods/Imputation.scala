package uk.gov.ons.methods

import org.apache.spark.sql.DataFrame

class Imputation(val dfIn: DataFrame) extends BaseMethod {
  if (dfIn == null) throw new Exception("DataFrame cannot be null")

  import uk.gov.ons.methods.impl.ImputationImpl._

  /** Marks, constructs and imputes missing values
    *
    * @param df         DataFrame - The input DataFrame for the function to be applied to
    * @param partCols   List[String] - Columns that will be used to partition the data
    * @param unitCol    String - Name of column containing identifier for each unit
    * @param timeCol    String - Name of column contain time period for data
    * @param targetCol  String - Name of column that will be imputed
    * @param outputCol  String - Name of output column for imputed/constructed/real values
    * @param markerCol  String - Name of marker column indicating if a row is imputed/constructed/real
    * @param auxCol     String - Name of column containing auxiliary variable
    * @return
    */
  def impute(df: DataFrame = dfIn, partCols: List[String], unitCol: String, timeCol: String, targetCol: String,
             outputCol: String, markerCol: String, auxCol: String): DataFrame = {
    mandatoryArgCheck(partCols.flatten, timeCol, targetCol, outputCol, auxCol)
    df.impute(partCols, unitCol, timeCol, targetCol, outputCol, markerCol, auxCol)
  }
}

object Imputation {
  def imputation(df: DataFrame): Imputation = new Imputation(df)
}