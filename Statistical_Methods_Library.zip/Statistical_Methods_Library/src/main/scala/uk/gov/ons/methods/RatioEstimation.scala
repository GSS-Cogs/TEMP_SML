package uk.gov.ons.methods

import org.apache.spark.sql.DataFrame

class RatioEstimation(val dfIn: DataFrame) extends BaseMethod {


  import uk.gov.ons.methods.impl.RatioEstimationImpl._

  if (dfIn == null) throw new Exception("DataFrame cannot be null")

  /** This method estimates values where non-response is present in a dataset using a ratio methodology.
    *
    * @author martyn.spooner@ons.gov.uk
    * @version 1.0
    *
    * @param df_population                          Dataset     - Population dataset required for the ratio calculation.
    * @param grouping_classification_col            String      - Used to identify the grouping classification.
    * @param reporting_period_col                   String      - Used to identify the reporting period.
    * @param auxiliary_variable_col                 String      - Used to identify the auxiliary variable.
    * @param focus_col                              String      - Used to identify the focus (the primary key).
    * @param target_estimation_col                  String      - Used to identify the estimation target.
    * @param population_grouping_classification_col String      - Used to identify the population grouping classification.
    * @param population_reporting_period_col        String      - Used to identify the population reporting period.
    * @param population_auxiliary_variable_col      String      - Used to identify the population auxiliary variable.
    * @param population_focus_col                   String      - Used to identify the population focus (the primary key).
    * @param bln_flag_focus_or_grpclass             Boolean     - Used to identify the output from the method (True = focus / False = grouping classification).
    * @param flagging_exclude                       String      - Used to identify during the flagging process a singular grouping classification to exclude.
    * @return Dataframe                             Dataset     - Returned dataset based on flag, either at focus or grouping classification aggregation.
    */
  def ratioEstimationMethod(input: DataFrame = dfIn,
                            df_population: DataFrame,
                            grouping_classification_col: String,
                            reporting_period_col: String,
                            auxiliary_variable_col: String,
                            focus_col: String,
                            target_estimation_col: String,
                            population_grouping_classification_col: String,
                            population_reporting_period_col: String,
                            population_auxiliary_variable_col: String,
                            population_focus_col: String,
                            bln_flag_focus_or_grpclass: Boolean,
                            flagging_exclude: String
                                 ): (DataFrame) = {
                                          mandatoryArgCheck(grouping_classification_col, reporting_period_col,
                                                            auxiliary_variable_col, focus_col, target_estimation_col,
                                                            population_grouping_classification_col, population_reporting_period_col,
                                                            population_auxiliary_variable_col, population_focus_col,
                                                            bln_flag_focus_or_grpclass, flagging_exclude)
                                          input.ratioEstimationMethodMain(
                                                                      df_population,
                                                                      grouping_classification_col,
                                                                      reporting_period_col,
                                                                      auxiliary_variable_col,
                                                                      focus_col,
                                                                      target_estimation_col,
                                                                      population_grouping_classification_col,
                                                                      population_reporting_period_col,
                                                                      population_auxiliary_variable_col,
                                                                      population_focus_col,
                                                                      bln_flag_focus_or_grpclass,
                                                                      flagging_exclude
                                                                     )
                                                }

}

/**
  * Initialisation...
  */
object RatioEstimation
{
  def ratioEstimation(df: DataFrame): RatioEstimation = new RatioEstimation(df)
}
