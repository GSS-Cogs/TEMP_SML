package uk.gov.ons.api.java.methods

import org.apache.spark.sql.{DataFrame, Dataset, Row}
import uk.gov.ons.methods.Estimate

import scala.collection.JavaConversions._

object EstimateAPI {

  /**
    * Scala method that calls the Estimate implicit method.
    * Method acts as a bridge between Java and Scala.
    *
    * @author martyn.spooner@ons.gov.uk
    * @version 1.0
    * @since 1.0
    * @param targetColumn String          - Column name that to be estimated from.
    * @param strataColumn Option[String]  - Column name to be partitioned on.
    * @param flagExclude Option[String]   - Identifies a single strata to exclude from flagging.
    * @param isTrimmed Boolean            - Flag to disregard marked records in estimation.
    * @return DataFrame
    */
    def estimateWeightByExpansion(df: Dataset[Row], targetColumn: String, strataColumn: String, flagExclude: String,
                                  isTrimmed: Boolean = false): DataFrame = {
    Estimate.estimateWeightByExpansion(df, targetColumn, Option(strataColumn), Option(flagExclude), isTrimmed)
    }

    /**
      * @author martyn.spooner@ons.gov.uk, danny.fiske@ons.gov.uk, stuart.russell@ons.gov.uk
      * @version 1.0
      * @since 1.0
      * @param targetColumn String          - Column name that to be estimated from.
      * @param auxiliaryColumn String       - Column name of auxiliary values to produce a weight.
      * @param strataColumn Option[String]  - Column name to be partitioned on.
      * @param isTrimmed Boolean            - Flag to disregard marked records in estimation.
      * @return DataFrame
      */
    def estimateWeightByRatio(df: Dataset[Row], targetColumn: String, auxiliaryColumn: String, strataColumn: String,
                              isTrimmed: Boolean = false): DataFrame = {
    Estimate.estimateWeightByRatio(df, targetColumn, auxiliaryColumn, Option(strataColumn), isTrimmed)
    }

    def applyEstimateWeights(df: Dataset[Row], weightCol: String, auxCol: String, targetCol: String,
                             strataCol: String): DataFrame = {
    Estimate.applyEstimateWeights(df, weightCol, auxCol, targetCol, Option(strataCol))
    }


/**
* object Estimate {
*  def estimate(df: DataFrame): EstimateAPI[Estimate] = {
*  new EstimateAPI[Estimate](Estimate.estimate(df))
*  }
* }
*/





}