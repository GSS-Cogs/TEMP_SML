from behave import Given, When, Then
from python.sml.methods.redistribution import redistribution


@Given("the user provides the Redistribution function parameters")
def step_impl(context):

    context.part_cols = str(context.table.rows[0][0]).split(",")
    context.target_col = str(context.table.rows[0][1])
    context.new_col = str(context.table.rows[0][2])
    if context.table.rows[0][3] == 'null':
        context.weight_col = None
    else:
        context.weight_col = str(context.table.rows[0][3])


@When("the Python Redistribution function is applied")
def step_impl(context):

    if context.weight_col is None:
        context.output_df = redistribution(context.input_data)\
            .redistribute(partCols=context.part_cols,
                          targetCol=context.target_col,
                          newCol=context.new_col
                        )
        print("Input DataFrame ...")
        context.input_data.show()

        print("Output DataFrame ...")
        context.output_df.show()

        print("Expected DataFrame ...")
        context.expected_data.show()

    else:
        context.output_df = redistribution(context.input_data) \
            .redistribute(partCols=context.part_cols,
                          targetCol=context.target_col,
                          newCol=context.new_col,
                          weightCol=context.weight_col
                          )
        print("Input DataFrame ...")
        context.input_data.show()

        print("Output DataFrame ...")
        context.output_df.show()

        print("Expected DataFrame ...")
        context.expected_data.show()


@Then("the DataFrame will be redistributed correctly")
def step_impl(context):
    if context.weight_col is None:
        assert context.expected_data.select("id", "value", "output").collect() == \
            context.output_df.select("id", "value", "output").collect()
    else:
        assert context.expected_data.select("id", "value", "weights", "output").collect() == \
            context.output_df.select("id", "value", "weights", "output").collect()


