from behave import Given, When, Then


import python.sml.methods.QuarterlyPatternRulePython as QPR


@Given(u'the paramters are provided')
def the_file_paths_are_available(context):
            context.partition_cols = str(context.table.rows[0][0]).split(",")
            context.part_order_cols = str(context.table.rows[0][1]).split(",")
            context.comparisonValueColumn = str(context.table.rows[0][2])
            context.identifierColumn = str(context.table.rows[0][3])
            context.identifierValue = str(context.table.rows[0][4]).split(",")
            print("PARAMS from BDD AND:")
            print(context.partition_cols)
            print(context.part_order_cols)
            print(context.comparisonValueColumn)
            print(context.identifierColumn)
            print(context.identifierValue)

@When(u'we apply the Python QPR function to the input dataset Scenario A')
def we_apply_the_Python_QPR_function_to_the_input_dataset_Scenario_A(context):
            print("Running Python Scenario A:")
            context.qpr_output_df = QPR.quarterlyPatternRule(context.input_data).quarterlyPatternRule1(context.input_data, context.partition_cols, context.part_order_cols, context.comparisonValueColumn, context.identifierColumn, context.identifierValue)
            print("Output - Python Scenario A:")
            context.qpr_output_df.show(50)
            context.qpr_output_df.printSchema()

@When(u'we apply the Python QPR function to the input dataset Scenario B')
def we_apply_the_Python_QPR_function_to_the_input_dataset_Scenario_B(context):
            print("Running Python Scenario B:")
            context.qpr_output_df = QPR.quarterlyPatternRule(context.input_data).quarterlyPatternRule1(context.input_data, context.partition_cols, context.part_order_cols, context.comparisonValueColumn, context.identifierColumn, context.identifierValue)
            print("Output - Python Scenario B:")
            context.qpr_output_df.show(50)
            context.qpr_output_df.printSchema()

@When(u'we apply the Python QPR function to the input dataset Scenario C')
def we_apply_the_Python_QPR_function_to_the_input_dataset_Scenario_C(context):
            print("Running Python Scenario C:")
            context.qpr_output_df = QPR.quarterlyPatternRule(context.input_data).quarterlyPatternRule1(context.input_data, context.partition_cols, context.part_order_cols, context.comparisonValueColumn, context.identifierColumn, context.identifierValue)
            print("Output - Python Scenario C:")
            context.qpr_output_df.show(50)
            context.qpr_output_df.printSchema()

@Then(u'the Python QPR function correctly flags the record where the scenario pattern is identified')
def the_Python_QPR_function_correctly_flags_the_record_where_the_scenario_pattern_is_identified(context):
    print("Asset the Test - Python wrapper Expected Data:")
    assert context.qpr_output_df.select("test_financial_year", "test_period", "test_stagger", "test_turnover",
                                                  "test_vat_returns_vatref9", "lagged_1", "lagged_2",
                                                  "lagged_3", "qpr_pattern") \
        .orderBy("test_vat_returns_vatref9", "test_period").collect() == \
     context.expected_data.select("test_financial_year", "test_period", "test_stagger", "test_turnover",
                                                  "test_vat_returns_vatref9", "lagged_1", "lagged_2",
                                                  "lagged_3", "qpr_pattern") \
                           .orderBy("test_vat_returns_vatref9", "test_period").collect()

