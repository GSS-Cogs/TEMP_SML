from behave import given, when, then

from python.sml.methods.Estimation import estimation


@given("the user provides the estimateWeightByExpansion function parameters")
def given_expansion_estimation_parameters(context):

    if str(context.table.rows[0][1]) == "null": context.estimation_strata_col = None
    else: context.estimation_strata_col = str(context.table.rows[0][1])

    if str(context.table.rows[0][2]) == "null": context.estimation_is_trimmed = None
    else: context.estimation_is_trimmed = bool(context.estimation_is_trimmed[0][2] == "True")

    context.estimation_target_col = str(context.table.rows[0][0])


@given("the user provides the estimateWeightByRatio function parameters")
def given_ratio_estimation_parameters(context):

    if str(context.table.rows[0][2]) == "null": context.estimation_strata_col = None
    else: context.estimation_strata_col = str(context.table.rows[0][2])

    if str(context.table.rows[0][3]) == "null": context.estimation_is_trimmed = None
    else: context.estimation_is_trimmed = context.table.rows[0][3]

    context.estimation_target_col = str(context.table.rows[0][0])
    context.estimation_auxiliary_col = str(context.table.rows[0][1])


@when("the Python estimateWeightByExpansion function is applied.")
def estimate_expansion(context):

    if context.estimation_strata_col == "null":

        context.estimation_output = estimation(context.input_data) \
            .estimate_weight_by_expansion(target_column=context.estimation_target_col)
    else:

        context.estimation_output = estimation(context.input_data) \
            .estimate_weight_by_expansion(target_column=context.estimation_target_col,
                                          strata_column=context.estimation_strata_col,
                                          is_trimmed=context.estimation_is_trimmed)


@when("the Python estimateWeightByRatio function is applied.")
def estimate_ratio(context):
    if context.estimation_strata_col == "null":

        context.estimation_output = estimation(context.input_data) \
            .estimate_weight_by_ratio(target_column=context.estimation_target_col,
                                      auxiliary_column=context.estimation_auxiliary_col)
    else:

        context.estimation_output = estimation(context.input_data) \
            .estimate_weight_by_ratio(target_column=context.estimation_target_col,
                                      auxiliary_column=context.estimation_auxiliary_col,
                                      strata_column=context.estimation_strata_col,
                                      is_trimmed=context.estimation_is_trimmed)


@then("the target column will be extrapolated to estimate a total.")
def target_extrapolated(context):

    print("Input Data:")
    context.input_data.show()

    print("Output Data:")
    output = context.estimation_output
    output.show()

    print("Expected Output:")
    expected = context.expected_data.select(output.columns)
    expected.show()

    assert (expected.collect() == output.collect())
