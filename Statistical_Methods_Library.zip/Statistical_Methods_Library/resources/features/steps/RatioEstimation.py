from behave import Given, Then, When
import python.sml.methods.RatioEstimation as RatEst
from pyspark.sql.types import *
from common_steps import df_from_file

input_data_schema_sample_fields = [StructField("grouping_classification", StringType(), nullable=False),
                                   StructField("reporting_period", StringType(), nullable=False),
                                   StructField("auxiliary_variable", StringType(), nullable=False),
                                   StructField("focus", StringType(), nullable=False),
                                   StructField("turnover", LongType(), nullable=True),
                                   StructField("complexity", StringType(), nullable=True)
                                   ]
input_data_schema_sample_schema = StructType(input_data_schema_sample_fields)


input_data_schema_population_fields = [StructField("population_grouping_classification", StringType(), nullable=False),
                                       StructField("population_reporting_period", StringType(), nullable=False),
                                       StructField("population_auxiliary_variable", StringType(), nullable=False),
                                       StructField("population_focus", StringType(), nullable=False),
                                       StructField("population_complexity", StringType(), nullable=True)
                                       ]
input_data_schema_population_schema = StructType(input_data_schema_population_fields)

expected_data_schema_focus_fields = [StructField("grouping_classification", StringType(), nullable=True),
                                     StructField("reporting_period", StringType(), nullable=True),
                                     StructField("auxiliary_variable", StringType(), nullable=True),
                                     StructField("focus", StringType(), nullable=True),
                                     StructField("turnover", LongType(), nullable=True),
                                     StructField("complexity", StringType(), nullable=True),
                                     StructField("population_grouping_classification", StringType(), nullable=True),
                                     StructField("population_reporting_period", StringType(), nullable=True),
                                     StructField("sum_of_auxiliary_variable_population", DoubleType(), nullable=True),
                                     StructField("count_of_focus_population", LongType(), nullable=False),
                                     StructField("grouping_classification_beta", StringType(), nullable=True),
                                     StructField("reporting_period_beta", StringType(), nullable=True),
                                     StructField("sum_of_auxiliary_variable_sample", DoubleType(), nullable=True),
                                     StructField("sum_of_target_sample", LongType(), nullable=True),
                                     StructField("count_of_focus_sample", LongType(), nullable=True),
                                     StructField("ratio_estimation_flag", IntegerType(), nullable=False),
                                     StructField("beta_grouping_classification", DoubleType(), nullable=True),
                                     StructField("estimated_target_by_grouping_classification", DoubleType(), nullable=True),
                                     StructField("residual_target_by_grouping_classification", DoubleType(), nullable=True)
                                     ]
expected_data_schema_focus_schema = StructType(expected_data_schema_focus_fields)

expected_data_schema_grouping_classification_fields = [StructField("grouping_classification", StringType(), nullable=True),
                                                       StructField("reporting_period", StringType(), nullable=True),
                                                       StructField("sum_of_auxiliary_variable_sample", DoubleType(), nullable=True),
                                                       StructField("sum_of_auxiliary_variable_population", DoubleType(), nullable=True),
                                                       StructField("sum_of_target_sample", LongType(), nullable=True),
                                                       StructField("count_of_focus_sample", LongType(), nullable=True),
                                                       StructField("count_of_focus_population", LongType(), nullable=False),
                                                       StructField("ratio_estimation_flag", IntegerType(), nullable=False),
                                                       StructField("beta_grouping_classification", DoubleType(), nullable=True),
                                                       StructField("estimated_target_by_grouping_population", DoubleType(), nullable=True),
                                                       StructField("sum_of_Sqr_DeltaRft", DoubleType(), nullable=True),
                                                       StructField("root_sum_sqr", DoubleType(), nullable=True),
                                                       StructField("standard_error", DoubleType(), nullable=True),
                                                       StructField("final_target", DoubleType(), nullable=True)
                                                       ]
expected_data_schema_grouping_classification_schema = StructType(expected_data_schema_grouping_classification_fields)

@Given("there is an input dataset LOAD")
def given_paths(context):
        context.input_data_sample = df_from_file(context, str(context.table.rows[0][0]))
        context.input_data_population = df_from_file(context, str(context.table.rows[0][1]))
        context.expected_data_focus = df_from_file(context, str(context.table.rows[0][2]))
        context.expected_data_grouping_classification = df_from_file(context, str(context.table.rows[0][3]))
        print("Given there is an input dataset LOAD PARAMS:")
        print(str(context.table.rows[0][0]))
        context.input_data_sample.show(50)
        print(str(context.table.rows[0][1]))
        context.input_data_population.show(50)
        print(str(context.table.rows[0][2]))
        context.expected_data_focus.show(50)
        print(str(context.table.rows[0][3]))
        context.expected_data_grouping_classification.show(50)



@Given("there is an input dataset")
def given_paths(context):
        context.input_data_sample = df_from_file(context, str(context.table.rows[0][0]))
        context.input_data_population = df_from_file(context, str(context.table.rows[0][1]))
        context.expected_data_focus = df_from_file(context, str(context.table.rows[0][2]))
        context.expected_data_grouping_classification = df_from_file(context, str(context.table.rows[0][3]))



@Given(u'an auxiliary variable is provided')
def an_auxiliary_variable_is_provided(context):
        context.grouping_classification = str(context.table.rows[0][0])
        context.reporting_period = str(context.table.rows[0][1])
        context.auxiliary_variable = str(context.table.rows[0][2])
        context.focus = str(context.table.rows[0][3])
        context.target = str(context.table.rows[0][4])
        context.population_grouping_classification = str(context.table.rows[0][5])
        context.population_reporting_period = str(context.table.rows[0][6])
        context.population_auxiliary_variable = str(context.table.rows[0][7])
        context.population_focus = str(context.table.rows[0][8])
        context.flagging_exclude = str(context.table.rows[0][9])
        print("PARAMS available in Python Steps file:")
        print(context.grouping_classification)
        print(context.reporting_period)
        print(context.auxiliary_variable)
        print(context.focus)
        print(context.target)
        print(context.population_grouping_classification)
        print(context.population_reporting_period)
        print(context.population_auxiliary_variable)
        print(context.population_focus)
        print(context.flagging_exclude)


@Given(u'a ratio has been calculated')
def a_ratio_has_been_calculated(context):
        print("And a ratio has been calculated:")
        context.grouping_classification = str(context.table.rows[0][0])
        context.reporting_period = str(context.table.rows[0][1])
        context.auxiliary_variable = str(context.table.rows[0][2])
        context.focus = str(context.table.rows[0][3])
        context.target = str(context.table.rows[0][4])
        context.population_grouping_classification = str(context.table.rows[0][5])
        context.population_reporting_period = str(context.table.rows[0][6])
        context.population_auxiliary_variable = str(context.table.rows[0][7])
        context.population_focus = str(context.table.rows[0][8])
        context.flagging_exclude = str(context.table.rows[0][9])
        print("PARAMS available in Python Steps file:")
        print(context.grouping_classification)
        print(context.reporting_period)
        print(context.auxiliary_variable)
        print(context.focus)
        print(context.target)
        print(context.population_grouping_classification)
        print(context.population_reporting_period)
        print(context.population_auxiliary_variable)
        print(context.population_focus)
        print(context.flagging_exclude)
        #pass


@Given(u'estimated turnover for RU and cell have both been calculated')
def estimated_turnover_for_RU_and_cell_have_both_been_calculated(context):
        print("And estimated turnover for RU and cell have both been calculated:")
        context.grouping_classification = str(context.table.rows[0][0])
        context.reporting_period = str(context.table.rows[0][1])
        context.auxiliary_variable = str(context.table.rows[0][2])
        context.focus = str(context.table.rows[0][3])
        context.target = str(context.table.rows[0][4])
        context.population_grouping_classification = str(context.table.rows[0][5])
        context.population_reporting_period = str(context.table.rows[0][6])
        context.population_auxiliary_variable = str(context.table.rows[0][7])
        context.population_focus = str(context.table.rows[0][8])
        context.flagging_exclude = str(context.table.rows[0][9])
        print("PARAMS available in Python Steps file:")
        print(context.grouping_classification)
        print(context.reporting_period)
        print(context.auxiliary_variable)
        print(context.focus)
        print(context.target)
        print(context.population_grouping_classification)
        print(context.population_reporting_period)
        print(context.population_auxiliary_variable)
        print(context.population_focus)
        print(context.flagging_exclude)


@When(u'we apply the Python function to the dataset')
def we_apply_the_Python_function_to_the_dataset(context):
        print("When we apply the Python function to the dataset:")
        context.input_data_sample.printSchema()
        context.input_data_population.printSchema()
        print("PARAMS: " + context.grouping_classification, context.reporting_period, context.auxiliary_variable, context.focus, context.target, context.population_grouping_classification, context.population_reporting_period, context.population_auxiliary_variable, context.population_focus, context.flagging_exclude)
        context.df_output = RatEst.ratioEstimation(context.input_data_sample).ratioEstimation1(context.input_data_sample, context.input_data_population, context.grouping_classification, context.reporting_period, context.auxiliary_variable, context.focus, context.target, context.population_grouping_classification, context.population_reporting_period, context.population_auxiliary_variable, context.population_focus, True, context.flagging_exclude)
        context.df_output.show(50)
        context.df_output.printSchema()


@When(u'the ratio is multiplied by the Python auxiliary variable')
def the_ratio_is_multiplied_by_the_Python_auxiliary_variable(context):
        print("When the ratio is multiplied by the Python auxiliary variable:")
        context.input_data_sample.printSchema()
        context.input_data_population.printSchema()
        print("PARAMS: " + context.grouping_classification, context.reporting_period, context.auxiliary_variable, context.focus, context.target, context.population_grouping_classification, context.population_reporting_period, context.population_auxiliary_variable, context.population_focus, context.flagging_exclude)
        context.df_output = RatEst.ratioEstimation(context.input_data_sample).ratioEstimation1(context.input_data_sample, context.input_data_population, context.grouping_classification, context.reporting_period, context.auxiliary_variable, context.focus, context.target, context.population_grouping_classification, context.population_reporting_period, context.population_auxiliary_variable, context.population_focus, True, context.flagging_exclude)
        context.df_output.show(50)
        context.df_output.printSchema()


@When(u'the ratio is multiplied by the Python sum of the auxiliary variable for population')
def the_ratio_is_multiplied_by_the_Python_sum_of_the_auxiliary_variable_for_population(context):
        print("When the ratio is multiplied by the Python sum of the auxiliary variable for population:")
        context.str_flag_focus_or_cell = "flagiscell"
        print("PARAMS: " + context.grouping_classification, context.reporting_period, context.auxiliary_variable, context.focus, context.target, context.population_grouping_classification, context.population_reporting_period, context.population_auxiliary_variable, context.population_focus, context.flagging_exclude)
        context.df_output_2 = RatEst.ratioEstimation(context.input_data_sample).ratioEstimation1(context.input_data_sample, context.input_data_population, context.grouping_classification, context.reporting_period, context.auxiliary_variable, context.focus, context.target, context.population_grouping_classification, context.population_reporting_period, context.population_auxiliary_variable, context.population_focus, False, context.flagging_exclude)
        context.df_output_2.show(50)
        context.df_output_2.printSchema()


@When(u'the sum of squares of difference Python calculation is applied')
def the_sum_of_squares_of_difference_Python_calculation_is_applied(context):
        print("When the sum of squares of difference Python calculation is applied:")
        context.str_flag_focus_or_cell = "flagiscell"
        print("PARAMS: " + context.grouping_classification, context.reporting_period, context.auxiliary_variable, context.focus, context.target, context.population_grouping_classification, context.population_reporting_period, context.population_auxiliary_variable, context.population_focus, context.flagging_exclude)
        context.df_output_2 = RatEst.ratioEstimation(context.input_data_sample).ratioEstimation1(context.input_data_sample, context.input_data_population, context.grouping_classification, context.reporting_period, context.auxiliary_variable, context.focus, context.target, context.population_grouping_classification, context.population_reporting_period, context.population_auxiliary_variable, context.population_focus, False, context.flagging_exclude)
        context.df_output_2.show(50)
        context.df_output_2.printSchema()


@Then(u'the sum of the turnover sample is divided by the auxiliary sample and a ratio is produced by the Python process')
def the_sum_of_the_turnover_sample_is_divided_by_the_auxiliary_sample_and_a_ratio_is_produced_by_the_Python_process(context):

        print("Then the sum of the turnover sample is divided by the auxiliary sample and a ratio is produced by the Python process:")
        context.df_output.printSchema()
        context.expected_data_focus.printSchema()
        context.df_output.select(
                "focus", "reporting_period", "grouping_classification", "auxiliary_variable", "turnover",
                "sum_of_auxiliary_variable_sample", "sum_of_auxiliary_variable_population",
                "sum_of_target_sample", "count_of_focus_population"
                ).orderBy("focus", "reporting_period", "grouping_classification").show(50)

        context.expected_data_focus.select(
                "focus", "reporting_period", "grouping_classification", "auxiliary_variable", "turnover",
                "sum_of_auxiliary_variable_sample", "sum_of_auxiliary_variable_population",
                "sum_of_target_sample", "count_of_focus_population"
                ).orderBy("focus", "reporting_period", "grouping_classification").show(50)

        assert context.df_output.select(
                "focus", "reporting_period", "grouping_classification", "auxiliary_variable", "turnover",
                "sum_of_auxiliary_variable_sample", "sum_of_auxiliary_variable_population",
                "sum_of_target_sample", "count_of_focus_population"
                ).orderBy("focus", "reporting_period", "grouping_classification").collect()\
               == context.expected_data_focus.select(
                "focus", "reporting_period", "grouping_classification", "auxiliary_variable", "turnover",
                "sum_of_auxiliary_variable_sample", "sum_of_auxiliary_variable_population",
                "sum_of_target_sample", "count_of_focus_population"
                ).orderBy("focus", "reporting_period", "grouping_classification").collect()


@Then(u'the Python estimated turnover for reporting unit is produced')
def the_Python_estimated_turnover_for_reporting_unit_is_produced(context):

        print("Then the Python estimated turnover for reporting unit is produced:")
        context.df_output.printSchema()
        context.expected_data_focus.printSchema()

        focus_expected_part1 = context.expected_data_focus.select("focus", "reporting_period", "grouping_classification",
                                                                  "beta_grouping_classification",
                                                                  "estimated_target_by_grouping_classification")
        focus_output_part1 = context.df_output.select("focus", "reporting_period", "grouping_classification",
                                                      "beta_grouping_classification",
                                                      "estimated_target_by_grouping_classification")
        focus_expected_part2 = focus_expected_part1.withColumn("beta_grouping_classification_new",
                                                               focus_expected_part1["beta_grouping_classification"].cast(DecimalType(25,3)))\
                .withColumn("estimated_target_by_grouping_classification_new",
                            focus_expected_part1["estimated_target_by_grouping_classification"].cast(DecimalType(25,3)))\
                .drop("beta_grouping_classification", "estimated_target_by_grouping_classification")
        focus_output_part2 = focus_output_part1.withColumn("beta_grouping_classification_new",
                                                           focus_output_part1["beta_grouping_classification"].cast(DecimalType(25,3)))\
                .withColumn("estimated_target_by_grouping_classification_new",
                            focus_output_part1["estimated_target_by_grouping_classification"].cast(DecimalType(25,3)))\
                .drop("beta_grouping_classification", "estimated_target_by_grouping_classification")


        focus_output_part2.select("focus", "reporting_period", "grouping_classification",
                                        "beta_grouping_classification_new",
                                        "estimated_target_by_grouping_classification_new") \
                .orderBy("focus", "reporting_period", "grouping_classification").show(50)
        focus_expected_part2.select("focus", "reporting_period", "grouping_classification",
                                           "beta_grouping_classification_new",
                                           "estimated_target_by_grouping_classification_new") \
                .orderBy("focus", "reporting_period", "grouping_classification").show(50)

        assert focus_output_part2.select("focus", "reporting_period", "grouping_classification",
                                               "beta_grouping_classification_new",
                                               "estimated_target_by_grouping_classification_new")\
                       .orderBy("focus", "reporting_period", "grouping_classification").collect() == \
               focus_expected_part2.select("focus", "reporting_period", "grouping_classification",
                                                  "beta_grouping_classification_new",
                                                  "estimated_target_by_grouping_classification_new")\
                       .orderBy("focus", "reporting_period", "grouping_classification").collect()


@Then(u'the Python estimated turnover cell is produced')
def the_Python_estimated_turnover_cell_is_produced(context):

        print("Then the Python estimated turnover cell is produced:")
        context.df_output_2.printSchema()
        context.expected_data_focus.printSchema()
        grouping_classification_expected_part1 = context.expected_data_grouping_classification.select(
                "reporting_period", "grouping_classification", "beta_grouping_classification", "final_target")
        grouping_classification_output_part1 = context.df_output_2.select(
                "reporting_period", "grouping_classification", "beta_grouping_classification", "final_target")
        grouping_classification_expected_part2 = grouping_classification_expected_part1.withColumn(
                "beta_grouping_classification_new", grouping_classification_expected_part1["beta_grouping_classification"].cast(DecimalType(25,3)))\
                .withColumn("final_target_new", grouping_classification_expected_part1["final_target"].cast(DecimalType(25,3)))\
                .drop("beta_grouping_classification", "final_target")
        grouping_classification_output_part2 = grouping_classification_output_part1.withColumn(
                "beta_grouping_classification_new", grouping_classification_output_part1["beta_grouping_classification"].cast(DecimalType(25,3)))\
                .withColumn("final_target_new", grouping_classification_output_part1["final_target"].cast(DecimalType(25,3)))\
                .drop("beta_grouping_classification", "final_target")

        grouping_classification_expected_part2.select("reporting_period", "grouping_classification", "beta_grouping_classification_new", "final_target_new")\
                .orderBy("reporting_period", "grouping_classification").show(50)
        grouping_classification_output_part2.select("reporting_period", "grouping_classification", "beta_grouping_classification_new", "final_target_new")\
                .orderBy("reporting_period", "grouping_classification").show(50)

        assert (grouping_classification_expected_part2.select("reporting_period", "grouping_classification", "beta_grouping_classification_new", "final_target_new")
                .orderBy("reporting_period", "grouping_classification").collect()
                ==
                grouping_classification_output_part2.select("reporting_period", "grouping_classification", "beta_grouping_classification_new", "final_target_new")
                .orderBy("reporting_period", "grouping_classification").collect())


@Then(u'the Python uncertainty of the estimation is produced')
def the_Python_uncertainty_of_the_estimation_is_produced(context):

        print("Then the Python uncertainty of the estimation is produced:")
        uncertainty_expected_part1 = context.expected_data_grouping_classification.select("reporting_period", "grouping_classification", "standard_error")
        uncertainty_output_part1 = context.df_output_2.select("reporting_period", "grouping_classification", "standard_error")
        uncertainty_expected_part2 = uncertainty_expected_part1.withColumn("standard_error_new", uncertainty_expected_part1["standard_error"]
                                                                           .cast(DecimalType(25,3))).drop("standard_error")
        uncertainty_output_part2 = uncertainty_output_part1.withColumn("standard_error_new", uncertainty_output_part1["standard_error"]
                                                                       .cast(DecimalType(25,3))).drop("standard_error")


        uncertainty_expected_part2.select("reporting_period", "grouping_classification", "standard_error_new")\
                .orderBy("reporting_period", "grouping_classification").show(50)
        uncertainty_output_part2.select("reporting_period", "grouping_classification", "standard_error_new")\
                .orderBy("reporting_period", "grouping_classification").show(50)


        assert (uncertainty_expected_part2.select("reporting_period", "grouping_classification", "standard_error_new")
                .orderBy("reporting_period", "grouping_classification").collect()
                ==
                uncertainty_output_part2.select("reporting_period", "grouping_classification", "standard_error_new")
                .orderBy("reporting_period", "grouping_classification").collect())