from behave import Given, When, Then
from python.sml.methods.CleaningTPR import CleaningTPR


@Given("the user provides the TPRC function parameters")
def userParameters(context):
    context.Value_Col = str(context.table.rows[0][1])
    context.Marker_Col = str(context.table.rows[0][0])
    context.New_Col = str(context.table.rows[0][2])
    context.Marker_val = str(context.table.rows[0][3])
    context.Corrector_val = str(context.table.rows[0][4])


@When("the Python TPR Cleaning function is applied")
def step_impl(context):
    New_Col = "tpr_turnover"
    context.outData = CleaningTPR(context.input_data).clean1(context.input_data,
                                                            context.Value_Col,
                                                            context.Marker_Col,
                                                            context.New_Col,
                                                            int(context.Marker_val),
                                                            int(context.Corrector_val))

    print("Expected DataFrame ...")
    context.expected_data.select("turnover", "marker", "tpr_turnover").show()
    print("Output DataFrame ...")
    context.outData.select("turnover", "marker", "tpr_turnover").show()


@Then("the Python TPR function will Correct records")
def step_impl(context):
    assert context.expected_data.select("turnover", "marker", "tpr_turnover").collect() == \
           context.outData.select("turnover", "marker", "tpr_turnover").collect()

@Then(u'the Python TPR function will Copy records')
def step_impl(context):
    assert context.expected_data.select("turnover", "marker", "tpr_turnover").collect() == \
           context.outData.select("turnover", "marker", "tpr_turnover").collect()