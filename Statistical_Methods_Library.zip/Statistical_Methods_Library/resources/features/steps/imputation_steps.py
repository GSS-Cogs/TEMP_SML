from behave import Given, When, Then

import python.sml.methods.imputation as imp


def order_df(df):
    cols = sorted(df.columns)
    return df.select(*cols)


@Given(u'the user provides the Imputation function parameters')
def imputation_parameters(context):
    context.partition_cols = str(context.table.rows[0][0]).split(",")
    context.unit_col = str(context.table.rows[0][1])
    context.time_col = str(context.table.rows[0][2])
    context.target_col = str(context.table.rows[0][3])
    context.aux_col = str(context.table.rows[0][4])
    context.output_col = str(context.table.rows[0][5])
    context.marker_col = str(context.table.rows[0][6])
    print("PARAMS from BDD AND:")
    print(context.partition_cols)
    print(context.unit_col)
    print(context.time_col)
    print(context.target_col)
    print(context.aux_col)
    print(context.output_col)
    print(context.marker_col)


@When(u'the Python Imputation function is applied')
def imputation_scenario_one(context):
    print("Running Python Scenario A:")
    context.output = imp.imputation(context.input_data) \
        .impute(df=context.input_data,
                partitionCol=context.partition_cols,
                unitCol=context.unit_col,
                timeCol=context.time_col,
                targetCol=context.target_col,
                outputCol=context.output_col,
                markerCol=context.marker_col,
                auxCol=context.aux_col)
    print("Output - Python Scenario A:")
    context.output.show(50)
    context.output.printSchema()


@Then(u'the DataFrame will be imputed correctly')
def imputation_result(context):
    print("Asset the Test - Python wrapper Expected Data:")
    assert context.output.select("aux", "group", "id", "impValue",
                                 "marker", "time", "value") \
               .orderBy("time", "id").collect() == \
           context.expected_data.select("aux", "group", "id", "impValue",
                                        "marker", "time", "value") \
               .orderBy("time", "id").collect()
