from behave import Given, When, Then

from python.sml.methods.median_redistribution import median_redistribution


def order_df(df):
    cols = sorted(df.columns)
    return df.select(*cols)


@Given("a partition column {part_col}")
def given_part_col(context, part_col):
    context.partition_col = part_col


@Given("a time period column {time_period_col}")
def given_time_col(context, time_period_col):
    context.time_col = time_period_col


@Given("a clean marker column {marker_col}")
def given_marker_col(context, marker_col):
    context.marker_col = marker_col


@Given("a record type column {type_col}")
def given_type_col(context, type_col):
    context.type_col = type_col


@Given("a target column {target_col}")
def given_target_col(context, target_col):
    context.target_col = target_col


@Given("unclean values {unclean_vals}")
def given_unclean_col(context, unclean_vals):
    context.unclean_vals = unclean_vals.split(",")


@Given("a output column {out_col}")
def given_out_col(context, out_col):
    context.out_col = out_col


@When("the Python MedianRedistribution function is applied to the dataset")
def when_median_redistribution(context):
    context.output_data = median_redistribution(context.input_data) \
        .median_redistribution(
        context.input_data,
        context.partition_col,
        context.time_col,
        context.marker_col,
        context.type_col,
        context.target_col,
        context.unclean_vals,
        context.out_col)


@Then("the unclean records are altered based on the clean records, the output dataset should match the expected dataset")
def then_median_redistribution(context):
    context.output_data = order_df(context.output_data)
    print("Input Dataframe")
    context.input_data.show()
    print("Expected Dataframe")
    context.expected_data.show()
    print("Output Dataframe")
    context.output_data.show()
    assert (context.output_data.collect() == context.expected_data.collect())


@Then("the clean records are unaltered")
def then_median_redistribution_2(context):
    # Step is covered by expected data
    pass


@Then("the sum of the target column and output column is the same")
def then_median_redistribution_3(context):
    # Sum the input target column
    in_sum = context.input_data.select(context.target_col).groupBy().sum().rdd.map(lambda x: x[0]).collect()
    # Sum the output column of the output dataframe
    out_sum = context.output_data.select(context.target_col).groupBy().sum().rdd.map(lambda x: x[0]).collect()

    assert (in_sum == out_sum)
