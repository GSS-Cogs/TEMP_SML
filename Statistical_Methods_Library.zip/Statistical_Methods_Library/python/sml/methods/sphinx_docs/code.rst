Auto Generated Documentation
============================

.. automodule:: melt
    :members:

.. automodule:: median_redistribution
    :members:

.. automodule:: QuarterlyPatternRulePython
    :members:

.. automodule:: RatioEstimation
    :members: