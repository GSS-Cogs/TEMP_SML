from pyspark.sql import DataFrame


class Estimation:

    def __init__(self, df=None):

        if df is None: raise TypeError

        self._df = df

        self._jApp = self._df._sc._jvm \
                         .uk.gov.ons \
                         .api.java.methods \
                         .EstimationFactory.estimation(self._df._jdf)

    def __mandatory_argument_check(self, *args):

        for arg in args:
            if arg is None: raise TypeError

    def estimate_weight_by_expansion(self, target_column=None, strata_column=None,
                                     is_trimmed=None):

        """
        Public method that estimates a weighting of a target column based on the simple relationship of sample
        values to unknown population values, optionally allows for strata to be honoured. This is also referred to as
        Horvits-Thompson estimation.

        :param target_column    - Column name that to be estimated from.
        :param strata_column    - Column name to be partitioned on.
        :param is_trimmed       - Flag to disregard marked records in estimation.
        :return pyspark.sqlDataFrame
        """

        # Deals with default not setting properly.
        if is_trimmed is None: is_trimmed = False

        self.__mandatory_argument_check(target_column)

        df = self._df

        return DataFrame(self._jApp.estimateWeightByExpansion(target_column, strata_column, is_trimmed),
                         df.sql_ctx)

    def estimate_weight_by_ratio(self, target_column=None, auxiliary_column=None,
                                 strata_column=None, is_trimmed=None):

        """
        Public method that estimates estimates a weighting of a target column based on an auxiliary variable,
        optionally allows for strata to be honoured.

        :param target_column        - Column name that to be estimated from.
        :param auxiliary_column     - Column name of auxiliary values to produce a weight.
        :param strata_column        - Column name to be partitioned on.
        :param is_trimmed           - Flag to disregard marked records in estimation.
        :return pyspark.sqlDataFrame
        """

        # Deals with default not setting properly.
        if is_trimmed is None: is_trimmed = False

        self.__mandatory_argument_check(target_column, auxiliary_column)

        df = self._df

        return DataFrame(self._jApp.estimateWeightByRatio(target_column, auxiliary_column,
                                                          strata_column, is_trimmed),
                         df.sql_ctx)


def estimation(df): return Estimation(df)
