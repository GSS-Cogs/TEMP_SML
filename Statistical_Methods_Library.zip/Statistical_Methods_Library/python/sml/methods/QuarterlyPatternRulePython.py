from pyspark.sql import DataFrame

class QuarterlyPatternRule():

    def __init__(self, df = None):
        if df is None : raise TypeError

        self._df = df
        self._qpr = self._df._sc._jvm.uk.gov.ons.api.java.methods.QuarterlyPatternRuleFactory.quarterlyPatternRule(self._df._jdf)

    def __mandatoryArgumentCheck(self, *args):
        for arg in args:
            if arg is None:
                raise TypeError

    def quarterlyPatternRule1(self, df=None, partitionColumns=None, orderColumns=None, comparisonValueColumn=None, identifierColumn=None,
                              identifierValue=None):
        """

        This method will mark records that fail return in a quarterly stagger but actually are annual returns.  It does
        this by checking for the following patterns in the quarterly returns split over a financial year then marks them
        depending on the pattern they fail
        Pattern 2 : X,X,X,X Marked with : 2
        Pattern 3 : X,X,X,Y Marked with : 3
        Pattern 4 : 0,0,0,Y Marked with : 4

        These marked records can then be cleaned using some form of calendarisation function like the
        MedianRedistribution function in the SML

        This Python wrapper connects the underlying Java interface for the QPR functionality.

        :param df: A DataFrame
        :param partitionColumns: List[String] The dataframe columns that will be used to partition the input dataframe.
        :param orderColumns:     List[String] The dataframe columns that will be used to order the partition.
        :param turnover_column:  String       The dataframe column that will specify the turnover identifier.
        :param stagger_col:      String       The dataframe column that will specify the stagger-return identifier.
        :param identifierColumn: String       The dataframe column that will specify the whether a row will be part of the comparison.
        :param identifierValue:  List         The value(s) to look for in the identifierColumn to indicate it is a quarterly value
        :return: pyspark.sql.DataFrame
        """
        self.__mandatoryArgumentCheck(partitionColumns, orderColumns, comparisonValueColumn, identifierColumn, identifierValue)

        if df is None: df = self._df
        return DataFrame(self._qpr.quarterlyPatternRuleMethod(df._jdf, partitionColumns, orderColumns,
                                                              comparisonValueColumn, identifierColumn,
                                                              identifierValue), df.sql_ctx)

def quarterlyPatternRule(df):
    return QuarterlyPatternRule(df)