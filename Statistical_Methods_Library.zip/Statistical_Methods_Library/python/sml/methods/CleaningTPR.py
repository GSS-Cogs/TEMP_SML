from pyspark.sql import DataFrame


class CleaningTPR():

    defaultCol = 'tpr_turnover'

    def __init__(self, df=None):

        if df is None:
            raise TypeError

        self._df = df

        self._jCtpr = self._df._sc._jvm.uk.gov.ons.api.java.methods.TPRCleaningFactory.cleaning(self._df._jdf)

    def __mandatoryArgumentCheck(self, arg1, arg2, arg3):
        if (arg1 is None) or (arg2 is None) or (arg3 is None):
            raise TypeError

    def clean1(self, df=None, Value_Col= None, Marker_Col= None, New_Col=None, marker_val=None, correction_val=None):
        """
        A Python wrapper for the TPR Cleaning Method

        @author saul.pountney@ons.gov.uk
        @version 1.0

        The Cleaning TPR checks for relevant Marker and applies a function to the correct marker.

        If the Marker is different from the designated value then it is expected that the ratio calculation was
        correct and the value column is kept the same, the new results are then then stored in a new column.

        If the Marker is the designated value then it has failed the the ratio calculation and the value
        column is multiplied by 1000, the new results are then stored in a new column.

        :param df: dataframe
        :param Value_Col:     String  -  column which is used as the initial value.
        :param Marker_Col:    String  -  column which is the marked value which shows irregular values.
        :param New_Col:       String  -  column which shows the altered values.
        :param marker_val:    Any     -  the value that indicates a record requires correction
        :param corrector_val: Integer -  the multiplier used in correction in value
        :return: dataset[Row]
        """
        self.__mandatoryArgumentCheck(Value_Col,Marker_Col,New_Col)

        if df is None:
            df = self._df

        return DataFrame(
            self._jCtpr.clean1(
                df._jdf,
                Value_Col,
                Marker_Col,
                New_Col, marker_val, correction_val
            ),
            df.sql_ctx
        )




def cleaning(df):
    return CleaningTPR(df)
