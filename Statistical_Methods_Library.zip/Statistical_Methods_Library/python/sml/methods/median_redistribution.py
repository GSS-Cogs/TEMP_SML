from pyspark.sql import DataFrame


class MedianRedistribution:

    """
    This class contains methods which perform median redistribution on a DataFrame.
    """

    def __init__(self, df=None):
        if df is None:
            raise TypeError

        self._df = df
        self._jmr = self._df._sc._jvm.uk.gov.ons.api.java.methods. \
            MedianRedistributionFactory.medianRedistribution(self._df._jdf)

    def __mandatory_argument_check(self, *args):
        for arg in args:
            if arg is None:
                raise TypeError

    def median_redistribution(self, df=None, partitionCol=None, timeCol=None, markerCol=None,
                              typeCol=None, targetCol=None, uncleanVals=None, outCol=None):
        """
        A python wrapper for the median redistribution function

        :param df: A DataFrame
        :param partitionCol: Name of the column to partition on
        :param timeCol: Name of the column containg the timeperiod data
        :param markerCol: Name of the column that contains the markers
        :param typeCol: Name of the column that contains the record type
        :param targetCol: Name of the column that is to be redistributed
        :param uncleanVals: Markers that denote unclean records
        :param outCol: String - Name of the column to contain the output
        :return: pyspark.sql.DataFrame
        """
        self.__mandatory_argument_check(partitionCol, timeCol, markerCol, typeCol,
                                        targetCol, uncleanVals, outCol)
        if df is None:
            df = self._df
        return DataFrame(self._jmr.medianRedistributionMethod(df._jdf, partitionCol, timeCol,
                                                              markerCol, typeCol, targetCol,
                                                              uncleanVals, outCol),
                         df.sql_ctx)


def median_redistribution(df):
    return MedianRedistribution(df)
