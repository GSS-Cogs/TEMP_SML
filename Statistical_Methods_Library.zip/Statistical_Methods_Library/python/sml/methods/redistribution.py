from pyspark.sql import DataFrame


class Redistribution:

    """
    This class contains a method that redistributes the target column based on weights
    If no weights are provided the target will be redistributed evenly within the partitions

    """

    def __init__(self, df = None):

        if df is None:
            raise TypeError

        self._df = df

        self._jRed = self._df._sc._jvm.uk.gov.ons.api.java.methods.RedistributionFactory.redistribution(self._df._jdf)

    def __mandatoryArgumentCheck(self, *args):

        for arg in args:
            if arg is None:
                raise TypeError

    def redistribute(self, partCols=None, targetCol=None,
                     newCol=None, weightCol=None):
        """
        A Python wrapper for the redistribution function

        :param partCols: Name of the column(s) to partition on
        :param targetCol: Name of the column that is to be redistributed
        :param newCol: Name of the column to contain the output
        :param weightCol: Name of the column containing the weights
        :return: pyspark.sql.DataFrame
        """

        df = self._df

        return DataFrame(self._jRed.redistribute(partCols, targetCol,
                                                 newCol, weightCol),
                         df.sql_ctx)


def redistribution(df):
    return Redistribution(df)

