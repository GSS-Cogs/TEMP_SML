from pyspark.sql import DataFrame


class Imputation:
    def __init__(self, df=None):
        if df is None:
            raise TypeError

        self._df = df
        self._ji = self._df._sc._jvm.uk.gov.ons.api.java.methods. \
            ImputationFactory.imputation(self._df._jdf)

    def __mandatory_argument_check(self, *args):
        for arg in args:
            if arg is None:
                raise TypeError

    def impute(self, df=None, partitionCol=None, unitCol=None, timeCol=None, targetCol=None,
                   outputCol=None, markerCol=None, auxCol=None):
        """
        Marks, constructs and imputes missing values

        :param df: a DataFrame
        :param partitionCol: Columns that will be used to partition the data
        :param unitCol: Name of column containing identifier for each unit
        :param timeCol: Name of column contain time period for data
        :param targetCol: Name of column that will be imputed
        :param outputCol: Name of output column for imputed/constructed/real values
        :param markerCol: Name of marker column indicating if a row is imputed/constructed/real
        :param auxCol: Name of column containing auxiliary variable
        :return:
        """
        self.__mandatory_argument_check(partitionCol, unitCol, timeCol, targetCol, outputCol,
                                        markerCol, auxCol)
        if df is None:
            df = self._df
        return DataFrame(self._ji.impute(df._jdf, partitionCol, unitCol, timeCol, targetCol,
                                         outputCol, markerCol, auxCol),
                         df.sql_ctx)


def imputation(df):
    return Imputation(df)
