from pyspark.sql import DataFrame


class RatioEstimation():


    def __init__(self, df = None):
        if df is None : raise TypeError

        self._df = df
        self._ratioest = self._df._sc._jvm.uk.gov.ons.api.java.methods.RatioEstimationFactory.ratioEstimation(self._df._jdf)


    def __mandatoryArgumentCheck(self, *args):
        for arg in args:
            if arg is None:
                raise TypeError


    def ratioEstimation1(self, df=DataFrame, df_population=DataFrame, grouping_classification=None, reporting_period=None,
        auxiliary_variable=None, focus=None, turnover=None, population_grouping_classification=None,
        population_reporting_period=None, population_auxiliary_variable=None, population_focus=None,
        bln_flag_focus_or_grpclass=None, flagging_exclude=None):
            """
            This Python wrapper connects the underlying Java interface for the Ratio Estimation functionality.

              :param df_population                          Dataset     - Population dataset required for the ratio calculation.
              :param grouping_classification_col            String      - Used to identify the grouping classification.
              :param reporting_period_col                   String      - Used to identify the reporting period.
              :param auxiliary_variable_col                 String      - Used to identify the auxiliary variable.
              :param focus_col                              String      - Used to identify the focus (the primary key).
              :param target_estimation_col                  String      - Used to identify the estimation target.
              :param population_grouping_classification_col String      - Used to identify the population grouping classification.
              :param population_reporting_period_col        String      - Used to identify the population reporting period.
              :param population_auxiliary_variable_col      String      - Used to identify the population auxiliary variable.
              :param population_focus_col                   String      - Used to identify the population focus (the primary key).
              :param bln_flag_focus_or_grpclass             Boolean     - Used to identify the output from the method (True = focus / False = grouping classification).
              :param flagging_exclude                       String      - Used to identify during the flagging process a singular grouping classification to exclude.
              :return pyspark.sql.DataFrame                             - Returned dataset based on flag, either at focus or grouping classification aggregation.
            """

            self.__mandatoryArgumentCheck(grouping_classification, reporting_period, auxiliary_variable, focus,
                turnover, population_grouping_classification, population_reporting_period,
                population_auxiliary_variable, population_focus, bln_flag_focus_or_grpclass, flagging_exclude)

            if df is None: df = self._df

            return DataFrame(self._ratioest.Ratio_Estimation_Method(df._jdf, df_population._jdf,
                grouping_classification, reporting_period, auxiliary_variable, focus, turnover,
                population_grouping_classification, population_reporting_period, population_auxiliary_variable,
                population_focus, bln_flag_focus_or_grpclass, flagging_exclude), df.sql_ctx)


def ratioEstimation(df):
    return RatioEstimation(df)