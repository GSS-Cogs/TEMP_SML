.. SML documentation master file, created by
   sphinx-quickstart on Tue Sep 15 17:34:03 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to SML documentation!
============================================

This is documentation for the Statistical Method Library Project

Requirements:

The SML project depends on the following packages:
Spark version 2.2.1


Contents:

.. toctree::
   :maxdepth: 2

    modules
    sparkts

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

