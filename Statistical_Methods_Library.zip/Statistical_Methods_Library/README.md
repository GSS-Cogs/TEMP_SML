Statistical Method Library Project
=============
A Scala / Java / Python library for using Spark in as library.
This project shows an example pattern in using a Polyglot library for apache spark.
Structure DONE
Example Function DONE
Scala Tests DONE
Python Tests DONE
Java Tests IN PROGRESS
Documentation IN PROGRESS
CI IN PROGRESS
