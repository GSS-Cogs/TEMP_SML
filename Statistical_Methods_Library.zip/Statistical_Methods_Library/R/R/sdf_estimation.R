#' Call the Estimation By Expansion function
#'
#' Public method that estimates a weighting of a target column based on the simple relationship of sample
#' values to unknown population values, optionally allows for strata to be honoured. This is also referred to as
#' Horvits-Thompson estimation.
#'
#' @param sc \code{spark_connection}. Spark connection.
#' @param data_frame \code{jobj}. the Spark \code{DataFrame} on which to perform the function.
#' @param target_column string. Column name that to be estimated from.
#' @param strata_column string = NULL. Column name to be partitioned on.
#' @param is_trimmed logical = FALSE. Flag to disregard marked records in estimation.
#'
#' @return Returns a \code{jobj}
#'
#' @examples
#' \dontrun{
#' # Set up a spark connection
#' sc <- spark_connect(master = "local", version = "2.2.0")
#'
#' # Extract some data
#' est_data <- spark_read_json(sc,
#'                             "est_data",
#'                             path = system.file("data_raw/est.json", package = "sml")) %>%
#'   spark_dataframe()
#'
#' # Call the method
#' output <- sdf_estimate_weight_by_expansion(sc = sc, data = est_data,
#'                                            target_column = "target", strata_column = "strata")
#'
#' # Return the data to R
#' output %>%
#'   dplyr::collect()
#'
#' spark_disconnect(sc = sc)
#' }
#'
#' @export
sdf_estimate_weight_by_expansion <- function(sc, data_frame, target_column,
                                             strata_column = NULL,
                                             is_trimmed = FALSE) {

  stopifnot(inherits(sc, c("spark_connection", "spark_shell_connection",
                           "DBIConnection")))
  stopifnot(inherits(data_frame, c("spark_jobj", "shell_jobj")))
  stopifnot(is.character(target_column))
  stopifnot(is.logical(is_trimmed))

  invoke_static(sc = sc,
                class = "uk.gov.ons.api.java.methods.EstimationAPI",
                method = "estimation",
                df = data_frame) %>%
    invoke(method = "estimateWeightByExpansion",
           targetColumn = target_column,
           strataColumn = strata_column,
           isTrimmed = is_trimmed)
}

#' Call the Estimation By Ratio function
#'
#' Public method that estimates the total sum of a target column based on the ratio of known sample values to known
#' population values (using IDBRVAT data or some equivalent), optionally allows for strata to be honoured and
#' minimum/maximum percentage outlier trims to be applied.
#'
#' @param sc \code{spark_connection}. Spark connection.
#' @param data_frame \code{jobj}. the Spark \code{DataFrame} on which to perform the function.
#' @param target_column string. Column name that to be estimated from.
#' @param auxiliary_column string. Column name of auxiliary values to produce a weight.
#' @param strata_column string = NULL. Column name to be partitioned on.
#' @param is_trimmed logical = FALSE. Flag to disregard marked records in estimation.
#'
#' @return Returns a \code{jobj}
#'
#' @examples
#' \dontrun{
#' # Set up a spark connection
#' sc <- spark_connect(master = "local", version = "2.2.0")
#'
#' # Extract some data
#' est_data <- spark_read_json(sc,
#'                             "est_data",
#'                             path = system.file("data_raw/est.json", package = "sml"))
#'
#' # Call the method
#' output <- sdf_estimate_weight_by_ratio(sc = sc, data = est_data, target_column = "target",
#'                                        auxiliary_column = "auxiliary", strata_column = "strata")
#'
#' # Return the data to R
#' output %>% dplyr::collect()
#'
#' spark_disconnect(sc = sc)
#' }
#'
#' @export
sdf_estimate_weight_by_ratio <- function(sc, data_frame, target_column,
                                         auxiliary_column,
                                         strata_column = NULL,
                                         is_trimmed = FALSE) {

  stopifnot(inherits(sc, c("spark_connection", "spark_shell_connection",
                           "DBIConnection")))
  stopifnot(inherits(data_frame, c("spark_jobj", "shell_jobj")))
  stopifnot(is.character(target_column))
  stopifnot(is.character(auxiliary_column))
  stopifnot(is.logical(is_trimmed))

  invoke_static(sc = sc,
                class = "uk.gov.ons.api.java.methods.EstimationAPI",
                method = "estimation",
                df = data_frame) %>%
    invoke(method = "estimateWeightByRatio",
           targetColumn = target_column,
           auxiliaryColumn = auxiliary_column,
           strataColumn = strata_column,
           isTrimmed = is_trimmed)
}
