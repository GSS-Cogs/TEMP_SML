#' Call the imputation method
#'
#' This function marks, constructs and imputes missing values
#'
#' @param sc A \code{spark_connection}.
#'
#' @param data A \code{jobj}: the Spark \code{DataFrame} on which to perform the
#'   function.
#' @param partitionCols List of Strings - Columns that will be used to partition the data
#' @param unitCol String - Name of column containing identifier for each unit
#' @param timeCol String - Name of column contain time period for data
#' @param targetCol String - Name of column that will be imputed
#' @param outputCol String - Name of output column for imputed/constructed/real values
#' @param markCol String - Name of marker column indicating if a row is imputed/constructed/real
#' @param auxCol String - Name of column containing auxiliary variable
#'
#' @examples
#' \dontrun{
#' # Set up a spark connection
#' sc <- spark_connect(master = "local", version = "2.2.0")
#'
#' # Extract some data
#' fr_data <- spark_read_json(
#'   sc,
#'   "fr_data",
#'   path =  "../../../resources/inputs/Imputation/CompleteData.json"
#' ) %>%
#'  spark_dataframe()
#'
#' # Call the method
#' out <- sml::sdf_imputation(
#'   sc = sc, data = fr_data, partitionCols <- c("group"), unitCol <- "id", timeCol <- "time",
#'   targetCol <- "value", outCol <- "impValue", markCol <- "marker", auxCol <- "aux"
#' )
#' #' # Return the data to R
#' out %>% dplyr::collect()
#'
#' # Close the spark connection
#'#' spark_disconnect(sc = sc)
#' }
#'
#' @export
sdf_imputation <- function(sc, data, partitionCols, unitCol, timeCol, targetCol,
                           outputCol, markCol, auxCol){
  stopifnot(
    inherits(
      sc, c("spark_connection", "spark_shell_connection", "DBIConnection")
    )
  )
  stopifnot(inherits(data, c("spark_jobj", "shell_jobj")))
  stopifnot(is.vector(partitionCols))
  stopifnot(is.character(unitCol))
  stopifnot(is.character(timeCol))
  stopifnot(is.character(targetCol))
  stopifnot(is.character(outputCol))
  stopifnot(is.character(markCol))
  stopifnot(is.character(auxCol))

  invoke_static(
    sc = sc,
    class = "uk.gov.ons.methods.Imputation",
    method = "imputation",
    df = data
  ) %>%
    invoke(
      method = "impute",
      df = data,
      partitionCols = scala_list(sc, partitionCols),
      unitCol = unitCol,
      timeCol = timeCol,
      targetCol = targetCol,
      outputCol = outputCol,
      markCol = markCol,
      auxCol = auxCol
    )
}
