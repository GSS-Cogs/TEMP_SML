#'Call Redistribution Function
#'
#' @param sc
#'
#' @param data A \code{jobj}: the Spark \code{DataFrame} on which to perform the
#'   function.
#' @param partCols  ArrayList[String]. columns used to partition by.
#' @param targetCol String.            Name of the column that is to be redistributed
#' @param newCol    String.            Name of the column to contain the output
#' @param weightCol Option[String].    Name of the column containing the weights
#'
#'@return Returns a \code{jobj}
#'
#'@examples
#' \dontrun{
#' # Set up a spark connection
#' sc <- spark_connect(master = "local", version = "2.2.0")
#'
#' # Read in the data
#' input_data <- sparklyr::spark_read_json(
#'   sc,
#'   "input_data",
#'   path = system.file(
#'     "..\\..\\resources\\inputs\\redistribution\\WeightsProvided.json",
#'     package = "sml"
#'   )
#' ) %>%
#'   sparklyr::spark_dataframe()
#'
#' # Call the method
#' result_df <- sdf_redistribution(
#'   sc = sc,
#'   data = input_data,
#'   partCols = c("id"),
#'   targetCol = "value",
#'   newCol = "output",
#'   weightCol = "weights",
#' )
#'
#' # Return the data to R
#' result_df %>% dplyr::collect()
#'
#' spark_disconnect(sc = sc)
#' }
#'
#'
#' @export
sdf_redistribution<- function(sc, data, partCols, targetCol, newCol, weightCol = NULL ) {
  stopifnot(
    inherits(
      sc, c("spark_connection", "spark_shell_connection", "DBIConnection")
    )
  )
  stopifnot(inherits(data, c("spark_jobj", "shell_jobj")))
  stopifnot(is.character(partCols))
  stopifnot(is.character(targetCol))
  stopifnot(is.character(newCol))

  invoke_static(
    sc = sc,
    class = "uk.gov.ons.api.java.methods.RedistributionAPI",
    method = "redistribution",
    df = data
  ) %>%
    invoke(
      method = "redistribute",
      partCols = create_java_list(sc, partCols),
      targetCol = targetCol,
      newCol = newCol,
      weightCol = weightCol

    )
}
