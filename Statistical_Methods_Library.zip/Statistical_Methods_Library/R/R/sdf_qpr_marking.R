
#' Quarterly Pattern Rule Method
#'
#' This method will mark records that fail return in a quarterly stagger but actually are annual returns.  It does
#' this by checking for the following patterns in the quarterly returns split over a financial year then marks them
#' depending on the pattern they fail
#' Pattern 2 : X,X,X,X Marked with : 2
#' Pattern 3 : X,X,X,Y Marked with : 3
#' Pattern 4 : 0,0,0,Y Marked with : 4
#'
#' These marked records can then be cleaned using some form of calendarisation function like the
#' MedianRedistribution function in the SML
#'
#' This Method will check the names of columns in the DataFrame against a list of inputs
#' @param sc A \code{spark_connection}
#' @param data A \code{jobj}: the Spark \code{DataFrame} on which to perform the function
#' @param partition_cols list(string). Name of the new Column
#' @param order_columns list(string). Column(s) used to order the partition
#' @param comparison_value_column c(String). Column to specify the value to be compared.
#' @param identifier_column c(string). Column to specify whether a row will be part o the comparison
#' @param identifier_value list(string). value(s) to look for in the identifier_column to indicate it
#'        is a quarterly value
#'
#' @return DataFrame
#'
#'@examples
#'\dontrun{
#' #Set up a spark connection
#' sc <- spark_connect(master = "local", version = "2.2.0")
#'
#' # Extract some data
#' qpr_data <- spark_read_json(
#'  sc,
#'  "qpr_data",
#'  path = system.file(
#'      "data_raw/Qpr.json",
#'      package = "sml"
#'  )
#' ) %>%
#'  spark_dataframe()
#'
#'  # Call the method
#' p <- sdf_qpr_marking(
#'  sc = sc, data = qpr_data, partition_columns = c("test_vat_return_vatref9"),
#'  order_columns = c("test_period"), comparison_value_column = "test_turnover",
#'  identifier_column = "test_stagger", identifier_value = c("1, 2, 3")
#' )
#'
#' # Return the data to R
#' p %>% dplyr::collect()
#'
#'spark_disconnect(sc = sc)
#'}
#'
#' @export

sdf_qpr_marking <- function(sc, data, partition_columns, order_columns,
                            comparison_value_column, identifier_column,
                            identifier_value) {
  stopifnot(
    inherits(
      sc, c("spark_connection", "spark_shell_connection", "DBIConnection"))
  )
  stopifnot(inherits(data, c("spark_jobj", "shell_jobj")))
  stopifnot(is.vector(partition_columns))
  stopifnot(is.vector(order_columns))
  stopifnot(is.character(comparison_value_column))
  stopifnot(is.character(identifier_column))
  stopifnot(is.vector(identifier_value))

  invoke_static(
    sc = sc,
    class = "uk.gov.ons.methods.QuarterlyPatternRule",
    method = "quarterlyPatternRule",
    df = data
  ) %>%
    invoke(
      method = "quarterlyPatternRuleMethod",
      dfIn = data,
      partition_columns = scala_list(sc, partition_columns),
      order_columns = scala_list(sc, order_columns),
      comparison_value_column = comparison_value_column,
      identifier_column,
      identifier_value = scala_list(sc, identifier_value)
    )
}
