spark_dependencies <- function(spark_version, scala_version, ...) {
  sparklyr::spark_dependency(
    jars = c(
      system.file(
        "../../target/sml-1.0.8-jar-with-dependencies.jar",
        package = "sml"
      )
    ),
    packages = c()
  )
}

#' @import sparklyr
.onLoad <- function(libname, pkgname) {
  sparklyr::register_extension(pkgname)
}
