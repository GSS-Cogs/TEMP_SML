#' A package for calling Scala methods from the sml package
"_PACKAGE"
