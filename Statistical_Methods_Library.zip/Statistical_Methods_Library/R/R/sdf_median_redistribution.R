#' @export
sdf_median_redistribution <- function(sc, data, partitionCol, timeCol, markerCol,
                                      typeCol, targetCol, uncleanVals, outCol) {
  stopifnot(
    inherits(
      sc, c("spark_connection", "spark_shell_connection", "DBIConnection")
    )
  )
  stopifnot(inherits(data, c("spark_jobj", "shell_jobj")))
  stopifnot(is.character(partitionCol))
  stopifnot(is.character(timeCol))
  stopifnot(is.character(markerCol))
  stopifnot(is.character(typeCol))
  stopifnot(is.character(targetCol))
  stopifnot(is.vector(uncleanVals))
  stopifnot(is.character(outCol))

  invoke_static(
    sc = sc,
    class = "uk.gov.ons.methods.MedianRedistribution",
    method = "medianRedistribution",
    df = data
  ) %>%
    invoke(
      method = "medianRedistributionMethod",
      df = data,
      partitionCol = partitionCol,
      timeCol = timeCol,
      markerCol = markerCol,
      typeCol = typeCol,
      targetCol = targetCol,
      uncleanVals = scala_list(sc, uncleanVals),
      outCol = outCol
    )
}
