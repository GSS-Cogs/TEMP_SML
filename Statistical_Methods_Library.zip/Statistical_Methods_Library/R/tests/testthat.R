library(rprojroot)
library(testthat)
library(sml)

test_check("sml")
