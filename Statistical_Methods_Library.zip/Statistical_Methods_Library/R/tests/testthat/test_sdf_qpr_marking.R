context("Test the quarterly pattern rule marking")

sc <- testthat_spark_connection()

compare_data <- function(expected, actual, name_of_file){
  # Test the expectation
  tryCatch({
    expect_identical(
      actual,
      expected
    )
  },
  error = function(e) {
    # Send the method output and expected output to a file
    tmp_sink_file_name <- tempfile(fileext = ".txt")
    tmp_sink_file_num <- file(tmp_sink_file_name, open = "wt")
    send_output(
      file = tmp_sink_file_name,
      name = name_of_file,
      output = actual,
      expected = expected
    )
    close(tmp_sink_file_num)
    cat("\n   Output data can be seen in ", tmp_sink_file_name, "\n", sep = "")
  }
  )
  expect_identical(
    actual,
    expected
  )

}

describe("Quarterly Pattern Rule", {

  it("All four turnovers in the financial year are equal pattern Scenario A", {

    # Read in the data
    input_data <- read_data(file.path(
      PROJHOME, "../resources/inputs/InputTestData_QPR.json"),
      sc)
    # Read in the expected data
    expected_data <- read_data(file.path(
      PROJHOME, "../resources/outputs/OutputTestData_QPR_Scenario_ALL.json"),
      sc)

    # Instantiate the class
    output <- sdf_qpr_marking(
      sc <- sc, data <- input_data,
      partition_columns <- c("test_vat_returns_vatref9"),
      order_columns <- c("test_period"),
      comparison_value_column <- "test_turnover",
      identifier_column <- "test_stagger",
      identifier_value <- c("1", "2", "3")
      )

    # Order and arrange the data for assertions
    output <- output %>%
      dplyr::collect() %>%
      dplyr::select(test_financial_year, test_period, test_stagger,
                    test_turnover, test_vat_returns_vatref9,
                    lagged_1, lagged_2, lagged_3,
                    qpr_pattern) %>%
      dplyr::arrange(test_vat_returns_vatref9,
                     test_financial_year, test_period) %>%
      dplyr::mutate(qpr_pattern = as.numeric(qpr_pattern))

    expected <- expected_data %>%
      dplyr::collect() %>%
      dplyr::select(test_financial_year, test_period, test_stagger,
                    test_turnover, test_vat_returns_vatref9,
                    lagged_1, lagged_2, lagged_3,
                    qpr_pattern) %>%
      dplyr::arrange(test_vat_returns_vatref9,
                     test_financial_year, test_period) %>%
      dplyr::mutate(qpr_pattern = as.numeric(qpr_pattern))

    compare_data(expected, output, "sdf_qpr_marking_s1")
  })

  it("First three turnover returns in the financial year are equal
      except final return pattern Scenario B", {

    # Read in the data
    input_data <- read_data(file.path(
      PROJHOME, "../resources/inputs/InputTestData_QPR.json"),
      sc)
    # Read in the expected data
    expected_data <- read_data(file.path(
      PROJHOME, "../resources/outputs/OutputTestData_QPR_Scenario_ALL.json"),
      sc)

    # Instantiate the class
    output <- sdf_qpr_marking(
      sc <-  sc, data <- input_data,
      partition_columns <- c("test_vat_returns_vatref9"),
      order_columns <- c("test_period"),
      comparison_value_column <- "test_turnover",
      identifier_column <- "test_stagger",
      identifier_value <- c("1", "2", "3")
    )

    # Order and arrange the data for assertions
    output <- output %>%
      dplyr::collect() %>%
      dplyr::select(test_financial_year, test_period, test_stagger,
                    test_turnover, test_vat_returns_vatref9,
                    lagged_1, lagged_2, lagged_3,
                    qpr_pattern) %>%
      dplyr::arrange(test_vat_returns_vatref9,
                     test_financial_year, test_period) %>%
      dplyr::mutate(qpr_pattern = as.numeric(qpr_pattern))

    expected <- expected_data %>%
      dplyr::collect() %>%
      dplyr::select(test_financial_year, test_period, test_stagger,
                    test_turnover, test_vat_returns_vatref9,
                    lagged_1, lagged_2, lagged_3,
                    qpr_pattern) %>%
      dplyr::arrange(test_vat_returns_vatref9,
                     test_financial_year, test_period) %>%
      dplyr::mutate(qpr_pattern = as.numeric(qpr_pattern))

    compare_data(expected, output, "sdf_qpr_marking_s2")
  })

  it("First three turnover returns in the financial year are
     zero except final return pattern Scenario C", {

    # Read in the data
    input_data <- read_data(file.path(
      PROJHOME, "../resources/inputs/InputTestData_QPR.json"),
      sc)
    # Read in the expected data
    expected_data <- read_data(file.path(
      PROJHOME,  "../resources/outputs/OutputTestData_QPR_Scenario_ALL.json"),
      sc)

    # Instantiate the class
    output <- sdf_qpr_marking(
      sc <-  sc, data <- input_data,
      partition_columns <- c("test_vat_returns_vatref9"),
      order_columns <- c("test_period"),
      comparison_value_column <- "test_turnover",
      identifier_column <- "test_stagger",
      identifier_value <- c("1", "2", "3")
    )

    # Order and arrange the data for assertions
    output <- output %>%
      dplyr::collect() %>%
      dplyr::select(test_financial_year, test_period, test_stagger,
                    test_turnover, test_vat_returns_vatref9,
                    lagged_1, lagged_2, lagged_3,
                    qpr_pattern) %>%
      dplyr::arrange(test_vat_returns_vatref9,
                     test_financial_year, test_period) %>%
      dplyr::mutate(qpr_pattern = as.numeric(qpr_pattern))

    expected <- expected_data %>%
      dplyr::collect() %>%
      dplyr::select(test_financial_year, test_period, test_stagger,
                    test_turnover, test_vat_returns_vatref9,
                    lagged_1, lagged_2, lagged_3,
                    qpr_pattern) %>%
      dplyr::arrange(test_vat_returns_vatref9,
                     test_financial_year, test_period) %>%
      dplyr::mutate(qpr_pattern = as.numeric(qpr_pattern))

    compare_data(expected, output, "sdf_qpr_marking_s3")
  })

})
