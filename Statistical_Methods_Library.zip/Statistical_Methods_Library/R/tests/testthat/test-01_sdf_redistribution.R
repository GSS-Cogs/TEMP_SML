context("Test the sdf_Redistribution function")

sc <- testthat_spark_connection()


compare_data <- function(expected, actual, name_of_file){
  # Test the expectation
  tryCatch({
    expect_identical(
      actual,
      expected
    )
  },
  error = function(e) {
    # Send the method output and expected output to a file
    tmp_sink_file_name <- tempfile(fileext = ".txt")
    tmp_sink_file_num <- file(tmp_sink_file_name, open = "wt")
    send_output(
      file = tmp_sink_file_name,
      name = name_of_file,
      output = actual,
      expected = expected
    )
    close(tmp_sink_file_num)
    cat("\n   Output data can be seen in ", tmp_sink_file_name, "\n", sep = "")
  }
  )
  expect_identical(
    actual,
    expected
  )
}

describe("Redistribution", {
  it("Weights are provided",{

    # Read in the data
    input_data <-read_data(file.path(PROJHOME, "../resources/inputs/redistribution/WeightsProvided.json"), sc)
    View(input_data)
    # Read in the expected data
    expected_data <-read_data(file.path(PROJHOME, "../resources/outputs/redistribution/WeightsProvided.json"), sc)
    View(expected_data)

    output <- sdf_redistribution(
      sc =  sc, data = input_data, partCols <- c("id"), targetCol = "value", newCol = "output", weightCol = "weights")

    output <- output %>%
      dplyr::collect() %>%
      dplyr::select(id, value, weights, output) %>%
      dplyr::arrange(id, value, weights, output)

    expected_data <- expected_data %>%
      dplyr::collect() %>%
      dplyr::select(id, value, weights, output) %>%
      dplyr::arrange(id, value, weights, output)

    expect_identical(expected_data, output)
  })

  it("Weights are not provided",{

    # Read in the data
    input_data <-read_data(file.path(PROJHOME, "../resources/inputs/redistribution/WeightsNotProvided.json"), sc)
    View(input_data)
    # Read in the expected data
    expected_data <-read_data(file.path(PROJHOME, "../resources/outputs/redistribution/WeightsNotProvided.json"), sc)
    View(expected_data)

    output <- sdf_redistribution(
      sc =  sc, data = input_data, partCols <- c("id"), targetCol = "value", newCol = "output")

    output <- output %>%
      dplyr::collect() %>%
      dplyr::select(id, value, output) %>%
      dplyr::arrange(id, value, output)

    expected_data <- expected_data %>%
      dplyr::collect() %>%
      dplyr::select(id, value, output) %>%
      dplyr::arrange(id, value, output)

    expect_identical(expected_data, output)
  })
})
