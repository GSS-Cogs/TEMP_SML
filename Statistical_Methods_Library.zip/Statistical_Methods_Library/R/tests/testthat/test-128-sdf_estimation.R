context("Test the Estimation functions")

sc <- testthat_spark_connection()

compare_data <- function(expected, actual, name_of_file){
  # Test the expectation
  tryCatch({
    expect_identical(
      actual,
      expected
    )
  },
  error = function(e) {
    # Send the method output and expected output to a file
    tmp_sink_file_name <- tempfile(fileext = ".txt")
    tmp_sink_file_num <- file(tmp_sink_file_name, open = "wt")
    send_output(
      file = tmp_sink_file_name,
      name = name_of_file,
      output = actual,
      expected = expected
    )
    close(tmp_sink_file_num)
    cat("\n   Output data can be seen in ", tmp_sink_file_name, "\n", sep = "")
  }
  )
  expect_identical(
    actual,
    expected
  )

}

describe("Estimation By Expansion", {
  it("With Parameters", {

    # Read in the input and expected data
    input_data <- read_data(file.path(PROJHOME, "../resources/inputs/estimation/input.json"), sc)
    expected_data <- read_data(file.path(PROJHOME, "../resources/outputs/estimation/outputExpansionWithParams.json"), sc)

    # Call the method
    output <- sdf_estimate_weight_by_expansion(sc =  sc, data_frame = input_data,
                                               target_column = "target", strata_column = "strata",
                                               is_trimmed = FALSE)

    # Order and arrange the data for assertions
    expected <- expected_data %>%
      dplyr::collect()%>%
      dplyr::select(auxiliary, strata, target, design_weight)

    output <- output %>%
      dplyr::collect() %>%
      dplyr::select(auxiliary, strata, target, design_weight)

    expect_equal(output, expected)
  })

  it("With Parameters (synthetic data)", {

    # Read in the input and expected data
    input_data <- read_data(file.path(PROJHOME, "../resources/inputs/estimation/sample.json"), sc)
    expected_data <- read_data(file.path(PROJHOME, "../resources/outputs/estimation/sampleExpansionWithParams.json"), sc)

    # Call the method
    output <- sdf_estimate_weight_by_expansion(sc =  sc, data_frame = input_data,
                                               target_column = "q21_adj", strata_column = "cell_no",
                                               is_trimmed = FALSE)

    # Order and arrange the data for assertions
    expected <- expected_data %>%
      dplyr::collect() %>%
      dplyr::select(cell_no, q21_adj, rep_unit, design_weight)

    output <- output %>%
      dplyr::collect() %>%
      dplyr::select(cell_no, q21_adj, rep_unit, design_weight)

    expect_equal(output, expected)
  })

  it("No Parameters", {

    # Read in the input and expected data
    input_data <- read_data(file.path(PROJHOME, "../resources/inputs/estimation/input.json"), sc)
    expected_data <- read_data(file.path(PROJHOME, "../resources/outputs/estimation/outputExpansionNoParams.json"), sc)

    # Call the method
    output <- sdf_estimate_weight_by_expansion(sc =  sc, data_frame = input_data,
                                               target_column = "target", is_trimmed = FALSE)

    # Order and arrange the data for assertions
    expected <- expected_data %>%
      dplyr::collect() %>%
      dplyr::select(auxiliary, strata, target, design_weight)

    output <- output %>%
      dplyr::collect() %>%
      dplyr::select(auxiliary, strata, target, design_weight)

    expect_equal(output, expected)
  })

  it("No Parameters (synthetic data)", {

    # Read in the input and expected data
    input_data <- read_data(file.path(PROJHOME, "../resources/inputs/estimation/sample.json"), sc)
    expected_data <- read_data(file.path(PROJHOME, "../resources/outputs/estimation/sampleExpansionNoParams.json"), sc)

    # Call the method
    output <- sdf_estimate_weight_by_expansion(sc =  sc, data_frame = input_data,
                                               target_column = "q21_adj", is_trimmed = FALSE)

    # Order and arrange the data for assertions
    expected <- expected_data %>%
      dplyr::collect() %>%
      dplyr::select(cell_no, q21_adj, rep_unit, design_weight)

    output <- output %>%
      dplyr::collect() %>%
      dplyr::select(cell_no, q21_adj, rep_unit, design_weight)

    expect_equal(output, expected)
  })

  it("With trimming", {

    # Read in the input and expected data
    input_data <- read_data(file.path(PROJHOME, "../resources/inputs/estimation/trim.json"), sc)
    expected_data <- read_data(file.path(PROJHOME, "../resources/outputs/estimation/trimExpansionWithParams.json"), sc)

    # Call the method
    output <- sdf_estimate_weight_by_expansion(sc =  sc, data_frame = input_data,
                                               strata_column = "cell_no",
                                               target_column = "q21_adj", is_trimmed = TRUE)

    # Order and arrange the data for assertions
    expected <- expected_data %>%
      dplyr::collect() %>%
      dplyr::select(cell_no, q21_adj, employment, is_trimmed, design_weight)

    output <- output %>%
      dplyr::collect() %>%
      dplyr::select(cell_no, q21_adj, employment, is_trimmed, design_weight)

    expect_equal(output, expected)
  })

})

describe("Estimation By Ratio", {
  it("With Parameters", {

    # Read in the input and expected data
    input_data <- read_data(file.path(PROJHOME, "../resources/inputs/estimation/input.json"), sc)
    expected_data <- read_data(file.path(PROJHOME, "../resources/outputs/estimation/outputRatioWithParams.json"), sc)

    # Call the method
    output <- sdf_estimate_weight_by_ratio(sc =  sc, data_frame = input_data, target_column = "target",
                                           auxiliary_column = "auxiliary", strata_column = "strata",
                                           is_trimmed = FALSE)

    # Order and arrange the data for assertions
    expected <- expected_data %>%
      dplyr::collect() %>%
      dplyr::select(auxiliary, strata, target, design_weight, calibration_weight)

    output <- output %>%
      dplyr::collect() %>%
      dplyr::select(auxiliary, strata, target, design_weight, calibration_weight)

    expect_equal(output, expected)
  })

  it("No Parameters", {

    # Read in the input and expected data
    input_data <- read_data(file.path(PROJHOME, "../resources/inputs/estimation/input.json"), sc)
    expected_data <- read_data(file.path(PROJHOME, "../resources/outputs/estimation/outputRatioNoParams.json"), sc)

    # Call the method
    output <- sdf_estimate_weight_by_ratio(sc =  sc, data_frame = input_data,
                                           target_column = "target", auxiliary_column = "auxiliary",
                                           is_trimmed = FALSE)

    # Order and arrange the data for assertions
    expected <- expected_data %>%
      dplyr::collect() %>%
      dplyr::select(auxiliary, strata, target, design_weight, calibration_weight)

    output <- output %>%
      dplyr::collect() %>%
      dplyr::select(auxiliary, strata, target, design_weight, calibration_weight)

    expect_equal(output, expected)
  })

  it("With trimming", {

    # Read in the input and expected data
    input_data <- read_data(file.path(PROJHOME, "../resources/inputs/estimation/trim.json"), sc)
    expected_data <- read_data(file.path(PROJHOME, "../resources/outputs/estimation/trimRatioWithParams.json"), sc)

    # Call the method
    output <- sdf_estimate_weight_by_ratio(sc =  sc, data_frame = input_data,
                                           target_column = "q21_adj", auxiliary_column = "employment",
                                           strata_column = "cell_no", is_trimmed = TRUE)

    # Order and arrange the data for assertions
    expected <- expected_data %>%
      dplyr::collect() %>%
      dplyr::select(cell_no, q21_adj, employment, is_trimmed, design_weight, calibration_weight)

    output <- output %>%
      dplyr::collect() %>%
      dplyr::select(cell_no, q21_adj, employment, is_trimmed, design_weight, calibration_weight)

    expect_equal(output, expected)
  })

})
