context("Test the sdf_tpr_cleaning function")

sc <- testthat_spark_connection()

compare_data <- function(expected, actual, name_of_file){
  # Test the expectation
  tryCatch({
    expect_identical(
      actual,
      expected
    )
  },
  error = function(e) {
    # Send the method output and expected output to a file
    tmp_sink_file_name <- tempfile(fileext = ".txt")
    tmp_sink_file_num <- file(tmp_sink_file_name, open = "wt")
    send_output(
      file = tmp_sink_file_name,
      name = name_of_file,
      output = actual,
      expected = expected
    )
    close(tmp_sink_file_num)
    cat("\n   Output data can be seen in ", tmp_sink_file_name, "\n", sep = "")
  }
  )
  expect_identical(
    actual,
    expected
  )

}

describe("Cleaning TPR", {
  it("TPR Marked 0", {

    # Read in the data
    input_data <-read_data(file.path(PROJHOME, "../resources/inputs/TPRC_IN.json"), sc)
    # Read in the expected data
    expected_data <-read_data(file.path(PROJHOME, "../resources/outputs/TPRC_OUT.json"), sc)

    # Instantiate the class
    output <- sdf_tpr_cleaning(
      sc =  sc, data = input_data, Value_Col= "turnover", Marker_Col= "Marker",
      New_Col= "tpr_turnover", as.integer(1), correctorVal = as.integer(1000))

    # Order and arrange the data for assertions
    output <- output %>%
      dplyr::collect() %>%
      dplyr::select(turnover, Marker, tpr_turnover) %>%
      dplyr::mutate(Marker = as.numeric(Marker)) %>%
      dplyr::arrange(turnover, Marker, tpr_turnover)

    expected_data <- expected_data %>%
      dplyr::collect() %>%
      dplyr::select(turnover, Marker, tpr_turnover) %>%
      dplyr::arrange(turnover, Marker, tpr_turnover)

    compare_data(expected_data, output, "sdf_tpr_cleaning_s1")
  })

  it("TPR Marked 1", {

    # Read in the data
    input_data <-read_data(file.path(PROJHOME, "../resources/inputs/TPRC_IN.json"), sc)
    # Read in the expected data
    expected_data <-read_data(file.path(PROJHOME, "../resources/outputs/TPRC_OUT.json"), sc)

    # Instantiate the class
    output <- sdf_tpr_cleaning(
      sc =  sc, data = input_data, Value_Col= "turnover", Marker_Col= "Marker",
      New_Col= "tpr_turnover", markerVal = as.integer(1), correctorVal = as.integer(1000))

    # Order and arrange the data for assertions
    output <- output %>%
      dplyr::collect() %>%
      dplyr::select(turnover, Marker, tpr_turnover) %>%
      dplyr::mutate(Marker = as.numeric(Marker)) %>%
      dplyr::arrange(turnover, Marker, tpr_turnover)

    expected_data <- expected_data %>%
      dplyr::collect() %>%
      dplyr::select(turnover, Marker, tpr_turnover) %>%
      dplyr::arrange(turnover, Marker, tpr_turnover)

    compare_data(expected_data, output, "sdf_tpr_cleaning_s2")
  })
})
