context("Test the sdf_imputation function")

sc <- testthat_spark_connection()

describe("Records without a turnover will be imputed",{
  it("Forwards imputation based on returned data (current period)", {
    # Read the input data
    input_data <- read_data(file.path(PROJHOME, "../resources/inputs/imputation/CompleteData.json"), sc)
    # Read expected data
    expected_data <- read_data(file.path(PROJHOME, "../resources/outputs/imputation/CompleteData.json"), sc)

    output_data <- sdf_imputation(sc <- sc,
                                  df <- input_data,
                                  partitionCols <- c("group"),
                                  unitCol <- "id",
                                  timeCol <- "time",
                                  targetCol <- "value",
                                  outCol <- "impValue",
                                  markCol <- "marker",
                                  auxCol <- "aux")

    #Order and arrange the data for assertions
    output_data <- output_data %>%
      dplyr::collect() %>%
      dplyr::select(group, id, time, value, impValue, marker, aux) %>%
      dplyr::arrange(time, id)

    #Order and arrange the data for assertions
    expected_data <- expected_data %>%
      dplyr::collect() %>%
      dplyr::select(group, id, time, value, impValue, marker, aux) %>%
      dplyr::arrange(time, id)

    expect_identical(expected_data, output_data)
  })

  it("Backwards imputation based on returned data (current period)", {
    # Read the input data
    input_data <- read_data(file.path(PROJHOME, "../resources/inputs/imputation/BackwardSingle.json"), sc)
    # Read expected data
    expected_data <- read_data(file.path(PROJHOME, "../resources/outputs/imputation/BackwardSingle.json"), sc)

    output_data <- sdf_imputation(sc <- sc,
                                  df <- input_data,
                                  partitionCols <- c("group"),
                                  unitCol <- "id",
                                  timeCol <- "time",
                                  targetCol <- "value",
                                  outCol <- "impValue",
                                  markCol <- "marker",
                                  auxCol <- "aux")

    #Order and arrange the data for assertions
    output_data <- output_data %>%
      dplyr::collect() %>%
      dplyr::select(group, id, time, value, impValue, marker, aux) %>%
      dplyr::arrange(time, id)

    #Order and arrange the data for assertions
    expected_data <- expected_data %>%
      dplyr::collect() %>%
      dplyr::select(group, id, time, value, impValue, marker, aux) %>%
      dplyr::arrange(time, id)

    expect_identical(expected_data, output_data)
  })

  it("Forwards imputation based on auxiliary variable ('Construction')", {
    # Read the input data
    input_data <- read_data(file.path(PROJHOME, "../resources/inputs/imputation/ForwardConstruct.json"), sc)
    # Read expected data
    expected_data <- read_data(file.path(PROJHOME, "../resources/outputs/imputation/ForwardConstruct.json"), sc)

    output_data <- sdf_imputation(sc <- sc,
                                  df <- input_data,
                                  partitionCols <- c("group"),
                                  unitCol <- "id",
                                  timeCol <- "time",
                                  targetCol <- "value",
                                  outCol <- "impValue",
                                  markCol <- "marker",
                                  auxCol <- "aux")

    #Order and arrange the data for assertions
    output_data <- output_data %>%
      dplyr::collect() %>%
      dplyr::select(group, id, time, value, impValue, marker, aux) %>%
      dplyr::arrange(time, id)

    #Order and arrange the data for assertions
    expected_data <- expected_data %>%
      dplyr::collect() %>%
      dplyr::select(group, id, time, value, impValue, marker, aux) %>%
      dplyr::arrange(time, id)

    expect_identical(expected_data, output_data)
  })

  it("No previous data or auxiliary data available", {
    # Read the input data
    input_data <- read_data(file.path(PROJHOME, "../resources/inputs/imputation/NoDataAndAux.json"), sc)
    # Read expected data
    expected_data <- read_data(file.path(PROJHOME, "../resources/outputs/imputation/NoDataAndAux.json"), sc)

    output_data <- sdf_imputation(sc <- sc,
                                  df <- input_data,
                                  partitionCols <- c("group"),
                                  unitCol <- "id",
                                  timeCol <- "time",
                                  targetCol <- "value",
                                  outCol <- "impValue",
                                  markCol <- "marker",
                                  auxCol <- "aux")

    #Order and arrange the data for assertions
    output_data <- output_data %>%
      dplyr::collect() %>%
      dplyr::select(group, id, time, value, impValue, marker, aux) %>%
      dplyr::arrange(time, id)

    #Order and arrange the data for assertions
    expected_data <- expected_data %>%
      dplyr::collect() %>%
      dplyr::select(group, id, time, value, impValue, marker, aux) %>%
      dplyr::arrange(time, id)

    expect_identical(expected_data, output_data)
  })

  it("Would never backwards impute to overwrite forward imputed data from returned data", {
    # Read the input data
    input_data <- read_data(file.path(PROJHOME, "../resources/inputs/imputation/ForwardsOverBackwards.json"), sc)
    # Read expected data
    expected_data <- read_data(file.path(PROJHOME, "../resources/outputs/imputation/ForwardsOverBackwards.json"), sc)

    output_data <- sdf_imputation(sc <- sc,
                                  df <- input_data,
                                  partitionCols <- c("group"),
                                  unitCol <- "id",
                                  timeCol <- "time",
                                  targetCol <- "value",
                                  outCol <- "impValue",
                                  markCol <- "marker",
                                  auxCol <- "aux")

    #Order and arrange the data for assertions
    output_data <- output_data %>%
      dplyr::collect() %>%
      dplyr::select(group, id, time, value, impValue, marker, aux) %>%
      dplyr::arrange(time, id)

    #Order and arrange the data for assertions
    expected_data <- expected_data %>%
      dplyr::collect() %>%
      dplyr::select(group, id, time, value, impValue, marker, aux) %>%
      dplyr::arrange(time, id)

    expect_identical(expected_data, output_data)
  })
})
