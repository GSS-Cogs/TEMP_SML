context("Test the sdf_median_redistribution function")

sc <- testthat_spark_connection()


describe("Records marked as unclean are cleaned based on the pattern seen in the median value of similar clean records (same type and timeframe)",{

  # Read the input data
  input_data <- read_data(file.path(PROJHOME, "../resources/inputs/medianRedistribution/In1.json"), sc)
  # Read expected data
  expected_data <- read_data(file.path(PROJHOME, "../resources/outputs/medianRedistribution/Out1.json"), sc)

  output_data <- sdf_median_redistribution(sc <- sc,
                                           df <- input_data,
                                           partitionCol <- "id",
                                           timeCol <- "time",
                                           markerCol <- "marker",
                                           typeCol <- "type",
                                           targetCol <- "target",
                                           uncleanVals <- c("false"),
                                           outCol <- "new_target")

  #Order and arrange the data for assertions
  output_data <- output_data %>%
    dplyr::collect() %>%
    dplyr::select(id, time, marker, type, target, new_target) %>%
    dplyr::arrange(id, time, marker, type, target, new_target)

  expected_data <- expected_data %>%
    dplyr::collect() %>%
    dplyr::select(id, time, marker, type, target, new_target) %>%
    dplyr::arrange(id, time, marker, type, target, new_target)


  expect_identical(expected_data, output_data)
})
